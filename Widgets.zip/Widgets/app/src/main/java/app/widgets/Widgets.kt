package app.widgets

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint

/** Everything the app knows about the widget types, in one place. */
object Widgets {
    const val RINGER = "ringer"
    const val NP = "np"
    const val WX = "wx"
    val types = listOf(RINGER, NP, WX)

    fun cls(t: String): Class<*> = when (t) {
        RINGER -> RingerWidget::class.java
        NP -> NowPlayingWidget::class.java
        else -> WeatherWidget::class.java
    }

    fun label(t: String) = when (t) {
        RINGER -> "Ringer mode"
        NP -> "Now playing"
        else -> "Weather"
    }

    fun blurb(t: String) = when (t) {
        RINGER -> "Silent, vibrate or ring in one tap"
        NP -> "Album art, controls and a wavy progress bar"
        else -> "Current conditions, hourly and daily chips"
    }

    /** A sensible size in dp, used before the launcher reports a real one. */
    fun defaultDp(t: String): Pair<Int, Int> = when (t) {
        RINGER -> 250 to 70
        NP -> 300 to 170
        else -> 300 to 190
    }

    fun ids(c: Context, t: String): IntArray =
        AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, cls(t)))

    fun all(c: Context): List<Pair<Int, String>> {
        val out = ArrayList<Pair<Int, String>>()
        for (t in types) for (id in ids(c, t)) out.add(id to t)
        return out
    }

    fun typeOf(c: Context, id: Int): String? = all(c).firstOrNull { it.first == id }?.second

    fun any(c: Context) = types.any { ids(c, it).isNotEmpty() }

    fun style(c: Context, i: Inst): Style = if (i.useGlobal) Store.theme(c) else i.style

    fun sizePx(c: Context, m: AppWidgetManager, id: Int, t: String): Pair<Int, Int> {
        val o = m.getAppWidgetOptions(id)
        val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var wDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var hDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        val def = defaultDp(t)
        if (wDp <= 0) wDp = def.first
        if (hDp <= 0) hDp = def.second
        val d = c.resources.displayMetrics.density
        return Pair((wDp * d).toInt().coerceAtMost(1400), (hDp * d).toInt().coerceAtMost(1000))
    }

    /** A widget as a bitmap. preview = true fills in sample data when nothing real is available. */
    fun render(c: Context, t: String, id: Int, inst: Inst, w: Int, h: Int, preview: Boolean, pos: Float? = null): Bitmap {
        val st = style(c, inst)
        return when (t) {
            RINGER -> RingerRenderer.render(c, st, inst.ringer, pos ?: RingerWidget.mode(c).toFloat(), w, h)
            NP -> NpRenderer.render(c, st, inst.np, NpState.current(c) ?: (if (preview) NpState.sample() else null), w, h).bmp
            else -> WxRenderer.render(c, st, inst.wx, Wx.cached(c, id) ?: (if (preview) Wx.sample() else null), w, h, Wx.time(c, id))
        }
    }

    fun updateAll(c: Context) {
        RingerWidget.updateAll(c)
        NowPlayingWidget.updateAll(c)
        WeatherWidget.updateAll(c)
    }

    fun alpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun blank(w: Int, h: Int): Pair<Bitmap, Canvas> {
        val b = Bitmap.createBitmap(w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        return b to Canvas(b)
    }

    fun paint(): Paint = Paint(Paint.ANTI_ALIAS_FLAG)
}
