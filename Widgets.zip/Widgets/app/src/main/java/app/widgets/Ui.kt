package app.widgets

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch

/** One shared look for the settings screens: rounded cards, accent buttons and sliders, light/dark aware. */
object Ui {
    var dark = false
    var bg = 0
    var card = 0
    var chip = 0
    var text = 0
    var sub = 0
    var accent = 0
    var onAccent = 0

    fun init(c: Context) {
        dark = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        bg = (if (dark) 0xFF0E1013L else 0xFFF4F5F8L).toInt()
        card = (if (dark) 0xFF181B21L else 0xFFFFFFFFL).toInt()
        chip = (if (dark) 0xFF242830L else 0xFFEBEDF2L).toInt()
        text = (if (dark) 0xFFF2F4F8L else 0xFF14161AL).toInt()
        sub = (if (dark) 0xFF9AA3B2L else 0xFF677084L).toInt()
        accent = (if (dark) 0xFF7C9CFFL else 0xFF3F63E0L).toInt()
        onAccent = if (dark) 0xFF0E1013L.toInt() else Color.WHITE
    }

    fun round(color: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = r
        return g
    }

    private fun ripple(color: Int, r: Float): RippleDrawable {
        val rip = if (dark) 0x33FFFFFF else 0x22000000
        return RippleDrawable(ColorStateList.valueOf(rip), round(color, r), round(Color.BLACK, r))
    }

    /** Call after setContentView: edge-to-edge, themed window background, bar icon colours. */
    fun window(a: Activity) {
        a.window.setDecorFitsSystemWindows(false)
        a.window.setBackgroundDrawable(ColorDrawable(bg))
        a.window.statusBarColor = Color.TRANSPARENT
        a.window.navigationBarColor = Color.TRANSPARENT
        try {
            val light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            a.window.decorView.windowInsetsController?.setSystemBarsAppearance(if (dark) 0 else light, light)
        } catch (e: Throwable) {
        }
    }

    /** Restyles stock widgets in a finished view tree. Safe to call twice on the same views. */
    fun polish(v: View, dp: (Int) -> Int) {
        when (v) {
            is EditText -> {
                v.background = round(chip, dp(12).toFloat())
                v.setPadding(dp(14), dp(10), dp(14), dp(10))
            }
            is Button -> {
                v.isAllCaps = false
                v.setTextColor(accent)
                v.background = ripple(chip, dp(12).toFloat())
                v.stateListAnimator = null
                v.minHeight = dp(44)
                v.minimumHeight = dp(44)
                v.setPadding(dp(16), dp(8), dp(16), dp(8))
                val par = v.parent
                if (par is LinearLayout && par.orientation == LinearLayout.VERTICAL) {
                    val lp = v.layoutParams as? LinearLayout.LayoutParams
                    if (lp != null && lp.topMargin < dp(8)) lp.topMargin = dp(8)
                }
            }
            is Switch -> {
                val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                v.thumbTintList = ColorStateList(st, intArrayOf(accent, sub))
                v.trackTintList = ColorStateList(st, intArrayOf((accent and 0x00FFFFFF) or 0x66000000, chip))
            }
            is SeekBar -> {
                v.progressTintList = ColorStateList.valueOf(accent)
                v.thumbTintList = ColorStateList.valueOf(accent)
                v.progressBackgroundTintList = ColorStateList.valueOf(chip)
            }
            is Spinner -> {
                val arrow = v.context.getDrawable(R.drawable.ic_arrow_down)?.mutate()
                arrow?.setTint(sub)
                val base = round(chip, dp(12).toFloat())
                if (arrow != null) {
                    val ld = LayerDrawable(arrayOf(base, arrow))
                    ld.setLayerGravity(1, Gravity.END or Gravity.CENTER_VERTICAL)
                    ld.setLayerInset(1, 0, 0, dp(12), 0)
                    ld.setLayerSize(1, dp(16), dp(16))
                    v.background = ld
                } else {
                    v.background = base
                }
                v.setPadding(dp(14), dp(10), dp(36), dp(10))
            }
        }
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) polish(v.getChildAt(i), dp)
        }
    }

    /** Restyle anything that is added to this box later (lists that rebuild themselves). */
    fun watch(box: ViewGroup, dp: (Int) -> Int) {
        box.setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
            override fun onChildViewAdded(parent: View?, child: View?) {
                if (child != null) polish(child, dp)
            }

            override fun onChildViewRemoved(parent: View?, child: View?) {}
        })
    }
}
