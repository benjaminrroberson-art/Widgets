package app.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.TextPaint
import android.text.format.DateFormat
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class Place(val name: String, val detail: String, val lat: Double, val lon: Double)

/** Weather data from Open-Meteo (no key, no account), cached per widget. */
object Wx {
    private const val STALE_MS = 20 * 60 * 1000L

    fun cached(c: Context, id: Int): JSONObject? = try {
        Store.getStr(c, "wxj_$id")?.let { JSONObject(it) }
    } catch (e: Exception) {
        null
    }

    fun time(c: Context, id: Int): Long = Store.getLong(c, "wxt_$id", 0L)

    private fun http(url: String): String? = try {
        val u = URL(url)
        val cn = u.openConnection() as HttpURLConnection
        cn.connectTimeout = 12000
        cn.readTimeout = 15000
        cn.setRequestProperty("User-Agent", "Widgets/0.2 (Android)")
        val code = cn.responseCode
        if (code in 200..299) cn.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) {
        null
    }

    fun fetch(lat: Double, lon: Double): JSONObject? {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,is_day,wind_speed_10m,uv_index" +
            "&hourly=temperature_2m,weather_code,is_day,precipitation_probability" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max" +
            "&timezone=auto&forecast_days=8"
        return try {
            http(url)?.let { JSONObject(it) }
        } catch (e: Exception) {
            null
        }
    }

    /** Fetches and stores data for one widget if it is stale. Blocking, call off the main thread. */
    fun refresh(c: Context, id: Int, force: Boolean): Boolean {
        val cfg = Store.inst(c, id).wx
        if (!cfg.hasLoc) return false
        if (!force && System.currentTimeMillis() - time(c, id) < STALE_MS && cached(c, id) != null) return false
        val j = fetch(cfg.lat, cfg.lon) ?: return false
        Store.putStr(c, "wxj_$id", j.toString())
        Store.putLong(c, "wxt_$id", System.currentTimeMillis())
        return true
    }

    fun refreshAll(c: Context, force: Boolean) {
        val ctx = c.applicationContext
        Thread {
            var any = false
            for (id in Widgets.ids(ctx, Widgets.WX)) if (refresh(ctx, id, force)) any = true
            if (any) WeatherWidget.updateAll(ctx)
        }.start()
    }

    fun geocode(q: String): List<Place> {
        val body = http("https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(q, "UTF-8") + "&count=6&language=en&format=json") ?: return emptyList()
        return try {
            val arr = JSONObject(body).optJSONArray("results") ?: return emptyList()
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                val detail = listOf(o.optString("admin1"), o.optString("country")).filter { s -> s.isNotEmpty() }.joinToString(", ")
                Place(o.optString("name"), detail, o.optDouble("latitude"), o.optDouble("longitude"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun arr(vararg v: Any): JSONArray {
        val a = JSONArray()
        v.forEach { a.put(it) }
        return a
    }

    fun sample(): JSONObject {
        val now = LocalDateTime.now().withMinute(0).withSecond(0).withNano(0)
        val f = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")
        val codes = intArrayOf(2, 2, 3, 61, 61, 3, 1, 0)
        val h = JSONObject()
        val ht = JSONArray(); val hT = JSONArray(); val hC = JSONArray(); val hD = JSONArray(); val hP = JSONArray()
        for (i in 0 until 48) {
            val t = now.plusHours(i.toLong())
            ht.put(t.format(f)); hT.put(14.0 + 5 * Math.sin(i / 3.8)); hC.put(codes[(i / 3) % codes.size])
            hD.put(if (t.hour in 7..18) 1 else 0); hP.put(if (codes[(i / 3) % codes.size] == 61) 60 else 10)
        }
        h.put("time", ht).put("temperature_2m", hT).put("weather_code", hC).put("is_day", hD).put("precipitation_probability", hP)
        val d = JSONObject()
        val dt = JSONArray(); val dC = JSONArray(); val dH = JSONArray(); val dL = JSONArray(); val dP = JSONArray(); val dU = JSONArray()
        val dcodes = intArrayOf(2, 61, 3, 0, 1, 71, 95, 2)
        for (i in 0 until 8) {
            dt.put(LocalDate.now().plusDays(i.toLong()).toString()); dC.put(dcodes[i]); dH.put(19.0 - i); dL.put(9.0 - i * 0.5)
            dP.put(20 + i * 5); dU.put(4.0)
        }
        d.put("time", dt).put("weather_code", dC).put("temperature_2m_max", dH).put("temperature_2m_min", dL)
            .put("precipitation_probability_max", dP).put("uv_index_max", dU)
        val cur = JSONObject().put("time", now.format(f)).put("temperature_2m", 16.0).put("apparent_temperature", 14.5)
            .put("relative_humidity_2m", 62).put("weather_code", 2).put("is_day", 1).put("wind_speed_10m", 13.0).put("uv_index", 3.0)
        return JSONObject().put("current", cur).put("hourly", h).put("daily", d)
    }

    /** Lists what Breezy Weather's content provider answers with, so the format can be checked on a real phone. */
    fun breezyProbe(c: Context): String {
        val sb = StringBuilder()
        try {
            c.packageManager.getPackageInfo("org.breezyweather", 0)
        } catch (e: Exception) {
            return "Breezy Weather isn't installed (org.breezyweather)."
        }
        val uris = listOf(
            "content://org.breezyweather.provider.weather/locations?limit=3",
            "content://org.breezyweather.provider.weather/weather",
            "content://org.breezyweather.provider/locations?limit=3",
            "content://org.breezyweather.provider/weather"
        )
        for (u in uris) {
            sb.append(u).append('\n')
            try {
                val cur = c.contentResolver.query(Uri.parse(u), null, null, null, null)
                if (cur == null) {
                    sb.append("  null cursor\n")
                } else {
                    cur.use {
                        sb.append("  columns: ").append(it.columnNames.joinToString(", ")).append('\n')
                        sb.append("  rows: ").append(it.count).append('\n')
                        if (it.moveToFirst()) {
                            for (k in 0 until it.columnCount) {
                                val v = try { it.getString(k) } catch (e: Exception) { "?" }
                                sb.append("  ").append(it.getColumnName(k)).append(" = ").append((v ?: "null").take(300)).append('\n')
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                sb.append("  ").append(e.javaClass.simpleName).append(": ").append(e.message?.take(200)).append('\n')
            }
        }
        return sb.toString()
    }
}

private class WxNow(val time: LocalDateTime, val temp: Double, val feels: Double, val humidity: Int, val code: Int, val day: Boolean, val wind: Double, val uv: Double)
private class WxHour(val time: LocalDateTime, val temp: Double, val code: Int, val day: Boolean, val pop: Int)
private class WxDay(val date: LocalDate, val hi: Double, val lo: Double, val code: Int, val pop: Int)
private class WxData(val now: WxNow, val hours: List<WxHour>, val days: List<WxDay>)

private fun parseWx(j: JSONObject): WxData? = try {
    val cu = j.getJSONObject("current")
    val f = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")
    val nowT = try { LocalDateTime.parse(cu.getString("time"), f) } catch (e: Exception) { LocalDateTime.now() }
    val now = WxNow(
        nowT, cu.optDouble("temperature_2m"), cu.optDouble("apparent_temperature", cu.optDouble("temperature_2m")),
        cu.optInt("relative_humidity_2m"), cu.optInt("weather_code"), cu.optInt("is_day", 1) == 1,
        cu.optDouble("wind_speed_10m"), cu.optDouble("uv_index")
    )
    val h = j.getJSONObject("hourly")
    val ht = h.getJSONArray("time")
    val start = nowT.withMinute(0).withSecond(0).withNano(0)
    val hours = ArrayList<WxHour>()
    for (i in 0 until ht.length()) {
        val t = LocalDateTime.parse(ht.getString(i), f)
        if (t.isBefore(start)) continue
        hours.add(WxHour(t, h.getJSONArray("temperature_2m").optDouble(i), h.getJSONArray("weather_code").optInt(i), h.getJSONArray("is_day").optInt(i, 1) == 1, h.optJSONArray("precipitation_probability")?.optInt(i) ?: 0))
    }
    val d = j.getJSONObject("daily")
    val dt = d.getJSONArray("time")
    val days = ArrayList<WxDay>()
    for (i in 0 until dt.length()) {
        days.add(WxDay(LocalDate.parse(dt.getString(i)), d.getJSONArray("temperature_2m_max").optDouble(i), d.getJSONArray("temperature_2m_min").optDouble(i), d.getJSONArray("weather_code").optInt(i), d.optJSONArray("precipitation_probability_max")?.optInt(i) ?: 0))
    }
    WxData(now, hours, days)
} catch (e: Exception) {
    null
}

object WxText {
    fun desc(code: Int) = when (code) {
        0 -> "Clear"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        51, 53, 55, 56, 57 -> "Drizzle"
        61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Showers"
        85, 86 -> "Snow showers"
        95, 96, 99 -> "Thunderstorm"
        else -> "Cloudy"
    }
}

/** Weather icons drawn with paths, either filled or as outlines. */
object WxIcons {
    private fun kind(code: Int) = when (code) {
        0, 1 -> 0
        2 -> 1
        3 -> 2
        45, 48 -> 3
        51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> 4
        71, 73, 75, 77, 85, 86 -> 5
        95, 96, 99 -> 6
        else -> 2
    }

    private fun cloud(cx: Float, cy: Float, w: Float): Path {
        val h = w * 0.62f
        val l = cx - w / 2
        val t = cy - h / 2
        val base = Path()
        base.addRoundRect(RectF(l, t + h * 0.42f, l + w, t + h), h * 0.29f, h * 0.29f, Path.Direction.CW)
        val b1 = Path()
        b1.addCircle(l + w * 0.30f, t + h * 0.50f, h * 0.30f, Path.Direction.CW)
        val b2 = Path()
        b2.addCircle(l + w * 0.56f, t + h * 0.36f, h * 0.38f, Path.Direction.CW)
        base.op(b1, Path.Op.UNION)
        base.op(b2, Path.Op.UNION)
        return base
    }

    fun draw(cv: Canvas, code: Int, day: Boolean, cx: Float, cy: Float, s: Float, accent: Int, text: Int, outline: Boolean) {
        val sw = s * 0.075f
        val p = Widgets.paint()
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        fun body(path: Path, col: Int) {
            p.color = col
            p.style = if (outline) Paint.Style.STROKE else Paint.Style.FILL
            p.strokeWidth = sw
            cv.drawPath(path, p)
        }
        fun stroke(col: Int, w: Float = sw) {
            p.color = col
            p.style = Paint.Style.STROKE
            p.strokeWidth = w
        }
        val cloudCol = Widgets.alpha(text, 235)
        fun sun(x: Float, y: Float, r: Float) {
            val c = Path()
            c.addCircle(x, y, r, Path.Direction.CW)
            body(c, accent)
            stroke(accent)
            for (i in 0 until 8) {
                val a = Math.PI / 4 * i
                val c1 = Math.cos(a).toFloat()
                val s1 = Math.sin(a).toFloat()
                cv.drawLine(x + c1 * r * 1.5f, y + s1 * r * 1.5f, x + c1 * r * 1.95f, y + s1 * r * 1.95f, p)
            }
        }
        fun moon(x: Float, y: Float, r: Float) {
            val a = Path()
            a.addCircle(x, y, r, Path.Direction.CW)
            val b = Path()
            b.addCircle(x + r * 0.55f, y - r * 0.4f, r * 0.85f, Path.Direction.CW)
            a.op(b, Path.Op.DIFFERENCE)
            body(a, Widgets.alpha(text, 235))
        }
        fun orb(x: Float, y: Float, r: Float) = if (day) sun(x, y, r) else moon(x, y, r)

        when (kind(code)) {
            0 -> orb(cx, cy, s * (if (day) 0.24f else 0.3f))
            1 -> {
                val cl = cloud(cx + s * 0.06f, cy + s * 0.1f, s * 0.74f)
                cv.save()
                cv.clipOutPath(cl)
                orb(cx - s * 0.16f, cy - s * 0.14f, s * 0.17f)
                cv.restore()
                body(cl, cloudCol)
            }
            2 -> {
                body(cloud(cx + s * 0.15f, cy - s * 0.12f, s * 0.5f), Widgets.alpha(text, 130))
                val front = cloud(cx - s * 0.04f, cy + s * 0.06f, s * 0.78f)
                body(front, cloudCol)
            }
            3 -> {
                body(cloud(cx, cy - s * 0.15f, s * 0.66f), cloudCol)
                stroke(Widgets.alpha(text, 200))
                cv.drawLine(cx - s * 0.3f, cy + s * 0.16f, cx + s * 0.3f, cy + s * 0.16f, p)
                cv.drawLine(cx - s * 0.2f, cy + s * 0.3f, cx + s * 0.34f, cy + s * 0.3f, p)
            }
            4 -> {
                body(cloud(cx, cy - s * 0.1f, s * 0.76f), cloudCol)
                stroke(accent, sw * 1.2f)
                for (i in -1..1) {
                    val x = cx + i * s * 0.2f
                    cv.drawLine(x + s * 0.03f, cy + s * 0.2f, x - s * 0.03f, cy + s * 0.34f, p)
                }
            }
            5 -> {
                body(cloud(cx, cy - s * 0.1f, s * 0.76f), cloudCol)
                p.style = Paint.Style.FILL
                p.color = accent
                for (i in -1..1) cv.drawCircle(cx + i * s * 0.2f, cy + s * 0.28f - Math.abs(i) * s * 0.04f, s * 0.04f, p)
            }
            else -> {
                body(cloud(cx, cy - s * 0.12f, s * 0.76f), cloudCol)
                val b = Path()
                b.moveTo(cx + s * 0.07f, cy + s * 0.1f)
                b.lineTo(cx - s * 0.1f, cy + s * 0.3f)
                b.lineTo(cx, cy + s * 0.3f)
                b.lineTo(cx - s * 0.06f, cy + s * 0.46f)
                b.lineTo(cx + s * 0.14f, cy + s * 0.24f)
                b.lineTo(cx + s * 0.03f, cy + s * 0.24f)
                b.close()
                body(b, accent)
            }
        }
    }
}

object WxRenderer {
    private fun fit(p: TextPaint, text: String, maxW: Float, minSize: Float) {
        while (p.measureText(text) > maxW && p.textSize > minSize) p.textSize -= 0.5f
    }

    fun render(c: Context, st: Style, cfg: WxCfg, json: JSONObject?, wPx: Int, hPx: Int, updatedMs: Long): Bitmap {
        val (bmp, cv) = Widgets.blank(wPx, hPx)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val d = c.resources.displayMetrics.density
        val ts = st.textScale / 100f
        val pal = Palette.of(c, st)
        val metric = cfg.metric
        val outline = cfg.iconStyle == 1
        val p = Widgets.paint()
        val base = FontStore.typeface(c, st.font)
        val bold = Typeface.create(base, Typeface.BOLD)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)

        if (st.bgOpacity > 0) {
            p.color = Widgets.alpha(pal.bg, st.bgOpacity * 255 / 100)
            val r = (st.corner * d).coerceAtMost(minOf(w, h) / 2f)
            cv.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        }

        val data = json?.let { parseWx(it) }
        if (data == null) {
            tp.typeface = bold
            tp.textSize = 16f * d * ts
            tp.color = pal.text
            tp.textAlign = Paint.Align.CENTER
            cv.drawText(if (cfg.hasLoc) "Loading weather…" else "Set a location in the app", w / 2f, h / 2f, tp)
            return bmp
        }

        fun temp(cc: Double): String = ((if (metric) cc else cc * 9 / 5 + 32).roundToInt()).toString() + "°"
        val is24 = DateFormat.is24HourFormat(c)

        val pad = 14f * d
        val gap = 6f * d
        val vis = cfg.visible().filter { (it != "hourly" || cfg.hourly > 0) && (it != "daily" || cfg.daily > 0) }
        val topExtra = if (cfg.updated && vis.firstOrNull() != "current") 12f * d else 0f
        val innerW = w - 2 * pad
        val innerH = h - 2 * pad - topExtra - gap * (vis.size - 1).coerceAtLeast(0)
        val weights = mapOf("current" to 1.5f, "hourly" to 1.25f, "daily" to 1.25f, "details" to 0.5f)
        val total = vis.sumOf { (weights[it] ?: 1f).toDouble() }.toFloat().coerceAtLeast(0.1f)
        var y = pad + topExtra

        val now = data.now
        val today = data.days.firstOrNull()

        for (part in vis) {
            val hh = innerH * (weights[part] ?: 1f) / total
            when (part) {
                "current" -> {
                    val iconS = minOf(hh * 0.92f, innerW * 0.26f)
                    WxIcons.draw(cv, now.code, now.day, pad + iconS / 2f, y + hh / 2f, iconS, pal.accent, pal.text, outline)
                    tp.typeface = bold
                    tp.textSize = minOf(hh * 0.64f, 46f * d * ts)
                    tp.color = pal.text
                    tp.textAlign = Paint.Align.LEFT
                    val tx = pad + iconS + 8f * d
                    val tt = temp(now.temp)
                    cv.drawText(tt, tx, y + hh / 2f + tp.textSize * 0.35f, tp)
                    val colX = tx + tp.measureText(tt) + 14f * d
                    val room = pad + innerW - colX
                    if (room > 60f * d) {
                        val lines = ArrayList<Triple<String, Int, Float>>()
                        lines.add(Triple(WxText.desc(now.code), pal.text, 13.5f))
                        if (today != null) lines.add(Triple("H " + temp(today.hi) + "   L " + temp(today.lo), Widgets.alpha(pal.text, 175), 12f))
                        if (cfg.place.isNotEmpty() && hh > 52f * d) lines.add(Triple(cfg.place, Widgets.alpha(pal.text, 130), 11f))
                        val lh = 16f * d * ts
                        var yy = y + hh / 2f - (lines.size * lh) / 2f + lh * 0.8f
                        for ((txt, col, sz) in lines) {
                            tp.typeface = if (col == pal.text) bold else base
                            tp.textSize = sz * d * ts
                            tp.color = col
                            fit(tp, txt, room, 8f * d)
                            cv.drawText(txt, colX, yy, tp)
                            yy += lh
                        }
                    }
                }
                "hourly", "daily" -> {
                    val isH = part == "hourly"
                    val n = if (isH) minOf(cfg.hourly, data.hours.size) else minOf(cfg.daily, data.days.size)
                    if (n > 0) {
                        val cw = (innerW - gap * (n - 1)) / n
                        val rad = when (cfg.chip) {
                            0 -> minOf(14f * d * st.corner / 28f, cw / 2f, hh / 2f)
                            1 -> minOf(cw, hh) / 2f
                            else -> 0f
                        }
                        for (i in 0 until n) {
                            val x = pad + i * (cw + gap)
                            val cx = x + cw / 2f
                            if (cfg.chip != 2) {
                                p.style = Paint.Style.FILL
                                p.color = Widgets.alpha(pal.text, 22)
                                cv.drawRoundRect(RectF(x, y, x + cw, y + hh), rad, rad, p)
                            }
                            val label: String
                            val code: Int
                            val dayFlag: Boolean
                            if (isH) {
                                val hr = data.hours[i]
                                label = if (i == 0) "Now" else hr.time.format(DateTimeFormatter.ofPattern(if (is24) "HH" else "h a", Locale.getDefault()))
                                code = hr.code; dayFlag = hr.day
                            } else {
                                val dy = data.days[i]
                                label = if (i == 0) "Today" else dy.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
                                code = dy.code; dayFlag = true
                            }
                            tp.typeface = base
                            tp.textAlign = Paint.Align.CENTER
                            tp.textSize = minOf(11f * d * ts, hh * 0.2f)
                            tp.color = Widgets.alpha(pal.text, 170)
                            fit(tp, label, cw - 4f * d, 7f * d)
                            cv.drawText(label, cx, y + hh * 0.25f, tp)
                            val isz = minOf(cw * 0.62f, hh * 0.42f)
                            WxIcons.draw(cv, code, dayFlag, cx, y + hh * 0.52f, isz, pal.accent, pal.text, outline)
                            tp.textSize = minOf(13f * d * ts, hh * 0.22f)
                            tp.typeface = bold
                            tp.color = pal.text
                            if (isH) {
                                val tt = temp(data.hours[i].temp)
                                fit(tp, tt, cw - 4f * d, 7f * d)
                                cv.drawText(tt, cx, y + hh * 0.9f, tp)
                            } else {
                                val dy = data.days[i]
                                val hi = temp(dy.hi)
                                val lo = temp(dy.lo)
                                tp.textAlign = Paint.Align.LEFT
                                fit(tp, "$hi $lo", cw - 4f * d, 7f * d)
                                val wHi = tp.measureText("$hi ")
                                val wLo = tp.measureText(lo)
                                val sx = cx - (wHi + wLo) / 2f
                                cv.drawText(hi, sx, y + hh * 0.9f, tp)
                                tp.typeface = base
                                tp.color = Widgets.alpha(pal.text, 150)
                                cv.drawText(lo, sx + wHi, y + hh * 0.9f, tp)
                            }
                        }
                    }
                }
                "details" -> {
                    val items = ArrayList<String>()
                    if (cfg.uv) items.add("UV " + now.uv.roundToInt())
                    if (cfg.humidity) items.add("Humidity " + now.humidity + "%")
                    if (cfg.wind) items.add("Wind " + (if (metric) now.wind.roundToInt().toString() + " km/h" else (now.wind * 0.621371).roundToInt().toString() + " mph"))
                    if (cfg.feels) items.add("Feels " + temp(now.feels))
                    if (items.isNotEmpty()) {
                        val cw = innerW / items.size
                        tp.typeface = base
                        tp.textAlign = Paint.Align.CENTER
                        tp.color = Widgets.alpha(pal.text, 200)
                        for ((i, t) in items.withIndex()) {
                            tp.textSize = minOf(12f * d * ts, hh * 0.7f)
                            fit(tp, t, cw - 4f * d, 7f * d)
                            cv.drawText(t, pad + cw * (i + 0.5f), y + hh / 2f + tp.textSize * 0.35f, tp)
                        }
                    }
                }
            }
            y += hh + gap
        }

        if (cfg.updated && updatedMs > 0) {
            tp.typeface = base
            tp.textSize = 10f * d * ts
            tp.color = Widgets.alpha(pal.text, 120)
            tp.textAlign = Paint.Align.RIGHT
            cv.drawText("Updated " + DateFormat.getTimeFormat(c).format(Date(updatedMs)), w - pad, pad + 8f * d, tp)
        }
        return bmp
    }
}

class WeatherWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(c, m, it) }
        val pending = goAsync()
        val ctx = c.applicationContext
        Thread {
            try {
                var any = false
                ids.forEach { if (Wx.refresh(ctx, it, false)) any = true }
                if (any) updateAll(ctx)
            } finally {
                pending.finish()
            }
        }.start()
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, opts: android.os.Bundle?) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        ids.forEach { Store.deleteInst(c, it) }
    }

    override fun onEnabled(c: Context) {
        Live.ensure(c)
    }

    override fun onDisabled(c: Context) {
        if (!Widgets.any(c)) Live.stop(c)
    }

    companion object {
        fun update(c: Context, m: AppWidgetManager, id: Int) {
            try {
                val inst = Store.inst(c, id)
                val st = Widgets.style(c, inst)
                val (w, h) = Widgets.sizePx(c, m, id, Widgets.WX)
                val bmp = WxRenderer.render(c, st, inst.wx, Wx.cached(c, id), w, h, Wx.time(c, id))
                val rv = RemoteViews(c.packageName, R.layout.widget_wx)
                rv.setImageViewBitmap(R.id.img, bmp)
                val launch = c.packageManager.getLaunchIntentForPackage("org.breezyweather")
                    ?: Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                rv.setOnClickPendingIntent(
                    R.id.bg,
                    PendingIntent.getActivity(c, id, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                )
                m.updateAppWidget(id, rv)
            } catch (e: Exception) {
            }
        }

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            Widgets.ids(c, Widgets.WX).forEach { update(c, m, it) }
        }
    }
}
