package app.widgets

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.provider.CalendarContract
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.text.format.DateFormat
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

class CalInfo(val id: Long, val name: String, val account: String, val color: Int)

/** One event on the phone's calendar. Times are real local milliseconds; all-day events run from local midnight to local midnight. */
class Ev(val id: Long, val title: String, val begin: Long, val end: Long, val allDay: Boolean, val color: Int, val loc: String)

/** A row in the agenda: a day header, an event, or a note that the day is empty. */
class AgItem(val header: String?, val ev: Ev?)

/** Reads events from Android's calendar database, which is where ICSx5 puts a subscribed Proton calendar. */
object Cal {
    val zone: ZoneId get() = ZoneId.systemDefault()

    fun granted(c: Context) = c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun day(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    fun startOf(d: LocalDate): Long = d.atStartOfDay(zone).toInstant().toEpochMilli()
    private fun utcMidnightToLocal(ms: Long): Long = startOf(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate())

    fun calendars(c: Context): List<CalInfo> {
        if (!granted(c)) return emptyList()
        val out = ArrayList<CalInfo>()
        try {
            val cr = CalendarContract.Calendars.CONTENT_URI
            val proj = arrayOf(
                CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                CalendarContract.Calendars.ACCOUNT_NAME, CalendarContract.Calendars.CALENDAR_COLOR
            )
            c.contentResolver.query(cr, proj, null, null, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)?.use { cur ->
                while (cur.moveToNext()) out.add(CalInfo(cur.getLong(0), cur.getString(1) ?: "Calendar", cur.getString(2) ?: "", cur.getInt(3)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun events(c: Context, fromMs: Long, toMs: Long, cfg: CalCfg): List<Ev> {
        if (!granted(c)) return emptyList()
        val out = ArrayList<Ev>()
        try {
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, fromMs - 86_400_000L)
            ContentUris.appendId(b, toMs + 86_400_000L)
            val proj = arrayOf(
                CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END, CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.CALENDAR_COLOR,
                CalendarContract.Instances.EVENT_COLOR, CalendarContract.Instances.EVENT_LOCATION
            )
            val ids = cfg.cals.filter { it.isDigit() || it == ',' }.trim(',')
            val sel = if (ids.isEmpty()) null else CalendarContract.Instances.CALENDAR_ID + " IN (" + ids + ")"
            c.contentResolver.query(b.build(), proj, sel, null, CalendarContract.Instances.BEGIN + " ASC")?.use { cur ->
                while (cur.moveToNext()) {
                    val allDay = cur.getInt(4) == 1
                    var s = cur.getLong(2)
                    var e = cur.getLong(3)
                    if (allDay) {
                        s = utcMidnightToLocal(s)
                        e = utcMidnightToLocal(e)
                    }
                    if (e <= fromMs && !(e == s && s >= fromMs)) continue
                    if (s >= toMs) continue
                    if (allDay && !cfg.allDay) continue
                    val col = if (!cur.isNull(6) && cur.getInt(6) != 0) cur.getInt(6) else cur.getInt(5)
                    out.add(Ev(cur.getLong(0), cur.getString(1)?.ifBlank { null } ?: "(no title)", s, e, allDay, if (col == 0) 0xFF6C8EEF.toInt() else col, cur.getString(7) ?: ""))
                }
            }
        } catch (e: Exception) {
        }
        return out.sortedWith(compareBy({ it.begin }, { it.title }))
    }

    /** Does the event touch this day? */
    fun onDay(e: Ev, d: LocalDate): Boolean {
        val s = day(e.begin)
        val last = if (e.end > e.begin) day(e.end - 1) else s
        return !d.isBefore(s) && !d.isAfter(last)
    }

    fun sample(): List<Ev> {
        val now = System.currentTimeMillis()
        val today = LocalDate.now(zone)
        fun at(dayOff: Long, h: Int, m: Int) = today.plusDays(dayOff).atTime(h, m).atZone(zone).toInstant().toEpochMilli()
        return listOf(
            Ev(1, "Stand-up", at(0, 9, 30), at(0, 10, 0), false, 0xFF6C8EEF.toInt(), ""),
            Ev(2, "Lunch with Sam", at(0, 12, 0), at(0, 13, 0), false, 0xFF4CAF7D.toInt(), "Mellow Mushroom"),
            Ev(3, "Mix review", at(1, 15, 0), at(1, 16, 30), false, 0xFFE0A030.toInt(), ""),
            Ev(4, "Rent due", startOf(today.plusDays(2)), startOf(today.plusDays(3)), true, 0xFFD16B6B.toInt(), ""),
            Ev(5, "Studio session", at(3, 18, 0), at(3, 21, 0), false, 0xFF6C8EEF.toInt(), "")
        ).filter { it.end > now - 86_400_000L }
    }

    fun agenda(evs: List<Ev>, days: Int, now: Long): List<AgItem> {
        val out = ArrayList<AgItem>()
        val today = LocalDate.now(zone)
        val fmt = DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault())
        for (i in 0 until days) {
            val d = today.plusDays(i.toLong())
            val list = evs.filter { onDay(it, d) && (i > 0 || it.end > now || it.allDay) }
            if (list.isEmpty() && i > 0) continue
            val label = when (i) {
                0 -> "Today · " + d.format(fmt)
                1 -> "Tomorrow · " + d.format(fmt)
                else -> d.format(fmt)
            }
            out.add(AgItem(label, null))
            if (list.isEmpty()) out.add(AgItem(null, null)) else list.forEach { out.add(AgItem(null, it)) }
        }
        return out
    }
}

/** The month shown and the day picked on a month widget, kept per widget. */
object CalState {
    fun month(c: Context, id: Int): YearMonth {
        val v = Store.getLong(c, "calmon_$id", -1L)
        return if (v < 0) YearMonth.now(Cal.zone) else YearMonth.of((v / 12).toInt(), (v % 12).toInt() + 1)
    }

    fun setMonth(c: Context, id: Int, ym: YearMonth) {
        Store.putLong(c, "calmon_$id", ym.year * 12L + (ym.monthValue - 1))
    }

    fun selected(c: Context, id: Int): LocalDate {
        val v = Store.getLong(c, "calsel_$id", Long.MIN_VALUE)
        return if (v == Long.MIN_VALUE) LocalDate.now(Cal.zone) else LocalDate.ofEpochDay(v)
    }

    fun setSelected(c: Context, id: Int, d: LocalDate) {
        Store.putLong(c, "calsel_$id", d.toEpochDay())
    }

    fun gridStart(ym: YearMonth, weekStart: Int): LocalDate {
        val first = ym.atDay(1)
        val offset = ((first.dayOfWeek.value % 7) - weekStart + 7) % 7
        return first.minusDays(offset.toLong())
    }

    fun rows(ym: YearMonth, weekStart: Int): Int {
        val first = ym.atDay(1)
        val offset = ((first.dayOfWeek.value % 7) - weekStart + 7) % 7
        return (offset + ym.lengthOfMonth() + 6) / 7
    }
}

/** Where the last full picture put the list or grid, so the scrolling parts can match it. */
object CalGeom {
    class G(val dens: Float, val listW: Float, val cellW: Float, val cellH: Float)

    fun save(c: Context, id: Int, g: G) {
        Store.putStr(c, "calg_$id", "${g.dens},${g.listW},${g.cellW},${g.cellH}")
    }

    fun load(c: Context, id: Int): G? {
        val v = (Store.getStr(c, "calg_$id") ?: "").split(",").mapNotNull { it.toFloatOrNull() }
        return if (v.size == 4) G(v[0], v[1], v[2], v[3]) else null
    }
}

class CalFrame(
    val bmp: Bitmap, val listRect: RectF?, val gridRect: RectF?, val headRect: RectF?,
    val cellW: Float, val cellH: Float, val sig: String
)

/** Fonts, colors and drawing for every calendar piece, shared by the picture and the scrolling lists. */
class CalEnv(val c: Context, val st: Style, val cfg: CalCfg, val d: Float) {
    val ts = st.textScale / 100f
    val pal = Palette.of(c, st)
    val base: Typeface = FontStore.typeface(c, st.font)
    val bold: Typeface = Typeface.create(base, Typeface.BOLD)
    private val p = Widgets.paint()
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    val is24 = DateFormat.is24HourFormat(c)

    fun timeText(ms: Long): String = DateFormat.getTimeFormat(c).format(Date(ms))

    fun when_(e: Ev): String = if (e.allDay) "All day" else timeText(e.begin) + " – " + timeText(e.end)

    private fun fit(text: String, maxW: Float): String = TextUtils.ellipsize(text, tp, maxW, TextUtils.TruncateAt.END).toString()

    fun agendaItemH(it: AgItem, hasLoc: Boolean): Float = when {
        it.header != null -> 30f * d * ts.coerceAtLeast(0.9f)
        it.ev == null -> 34f * d
        hasLoc && it.ev.loc.isNotEmpty() -> 58f * d * ts.coerceAtLeast(0.9f)
        else -> 46f * d * ts.coerceAtLeast(0.9f)
    }

    fun drawAgendaItem(cv: Canvas, it: AgItem, w: Float, h: Float) {
        val pad = 4f * d
        if (it.header != null) {
            tp.typeface = bold
            tp.textSize = 12f * d * ts
            tp.color = pal.accent
            tp.textAlign = Paint.Align.LEFT
            cv.drawText(fit(it.header.uppercase(Locale.getDefault()), w - 2 * pad), pad, h * 0.74f, tp)
            return
        }
        val e = it.ev
        if (e == null) {
            tp.typeface = base
            tp.textSize = 13f * d * ts
            tp.color = Widgets.alpha(pal.text, 130)
            tp.textAlign = Paint.Align.LEFT
            cv.drawText("Nothing planned", pad + 10f * d, h * 0.62f, tp)
            return
        }
        val barW = 4f * d
        p.style = Paint.Style.FILL
        p.color = e.color
        cv.drawRoundRect(RectF(pad, 4f * d, pad + barW, h - 4f * d), barW / 2, barW / 2, p)
        val x = pad + barW + 10f * d
        val room = w - x - pad
        tp.textAlign = Paint.Align.LEFT
        tp.typeface = bold
        tp.textSize = 14.5f * d * ts
        tp.color = pal.text
        val showLoc = cfg.loc && e.loc.isNotEmpty()
        val lines = if (showLoc) 3 else 2
        val lh = (h - 8f * d) / lines
        var y = 4f * d + lh * 0.78f
        cv.drawText(fit(e.title, room), x, y, tp)
        tp.typeface = base
        tp.textSize = 12f * d * ts
        tp.color = Widgets.alpha(pal.text, 175)
        y += lh
        cv.drawText(fit(when_(e), room), x, y, tp)
        if (showLoc) {
            tp.color = Widgets.alpha(pal.text, 120)
            y += lh
            cv.drawText(fit(e.loc, room), x, y, tp)
        }
    }

    /** One square of the month grid. */
    fun drawCell(cv: Canvas, day: LocalDate, w: Float, h: Float, selected: Boolean, today: Boolean, inMonth: Boolean, dots: List<Int>) {
        val cx = w / 2f
        val r = minOf(w, h) * 0.36f
        val cy = h * 0.42f
        p.style = Paint.Style.FILL
        if (selected) {
            p.color = Widgets.alpha(pal.accent, 70)
            cv.drawCircle(cx, cy, r, p)
        }
        if (today) {
            p.color = pal.accent
            cv.drawCircle(cx, cy, r * 0.92f, p)
        }
        tp.typeface = if (today || selected) bold else base
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = minOf(14f * d * ts, r * 1.25f)
        tp.color = if (today) (if (luma(pal.accent) > 0.6f) 0xFF14161A.toInt() else Color.WHITE)
        else Widgets.alpha(pal.text, if (inMonth) 235 else 90)
        cv.drawText(day.dayOfMonth.toString(), cx, cy + tp.textSize * 0.36f, tp)
        val n = dots.size.coerceAtMost(3)
        val dr = (minOf(w, h) * 0.05f).coerceAtLeast(1.6f * d)
        for (i in 0 until n) {
            p.color = dots[i]
            cv.drawCircle(cx + (i - (n - 1) / 2f) * dr * 2.8f, h * 0.88f, dr, p)
        }
    }

    private fun luma(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    // ---------- the pieces drawn straight into the widget picture ----------

    fun card(cv: Canvas, w: Float, h: Float) {
        if (st.bgOpacity > 0) {
            p.style = Paint.Style.FILL
            p.color = Widgets.alpha(pal.bg, st.bgOpacity * 255 / 100)
            val r = (st.corner * d).coerceAtMost(minOf(w, h) / 2f)
            cv.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        }
    }

    fun title(cv: Canvas, text: String, right: String?, x0: Float, x1: Float, baseY: Float) {
        tp.typeface = bold
        tp.textSize = 16f * d * ts
        tp.color = pal.text
        tp.textAlign = Paint.Align.LEFT
        cv.drawText(fit(text, (x1 - x0) * 0.7f), x0, baseY, tp)
        if (right != null) {
            tp.typeface = base
            tp.textSize = 12.5f * d * ts
            tp.color = Widgets.alpha(pal.text, 150)
            tp.textAlign = Paint.Align.RIGHT
            cv.drawText(fit(right, (x1 - x0) * 0.45f), x1, baseY, tp)
        }
    }

    fun nextUp(cv: Canvas, evs: List<Ev>, w: Float, h: Float, now: Long) {
        val pad = 16f * d
        val list = evs.filter { it.end > now || (it.end == it.begin && it.begin >= now) }.filter { !(it.allDay && Cal.day(it.begin).isBefore(LocalDate.now(Cal.zone))) }
        tp.textAlign = Paint.Align.LEFT
        if (list.isEmpty()) {
            tp.typeface = bold
            tp.textSize = 17f * d * ts
            tp.color = pal.text
            cv.drawText("No upcoming events", pad, h / 2f, tp)
            tp.typeface = base
            tp.textSize = 12.5f * d * ts
            tp.color = Widgets.alpha(pal.text, 140)
            cv.drawText(if (Cal.granted(c)) "Nothing in the next " + cfg.days + " days" else "Allow Calendar access in the app", pad, h / 2f + 20f * d * ts, tp)
            return
        }
        val e = list[0]
        val nowOn = e.begin <= now && !e.allDay
        p.style = Paint.Style.FILL
        p.color = e.color
        cv.drawRoundRect(RectF(pad, pad, pad + 5f * d, h - pad), 2.5f * d, 2.5f * d, p)
        val x = pad + 5f * d + 12f * d
        val room = w - x - pad
        var y = pad + 12f * d * ts
        tp.typeface = bold
        tp.textSize = 11.5f * d * ts
        tp.color = pal.accent
        cv.drawText((if (nowOn) "HAPPENING NOW" else "NEXT UP"), x, y + 3f * d, tp)
        y += 10f * d
        tp.typeface = bold
        tp.textSize = 21f * d * ts
        tp.color = pal.text
        val lay = StaticLayout.Builder.obtain(e.title, 0, e.title.length, tp, room.toInt().coerceAtLeast(10))
            .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
        cv.save()
        cv.translate(x, y)
        lay.draw(cv)
        cv.restore()
        y += lay.height + 8f * d
        tp.typeface = base
        tp.textSize = 13.5f * d * ts
        tp.color = Widgets.alpha(pal.text, 215)
        val dayLabel = when (Cal.day(e.begin)) {
            LocalDate.now(Cal.zone) -> "Today"
            LocalDate.now(Cal.zone).plusDays(1) -> "Tomorrow"
            else -> Cal.day(e.begin).format(DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault()))
        }
        cv.drawText(fit(dayLabel + " · " + when_(e), room), x, y + 10f * d, tp)
        y += 22f * d * ts
        val mins = ((e.begin - now) / 60000L)
        val counter = when {
            nowOn -> "Ends " + timeText(e.end)
            e.allDay -> null
            mins < 1 -> "Starting now"
            mins < 60 -> "in $mins min"
            mins < 24 * 60 -> "in " + (mins / 60) + " h" + (if (mins % 60 != 0L) " " + (mins % 60) + " m" else "")
            else -> null
        }
        if (counter != null) {
            tp.typeface = bold
            tp.textSize = 13.5f * d * ts
            tp.color = pal.accent
            cv.drawText(counter, x, y + 10f * d, tp)
            y += 22f * d * ts
        }
        if (cfg.loc && e.loc.isNotEmpty()) {
            tp.typeface = base
            tp.textSize = 12.5f * d * ts
            tp.color = Widgets.alpha(pal.text, 140)
            cv.drawText(fit(e.loc, room), x, y + 10f * d, tp)
        }
        val then = list.getOrNull(1)
        if (then != null && h - y > 70f * d) {
            tp.typeface = base
            tp.textSize = 12f * d * ts
            tp.color = Widgets.alpha(pal.text, 130)
            cv.drawText(fit("Then  " + then.title + " · " + (if (then.allDay) "All day" else timeText(then.begin)), room), x, h - pad - 2f * d, tp)
        }
    }
}

object CalRenderer {
    /** inline = true draws the list or grid into the picture too (for previews); false leaves room for the scrolling versions. */
    fun render(c: Context, st: Style, cfg: CalCfg, id: Int, wPx: Int, hPx: Int, inline: Boolean): CalFrame {
        val (bmp, cv) = Widgets.blank(wPx, hPx)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val d = Widgets.density(c)
        val env = CalEnv(c, st, cfg, d)
        env.card(cv, w, h)
        val now = System.currentTimeMillis()
        val zone = Cal.zone
        val real = Cal.granted(c)
        val pad = 14f * d
        val head = 34f * d
        val today = LocalDate.now(zone)
        val sigBase = listOf(cfg.style, cfg.days, cfg.weekStart, cfg.loc, cfg.allDay, cfg.cals, wPx, hPx, st.toJson().toString().hashCode()).joinToString("|")

        fun evs(from: Long, to: Long): List<Ev> {
            val l = if (real) Cal.events(c, from, to, cfg) else Cal.sample()
            return l
        }

        when (cfg.style) {
            1 -> {
                val list = evs(now - 3_600_000L, now + cfg.days * 86_400_000L)
                env.nextUp(cv, list, w, h, now)
                return CalFrame(bmp, null, null, null, 0f, 0f, sigBase + "|" + list.hashCode0())
            }
            2 -> {
                val ym = if (id >= 0) CalState.month(c, id) else YearMonth.now(zone)
                val sel = if (id >= 0) CalState.selected(c, id) else today
                val rows = CalState.rows(ym, cfg.weekStart)
                val start = CalState.gridStart(ym, cfg.weekStart)
                val list = evs(Cal.startOf(start), Cal.startOf(start.plusDays(rows * 7L)))
                val strip = maxOf(70f * d, h * 0.26f)
                val dow = 18f * d
                val gridTop = pad + head + dow
                val cellW = (w - 2 * pad) / 7f
                val cellH = ((h - pad - strip - gridTop) / rows).coerceIn(14f * d, cellW * 1.05f)
                val gridRect = RectF(pad, gridTop, w - pad, gridTop + cellH * rows)
                val headRect = RectF(pad, pad, w - pad, pad + head)
                // title and arrows
                env.title(cv, ym.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault())), null, pad + 4f * d, w - pad - 80f * d, pad + head * 0.68f)
                val ap = Widgets.paint()
                ap.style = Paint.Style.STROKE
                ap.strokeWidth = 2.2f * d
                ap.strokeCap = Paint.Cap.ROUND
                ap.color = Widgets.alpha(env.pal.text, 190)
                val ay = pad + head * 0.5f
                for ((cx, dir) in listOf(w - pad - 56f * d to -1f, w - pad - 14f * d to 1f)) {
                    cv.drawLine(cx - 4f * d * dir, ay - 7f * d, cx + 4f * d * dir, ay, ap)
                    cv.drawLine(cx + 4f * d * dir, ay, cx - 4f * d * dir, ay + 7f * d, ap)
                }
                // weekday letters
                val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
                tp.typeface = env.base
                tp.textAlign = Paint.Align.CENTER
                tp.textSize = 11f * d * env.ts
                tp.color = Widgets.alpha(env.pal.text, 140)
                for (i in 0 until 7) {
                    val dd = start.plusDays(i.toLong())
                    cv.drawText(dd.dayOfWeek.getDisplayName(java.time.format.TextStyle.NARROW, Locale.getDefault()), pad + cellW * (i + 0.5f), gridTop - 5f * d, tp)
                }
                if (inline) {
                    for (i in 0 until rows * 7) {
                        val dd = start.plusDays(i.toLong())
                        val dots = list.filter { Cal.onDay(it, dd) }.map { it.color }
                        cv.save()
                        cv.translate(pad + (i % 7) * cellW, gridTop + (i / 7) * cellH)
                        env.drawCell(cv, dd, cellW, cellH, dd == sel, dd == today, dd.month == ym.month, dots)
                        cv.restore()
                    }
                }
                // the picked day's events
                val sy = gridRect.bottom + 6f * d
                val tp2 = TextPaint(Paint.ANTI_ALIAS_FLAG)
                tp2.typeface = env.bold
                tp2.textSize = 12f * d * env.ts
                tp2.color = env.pal.accent
                tp2.textAlign = Paint.Align.LEFT
                cv.drawText(sel.format(DateTimeFormatter.ofPattern("EEEE, MMM d", Locale.getDefault())).uppercase(Locale.getDefault()), pad + 4f * d, sy + 12f * d, tp2)
                val dayEvs = list.filter { Cal.onDay(it, sel) }
                var y = sy + 12f * d
                val lineH = 17f * d * env.ts.coerceAtLeast(0.9f)
                val maxLines = ((h - pad - y) / lineH).toInt().coerceAtLeast(1)
                if (dayEvs.isEmpty()) {
                    tp2.typeface = env.base
                    tp2.color = Widgets.alpha(env.pal.text, 130)
                    tp2.textSize = 13f * d * env.ts
                    cv.drawText("Nothing planned", pad + 4f * d, y + lineH, tp2)
                } else {
                    val shown = if (dayEvs.size > maxLines) maxLines - 1 else dayEvs.size
                    val pp = Widgets.paint()
                    for (k in 0 until shown) {
                        val e = dayEvs[k]
                        y += lineH
                        pp.color = e.color
                        cv.drawCircle(pad + 8f * d, y - 4.5f * d, 3.4f * d, pp)
                        tp2.typeface = env.base
                        tp2.textSize = 13f * d * env.ts
                        tp2.color = env.pal.text
                        val tm = if (e.allDay) "" else env.timeText(e.begin) + "  "
                        cv.drawText(TextUtils.ellipsize(tm + e.title, tp2, w - 2 * pad - 24f * d, TextUtils.TruncateAt.END).toString(), pad + 18f * d, y, tp2)
                    }
                    if (dayEvs.size > shown) {
                        y += lineH
                        tp2.color = Widgets.alpha(env.pal.text, 140)
                        cv.drawText("+" + (dayEvs.size - shown) + " more", pad + 18f * d, y, tp2)
                    }
                }
                val sig = sigBase + "|" + ym + "|" + sel + "|" + list.hashCode0()
                return CalFrame(bmp, null, gridRect, headRect, cellW, cellH, sig)
            }
            else -> {
                val list = evs(now - 3_600_000L, Cal.startOf(today.plusDays(cfg.days.toLong())))
                val items = Cal.agenda(list, cfg.days, now)
                env.title(cv, "Agenda", today.format(DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault())), pad + 4f * d, w - pad - 4f * d, pad + head * 0.68f)
                val listRect = RectF(pad, pad + head, w - pad, h - pad)
                if (inline) {
                    var y = listRect.top
                    for (it in items) {
                        val ih = env.agendaItemH(it, cfg.loc)
                        if (y + ih > listRect.bottom) break
                        cv.save()
                        cv.translate(listRect.left, y)
                        env.drawAgendaItem(cv, it, listRect.width(), ih)
                        cv.restore()
                        y += ih
                    }
                }
                return CalFrame(bmp, listRect, null, null, 0f, 0f, sigBase + "|" + list.hashCode0())
            }
        }
    }

    private fun List<Ev>.hashCode0(): Int {
        var h = 7
        for (e in this) h = h * 31 + (e.id.toInt() * 17 + e.title.hashCode() + e.begin.hashCode() + e.end.hashCode())
        return h
    }
}

class CalWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(c, m, it) }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, opts: android.os.Bundle?) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        ids.forEach { Store.deleteInst(c, it) }
    }

    override fun onEnabled(c: Context) {
        Live.ensure(c)
    }

    override fun onDisabled(c: Context) {
        if (!Widgets.any(c)) Live.stop(c)
    }

    companion object {
        fun update(c: Context, m: AppWidgetManager, id: Int, force: Boolean = false) {
            try {
                val inst = Store.inst(c, id)
                val st = Widgets.style(c, inst)
                val (bw, bh) = Widgets.sizePx(c, m, id, Widgets.CAL)
                val fit = Widgets.fit(c, Widgets.CAL, inst, bw, bh)
                val f = Widgets.withDensity(fit.dens) { CalRenderer.render(c, st, inst.cal, id, fit.w, fit.h, false) }
                val rv = RemoteViews(c.packageName, R.layout.widget_cal)
                rv.setImageViewBitmap(R.id.img, f.bmp)
                val launch = openCalendar(c)
                rv.setOnClickPendingIntent(R.id.bg, PendingIntent.getActivity(c, id, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                val mutable = PendingIntent.getActivity(c, id + 100000, launch, PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

                val dens = fit.dens ?: c.resources.displayMetrics.density
                val lr = f.listRect
                val gr = f.gridRect
                val hr = f.headRect
                CalGeom.save(c, id, CalGeom.G(dens, lr?.width() ?: 0f, f.cellW, f.cellH))

                area(rv, R.id.abox, lr, fit)
                if (lr != null) {
                    rv.setRemoteAdapter(R.id.alist, Intent(c, CalAgendaService::class.java).setAction("app.widgets.CAL_A").putExtra("id", id).also { it.data = Uri.parse(it.toUri(Intent.URI_INTENT_SCHEME)) })
                    rv.setPendingIntentTemplate(R.id.alist, mutable)
                }
                area(rv, R.id.gbox, gr, fit)
                if (gr != null) {
                    rv.setRemoteAdapter(R.id.grid, Intent(c, CalGridService::class.java).setAction("app.widgets.CAL_G").putExtra("id", id).also { it.data = Uri.parse(it.toUri(Intent.URI_INTENT_SCHEME)) })
                    rv.setPendingIntentTemplate(R.id.grid, PendingIntent.getBroadcast(c, id * 8 + 7, Intent(c, CalAction::class.java).putExtra("id", id), PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                }
                area(rv, R.id.mhead, hr, fit)
                if (hr != null) {
                    fun pi(op: String, k: Int) = PendingIntent.getBroadcast(
                        c, id * 8 + k, Intent(c, CalAction::class.java).putExtra("id", id).putExtra("op", op),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    rv.setOnClickPendingIntent(R.id.mprev, pi("prev", 1))
                    rv.setOnClickPendingIntent(R.id.mtoday, pi("today", 2))
                    rv.setOnClickPendingIntent(R.id.mnext, pi("next", 3))
                }
                m.updateAppWidget(id, rv)
                if (force || f.sig != (Store.getStr(c, "calsig_$id") ?: "")) {
                    Store.putStr(c, "calsig_$id", f.sig)
                    m.notifyAppWidgetViewDataChanged(id, R.id.alist)
                    m.notifyAppWidgetViewDataChanged(id, R.id.grid)
                }
            } catch (e: Exception) {
            }
        }

        private fun area(rv: RemoteViews, box: Int, r: RectF?, fit: Widgets.Fit) {
            if (r == null) {
                rv.setViewVisibility(box, View.GONE)
                return
            }
            rv.setViewVisibility(box, View.VISIBLE)
            rv.setViewPadding(box, fit.offX + r.left.toInt(), fit.offY + r.top.toInt(), fit.offX + (fit.w - r.right).toInt(), fit.offY + (fit.h - r.bottom).toInt())
        }

        /** Proton Calendar if it's installed, otherwise whatever calendar app the phone has. */
        fun openCalendar(c: Context): Intent {
            for (pkg in listOf("me.proton.android.calendar", "ch.protonmail.android.calendar")) {
                c.packageManager.getLaunchIntentForPackage(pkg)?.let { return it }
            }
            val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time").also { ContentUris.appendId(it, System.currentTimeMillis()) }.build()
            val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return if (i.resolveActivity(c.packageManager) != null) i else Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            Widgets.ids(c, Widgets.CAL).forEach { update(c, m, it) }
        }

        /** Once a minute: keeps the "next up" countdown honest. */
        fun tick(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in Widgets.ids(c, Widgets.CAL)) if (Store.inst(c, id).cal.style == 1) update(c, m, id)
        }
    }
}

/** Month arrows, "today", and tapping a day. */
class CalAction : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        if (id < 0) return
        val cfg = Store.inst(c, id).cal
        val ym = CalState.month(c, id)
        val today = LocalDate.now(Cal.zone)
        when (i.getStringExtra("op")) {
            "prev", "next" -> {
                val n = if (i.getStringExtra("op") == "prev") ym.minusMonths(1) else ym.plusMonths(1)
                CalState.setMonth(c, id, n)
                CalState.setSelected(c, id, if (YearMonth.from(today) == n) today else n.atDay(1))
            }
            "today" -> {
                CalState.setMonth(c, id, YearMonth.from(today))
                CalState.setSelected(c, id, today)
            }
            "day" -> {
                val d = LocalDate.ofEpochDay(i.getLongExtra("epochDay", today.toEpochDay()))
                CalState.setSelected(c, id, d)
                CalState.setMonth(c, id, YearMonth.from(d))
            }
        }
        if (cfg.haptic) {
            try {
                c.getSystemService(android.os.Vibrator::class.java)?.vibrate(android.os.VibrationEffect.createPredefined(android.os.VibrationEffect.EFFECT_TICK))
            } catch (e: Exception) {
            }
        }
        val pending = goAsync()
        val ctx = c.applicationContext
        Thread {
            try {
                CalWidget.update(ctx, AppWidgetManager.getInstance(ctx), id, true)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

class CalAgendaService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = AgendaFactory(applicationContext, intent.getIntExtra("id", -1))

    private class AgendaFactory(val c: Context, val id: Int) : RemoteViewsFactory {
        var env: CalEnv? = null
        var items: List<AgItem> = emptyList()
        var geom: CalGeom.G? = null

        override fun onCreate() {}
        override fun onDataSetChanged() {
            val inst = Store.inst(c, id)
            geom = CalGeom.load(c, id)
            val g = geom ?: return
            env = CalEnv(c, Widgets.style(c, inst), inst.cal, g.dens)
            val now = System.currentTimeMillis()
            val evs = if (Cal.granted(c)) Cal.events(c, now - 3_600_000L, Cal.startOf(LocalDate.now(Cal.zone).plusDays(inst.cal.days.toLong())), inst.cal) else Cal.sample()
            items = Cal.agenda(evs, inst.cal.days, now)
        }

        override fun onDestroy() {}
        override fun getCount() = items.size
        override fun getViewAt(i: Int): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.item_cal)
            val e = env
            val g = geom
            if (e != null && g != null && i < items.size) {
                val h = e.agendaItemH(items[i], e.cfg.loc)
                val bmp = Bitmap.createBitmap(g.listW.toInt().coerceAtLeast(1), h.toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                e.drawAgendaItem(Canvas(bmp), items[i], g.listW, h)
                rv.setImageViewBitmap(R.id.item, bmp)
            }
            rv.setOnClickFillInIntent(R.id.item, Intent())
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(i: Int) = 3000L + i
        override fun hasStableIds() = false
    }
}

class CalGridService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = GridFactory(applicationContext, intent.getIntExtra("id", -1))

    private class GridFactory(val c: Context, val id: Int) : RemoteViewsFactory {
        var env: CalEnv? = null
        var geom: CalGeom.G? = null
        var start: LocalDate = LocalDate.now()
        var cells = 0
        var ym: YearMonth = YearMonth.now()
        var sel: LocalDate = LocalDate.now()
        var evs: List<Ev> = emptyList()

        override fun onCreate() {}
        override fun onDataSetChanged() {
            val inst = Store.inst(c, id)
            geom = CalGeom.load(c, id)
            val g = geom ?: return
            env = CalEnv(c, Widgets.style(c, inst), inst.cal, g.dens)
            ym = CalState.month(c, id)
            sel = CalState.selected(c, id)
            start = CalState.gridStart(ym, inst.cal.weekStart)
            cells = CalState.rows(ym, inst.cal.weekStart) * 7
            evs = if (Cal.granted(c)) Cal.events(c, Cal.startOf(start), Cal.startOf(start.plusDays(cells.toLong())), inst.cal) else Cal.sample()
        }

        override fun onDestroy() {}
        override fun getCount() = cells
        override fun getViewAt(i: Int): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.item_cal_cell)
            val e = env
            val g = geom
            val day = start.plusDays(i.toLong())
            if (e != null && g != null) {
                val bmp = Bitmap.createBitmap(g.cellW.toInt().coerceAtLeast(1), g.cellH.toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                val dots = evs.filter { Cal.onDay(it, day) }.map { it.color }
                e.drawCell(Canvas(bmp), day, g.cellW, g.cellH, day == sel, day == LocalDate.now(Cal.zone), day.month == ym.month, dots)
                rv.setImageViewBitmap(R.id.cell, bmp)
            }
            rv.setOnClickFillInIntent(R.id.cell, Intent().putExtra("op", "day").putExtra("epochDay", day.toEpochDay()))
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(i: Int) = 4000L + i
        override fun hasStableIds() = false
    }
}
