package app.widgets

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.IBinder

object Live {
    fun ensure(c: Context) {
        if (!Store.live(c)) return
        try {
            c.startForegroundService(Intent(c, LiveService::class.java))
        } catch (e: Exception) {
        }
    }

    fun stop(c: Context) {
        try {
            c.stopService(Intent(c, LiveService::class.java))
        } catch (e: Exception) {
        }
    }
}

/** Keeps the widgets in step with ringer changes made elsewhere and with light/dark or wallpaper color changes. */
class LiveService : Service() {
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val ctx = applicationContext
            if (i.action == AudioManager.RINGER_MODE_CHANGED_ACTION) {
                RingerWidget.refresh(ctx)
            } else if (i.action == "app.widgets.TICK") {
                CalWidget.tick(ctx)
            } else {
                Widgets.updateAll(ctx)
                Wx.refreshAll(ctx, false)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("live", "Widgets", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "live")
            .setSmallIcon(R.drawable.ic_ring)
            .setContentTitle("Widgets are live")
            .setContentText("Keeps your widgets accurate")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(4, n)
        }
        val f = IntentFilter().apply {
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(Intent.ACTION_CONFIGURATION_CHANGED)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rx, f)
        val tf = IntentFilter("app.widgets.TICK")
        registerReceiver(rx, tf, Context.RECEIVER_NOT_EXPORTED)
        tick.run()
        try {
            contentResolver.registerContentObserver(android.provider.CalendarContract.CONTENT_URI, true, obs)
        } catch (e: Exception) {
        }
    }

    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (Widgets.ids(applicationContext, Widgets.CAL).isNotEmpty()) CalWidget.tick(applicationContext)
            main.postDelayed(this, 60_000L)
        }
    }
    private val obs = object : android.database.ContentObserver(main) {
        override fun onChange(selfChange: Boolean) {
            main.removeCallbacks(calPush)
            main.postDelayed(calPush, 1500)
        }
    }
    private val calPush = Runnable { CalWidget.updateAll(applicationContext) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try {
            contentResolver.unregisterContentObserver(obs)
        } catch (e: Exception) {
        }
        try {
            unregisterReceiver(rx)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            Live.ensure(c)
            Widgets.updateAll(c)
        }
    }
}
