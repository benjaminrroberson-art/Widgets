package app.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.notification.NotificationListenerService
import android.text.TextPaint
import android.text.TextUtils
import android.widget.RemoteViews

/** A snapshot of whatever is playing. */
class Np(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean,
    val pos: Long,
    val dur: Long,
    val pkg: String,
    val canLike: Boolean,
    val liked: Boolean,
    val canShuffle: Boolean,
    val shuffleOn: Boolean,
    val canRepeat: Boolean,
    val repeatOn: Boolean,
    val session: PendingIntent?
)

object NpState {
    private val likeKeys = listOf("like", "heart", "favorite", "favourite", "love", "thumb", "save", "add to")
    private val unlikeKeys = listOf("unlike", "remove", "unfav", "unsave", "liked", "saved")

    private fun cn(c: Context) = ComponentName(c, MediaListener::class.java)

    fun granted(c: Context): Boolean =
        android.provider.Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners")
            ?.contains(c.packageName) == true

    fun controllers(c: Context): List<MediaController> = try {
        c.getSystemService(MediaSessionManager::class.java).getActiveSessions(cn(c))
    } catch (e: Exception) {
        emptyList()
    }

    fun controller(c: Context): MediaController? {
        val l = controllers(c)
        return l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING && it.metadata != null }
            ?: l.firstOrNull { it.metadata != null }
    }

    private fun action(st: PlaybackState?, keys: List<String>, not: List<String> = emptyList()): PlaybackState.CustomAction? =
        st?.customActions?.firstOrNull { a ->
            val n = ((a.name?.toString() ?: "") + " " + a.action).lowercase()
            keys.any { n.contains(it) } && not.none { n.contains(it) }
        }

    fun likeAction(st: PlaybackState?) = action(st, likeKeys, listOf("dislike", "thumbs_down", "thumbs down", "thumbsdown"))
    fun shuffleAction(st: PlaybackState?) = action(st, listOf("shuffle"))
    fun repeatAction(st: PlaybackState?) = action(st, listOf("repeat"))

    private fun trackKey(pkg: String, t: String, a: String) = "$pkg|$t|$a"

    fun current(c: Context): Np? {
        val ctl = controller(c) ?: return null
        val md = ctl.metadata ?: return null
        val st = ctl.playbackState
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: return null
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val playing = st?.state == PlaybackState.STATE_PLAYING
        var pos = st?.position ?: 0L
        if (playing && st != null) {
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        if (dur > 0) pos = pos.coerceIn(0L, dur)
        val pkg = ctl.packageName
        val la = likeAction(st)
        val likedLabel = la != null && unlikeKeys.any { ((la.name?.toString() ?: "") + " " + la.action).lowercase().contains(it) }
        val key = trackKey(pkg, title, artist)
        val liked = likedLabel || Store.getStr(c, "np_liked") == key
        val acts = st?.actions ?: 0L
        val canShuffle = shuffleAction(st) != null || (acts and (8388608L or 524288L)) != 0L
        val canRepeat = repeatAction(st) != null || (acts and 262144L) != 0L
        return Np(
            title, artist, art, playing, pos, dur, pkg,
            la != null, liked,
            canShuffle, Store.getBool(c, "np_shuf_$pkg", false),
            canRepeat, Store.getBool(c, "np_rep_$pkg", false),
            ctl.sessionActivity
        )
    }

    fun toggleLiked(c: Context, np: Np) {
        val key = trackKey(np.pkg, np.title, np.artist)
        Store.putStr(c, "np_liked", if (Store.getStr(c, "np_liked") == key) "" else key)
    }

    private var sampleArt: Bitmap? = null

    fun sample(): Np {
        if (sampleArt == null) {
            val b = Bitmap.createBitmap(240, 240, Bitmap.Config.ARGB_8888)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = LinearGradient(0f, 0f, 240f, 240f, 0xFF5B7CFF.toInt(), 0xFFE0689A.toInt(), Shader.TileMode.CLAMP)
            Canvas(b).drawRect(0f, 0f, 240f, 240f, p)
            sampleArt = b
        }
        return Np("Song title", "Artist name", sampleArt, true, 84000, 215000, "", true, false, true, false, true, false, null)
    }
}

/** Needs Notification access. Once granted, the system keeps it alive and tells us when the music changes. */
class MediaListener : NotificationListenerService() {
    private val h = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var attached: List<MediaController> = emptyList()
    private var connected = false

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = changed()
        override fun onPlaybackStateChanged(state: PlaybackState?) = changed()
    }

    private val sessions = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        attach(list ?: emptyList())
        changed()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (Widgets.ids(applicationContext, Widgets.NP).isEmpty()) return
            val playing = attached.any { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            if (playing) {
                NowPlayingWidget.updateAll(applicationContext)
                h.postDelayed(this, 1000)
            }
        }
    }

    private fun changed() {
        NowPlayingWidget.updateAll(applicationContext)
        h.removeCallbacks(tick)
        h.postDelayed(tick, 1000)
    }

    private fun attach(list: List<MediaController>) {
        attached.forEach { try { it.unregisterCallback(cb) } catch (e: Exception) { } }
        attached = list
        list.forEach { try { it.registerCallback(cb, h) } catch (e: Exception) { } }
    }

    override fun onListenerConnected() {
        connected = true
        try {
            val m = getSystemService(MediaSessionManager::class.java)
            msm = m
            val cn = ComponentName(this, MediaListener::class.java)
            m.addOnActiveSessionsChangedListener(sessions, cn, h)
            attach(m.getActiveSessions(cn))
            changed()
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        connected = false
        try { msm?.removeOnActiveSessionsChangedListener(sessions) } catch (e: Exception) { }
        attach(emptyList())
    }
}

class NpFrame(val bmp: Bitmap, val slots: List<String>, val padL: Int, val padT: Int, val padR: Int, val padB: Int)

object NpRenderer {
    fun slots(cfg: NpCfg, np: Np?): List<String> {
        val l = ArrayList<String>()
        if (np == null) return l
        if (cfg.shuffleRepeat && np.canShuffle) l.add("shuffle")
        l.add("prev"); l.add("toggle"); l.add("next")
        if (cfg.shuffleRepeat && np.canRepeat) l.add("repeat")
        if (cfg.like && np.canLike) l.add("like")
        return l
    }

    /** A pleasant accent pulled from the cover: the most colourful pixels, lifted so it reads on dark. */
    fun artColor(b: Bitmap, fallback: Int): Int {
        return try {
            val s = Bitmap.createScaledBitmap(b, 12, 12, true)
            var r = 0f; var g = 0f; var bl = 0f; var wsum = 0f
            val hsv = FloatArray(3)
            for (x in 0 until 12) for (y in 0 until 12) {
                val px = s.getPixel(x, y)
                Color.colorToHSV(px, hsv)
                val w = hsv[1] * hsv[2] + 0.01f
                r += Color.red(px) * w; g += Color.green(px) * w; bl += Color.blue(px) * w; wsum += w
            }
            val avg = Color.rgb((r / wsum).toInt(), (g / wsum).toInt(), (bl / wsum).toInt())
            Color.colorToHSV(avg, hsv)
            hsv[1] = hsv[1].coerceIn(0.35f, 0.85f)
            hsv[2] = hsv[2].coerceIn(0.75f, 1f)
            Color.HSVToColor(hsv)
        } catch (e: Exception) {
            fallback
        }
    }

    private fun lum(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    fun render(c: Context, st: Style, cfg: NpCfg, np: Np?, wPx: Int, hPx: Int): NpFrame {
        val (bmp, cv) = Widgets.blank(wPx, hPx)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val d = c.resources.displayMetrics.density
        val ts = st.textScale / 100f
        val pal = Palette.of(c, st)
        val accent = if (cfg.artAccent && np?.art != null) artColor(np.art, pal.accent) else pal.accent
        val p = Widgets.paint()

        if (st.bgOpacity > 0) {
            p.color = Widgets.alpha(pal.bg, st.bgOpacity * 255 / 100)
            val r = (st.corner * d).coerceAtMost(minOf(w, h) / 2f)
            cv.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        }

        val pad = 14f * d
        val artS = minOf(h - 2 * pad, w * 0.42f).coerceAtLeast(1f)
        val artL = pad
        val artT = (h - artS) / 2f
        val artR = (st.corner * d * 0.6f).coerceAtMost(artS / 2f)
        val artRect = RectF(artL, artT, artL + artS, artT + artS)
        if (np?.art != null) {
            val a = np.art
            val sh = BitmapShader(a, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val sc = Math.max(artS / a.width, artS / a.height)
            val m = Matrix()
            m.setScale(sc, sc)
            m.postTranslate(artL + (artS - a.width * sc) / 2f, artT + (artS - a.height * sc) / 2f)
            sh.setLocalMatrix(m)
            p.shader = sh
            cv.drawRoundRect(artRect, artR, artR, p)
            p.shader = null
        } else {
            p.color = Widgets.alpha(pal.text, 28)
            cv.drawRoundRect(artRect, artR, artR, p)
            // a small music note
            val cx = artL + artS / 2f
            val cy = artT + artS / 2f
            val k = artS * 0.16f
            p.color = Widgets.alpha(pal.text, 120)
            cv.drawCircle(cx - k * 0.6f, cy + k * 0.9f, k * 0.62f, p)
            cv.drawRect(cx - k * 0.1f, cy - k * 1.3f, cx + k * 0.15f, cy + k * 0.9f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = k * 0.3f
            p.strokeCap = Paint.Cap.ROUND
            cv.drawLine(cx + k * 0.02f, cy - k * 1.2f, cx + k * 0.9f, cy - k * 0.5f, p)
            p.style = Paint.Style.FILL
        }

        val x0 = artL + artS + 14f * d
        val x1 = w - pad
        val avail = (x1 - x0).coerceAtLeast(10f)
        val base = FontStore.typeface(c, st.font)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)

        if (np == null) {
            tp.typeface = Typeface.create(base, Typeface.BOLD)
            tp.textSize = 17f * d * ts
            tp.color = pal.text
            cv.drawText(TextUtils.ellipsize("Nothing playing", tp, avail, TextUtils.TruncateAt.END).toString(), x0, h / 2f, tp)
            tp.typeface = base
            tp.textSize = 12.5f * d * ts
            tp.color = Widgets.alpha(pal.text, 150)
            val hint = if (NpState.granted(c)) "Start some music" else "Turn on Notification access in the app"
            cv.drawText(TextUtils.ellipsize(hint, tp, avail, TextUtils.TruncateAt.END).toString(), x0, h / 2f + 20f * d * ts, tp)
            return NpFrame(bmp, emptyList(), 0, 0, 0, 0)
        }

        val titleSize = 17f * d * ts
        val artistSize = 13f * d * ts
        tp.typeface = Typeface.create(base, Typeface.BOLD)
        tp.textSize = titleSize
        tp.color = pal.text
        val titleBase = minOf(artT, pad) + titleSize
        cv.drawText(TextUtils.ellipsize(np.title, tp, avail, TextUtils.TruncateAt.END).toString(), x0, titleBase, tp)
        tp.typeface = base
        tp.textSize = artistSize
        tp.color = Widgets.alpha(pal.text, 170)
        val artistBase = titleBase + artistSize * 1.45f
        cv.drawText(TextUtils.ellipsize(np.artist, tp, avail, TextUtils.TruncateAt.END).toString(), x0, artistBase, tp)

        val slots = slots(cfg, np)
        val ch = minOf(46f * d, (h - 2 * pad) * 0.36f)
        val ctlTop = h - pad - ch
        val ctlCy = ctlTop + ch / 2f

        // wavy progress, flat while paused
        val waveY = ctlTop - 13f * d
        if (cfg.progress && np.dur > 0 && waveY - 7f * d > artistBase + 4f * d) {
            val frac = (np.pos.toFloat() / np.dur).coerceIn(0f, 1f)
            val px = x0 + (x1 - x0) * frac
            val amp = if (np.playing) 3.2f * d else 0f
            val wl = 20f * d
            val path = Path()
            path.moveTo(x0, waveY)
            var x = x0
            while (x <= px) {
                path.lineTo(x, waveY + amp * Math.sin(((x - x0) / wl * 2 * Math.PI)).toFloat())
                x += 2f
            }
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.strokeWidth = 3.4f * d
            p.color = accent
            cv.drawPath(path, p)
            p.strokeWidth = 2.6f * d
            p.color = Widgets.alpha(pal.text, 55)
            cv.drawLine(px + 4f * d, waveY, x1, waveY, p)
            p.style = Paint.Style.FILL
            p.color = accent
            cv.drawRoundRect(RectF(px - 2f * d, waveY - 8f * d, px + 2f * d, waveY + 8f * d), 2f * d, 2f * d, p)
        }

        if (slots.isNotEmpty()) {
            val sw = (x1 - x0) / slots.size
            val s = ch * 0.46f
            for ((i, op) in slots.withIndex()) {
                val cx = x0 + sw * (i + 0.5f)
                if (op == "toggle") {
                    val bh = ch * 0.92f
                    val bw = minOf(sw * 0.94f, ch * 1.6f)
                    p.style = Paint.Style.FILL
                    p.color = accent
                    cv.drawRoundRect(RectF(cx - bw / 2, ctlCy - bh / 2, cx + bw / 2, ctlCy + bh / 2), bh / 2, bh / 2, p)
                    val ink = if (lum(accent) > 0.6f) 0xFF14161A.toInt() else Color.WHITE
                    glyph(cv, if (np.playing) "pause" else "play", cx, ctlCy, s * 1.05f, ink, false)
                } else {
                    val on = (op == "like" && np.liked) || (op == "shuffle" && np.shuffleOn) || (op == "repeat" && np.repeatOn)
                    val col = if (on) accent else Widgets.alpha(pal.text, 200)
                    glyph(cv, op, cx, ctlCy, s, col, on)
                }
            }
        }
        return NpFrame(bmp, slots, x0.toInt(), ctlTop.toInt(), (w - x1).toInt(), pad.toInt())
    }

    private fun glyph(cv: Canvas, op: String, cx: Float, cy: Float, s: Float, color: Int, on: Boolean) {
        val k = s / 2f
        val p = Widgets.paint()
        p.color = color
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        val soft = s * 0.14f
        fun solid(path: Path) {
            p.style = Paint.Style.FILL_AND_STROKE
            p.strokeWidth = soft
            cv.drawPath(path, p)
        }
        fun line(path: Path) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.13f
            cv.drawPath(path, p)
        }
        when (op) {
            "play" -> solid(Path().apply {
                moveTo(cx - k * 0.55f, cy - k * 0.9f); lineTo(cx - k * 0.55f, cy + k * 0.9f); lineTo(cx + k * 0.95f, cy); close()
            })
            "pause" -> {
                solid(Path().apply { addRoundRect(RectF(cx - k * 0.85f, cy - k * 0.9f, cx - k * 0.2f, cy + k * 0.9f), 2f, 2f, Path.Direction.CW) })
                solid(Path().apply { addRoundRect(RectF(cx + k * 0.2f, cy - k * 0.9f, cx + k * 0.85f, cy + k * 0.9f), 2f, 2f, Path.Direction.CW) })
            }
            "prev" -> {
                solid(Path().apply { moveTo(cx + k * 0.95f, cy - k * 0.85f); lineTo(cx + k * 0.95f, cy + k * 0.85f); lineTo(cx - k * 0.5f, cy); close() })
                solid(Path().apply { addRoundRect(RectF(cx - k * 1.0f, cy - k * 0.85f, cx - k * 0.7f, cy + k * 0.85f), 2f, 2f, Path.Direction.CW) })
            }
            "next" -> {
                solid(Path().apply { moveTo(cx - k * 0.95f, cy - k * 0.85f); lineTo(cx - k * 0.95f, cy + k * 0.85f); lineTo(cx + k * 0.5f, cy); close() })
                solid(Path().apply { addRoundRect(RectF(cx + k * 0.7f, cy - k * 0.85f, cx + k * 1.0f, cy + k * 0.85f), 2f, 2f, Path.Direction.CW) })
            }
            "like" -> {
                val hp = Path().apply {
                    moveTo(cx, cy + k * 0.9f)
                    cubicTo(cx - k * 1.7f, cy - k * 0.1f, cx - k * 0.9f, cy - k * 1.2f, cx, cy - k * 0.35f)
                    cubicTo(cx + k * 0.9f, cy - k * 1.2f, cx + k * 1.7f, cy - k * 0.1f, cx, cy + k * 0.9f)
                    close()
                }
                if (on) solid(hp) else line(hp)
            }
            "shuffle" -> {
                line(Path().apply {
                    moveTo(cx - k, cy + k * 0.55f); lineTo(cx - k * 0.3f, cy + k * 0.55f)
                    cubicTo(cx + k * 0.2f, cy + k * 0.55f, cx + k * 0.1f, cy - k * 0.55f, cx + k * 0.6f, cy - k * 0.55f)
                    lineTo(cx + k * 0.8f, cy - k * 0.55f)
                })
                line(Path().apply {
                    moveTo(cx - k, cy - k * 0.55f); lineTo(cx - k * 0.3f, cy - k * 0.55f)
                    cubicTo(cx + k * 0.2f, cy - k * 0.55f, cx + k * 0.1f, cy + k * 0.55f, cx + k * 0.6f, cy + k * 0.55f)
                    lineTo(cx + k * 0.8f, cy + k * 0.55f)
                })
                solid(Path().apply { moveTo(cx + k * 0.7f, cy - k * 0.9f); lineTo(cx + k * 1.1f, cy - k * 0.55f); lineTo(cx + k * 0.7f, cy - k * 0.2f); close() })
                solid(Path().apply { moveTo(cx + k * 0.7f, cy + k * 0.2f); lineTo(cx + k * 1.1f, cy + k * 0.55f); lineTo(cx + k * 0.7f, cy + k * 0.9f); close() })
            }
            "repeat" -> {
                line(Path().apply { addRoundRect(RectF(cx - k * 0.95f, cy - k * 0.6f, cx + k * 0.95f, cy + k * 0.6f), k * 0.45f, k * 0.45f, Path.Direction.CW) })
                solid(Path().apply { moveTo(cx + k * 0.45f, cy - k * 1.0f); lineTo(cx + k * 0.45f, cy - k * 0.2f); lineTo(cx + k * 1.05f, cy - k * 0.6f); close() })
            }
        }
    }
}

class NowPlayingWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(c, m, it) }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, opts: android.os.Bundle?) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        ids.forEach { Store.deleteInst(c, it) }
    }

    override fun onEnabled(c: Context) {
        Live.ensure(c)
    }

    override fun onDisabled(c: Context) {
        if (!Widgets.any(c)) Live.stop(c)
    }

    companion object {
        private val slotIds = intArrayOf(R.id.s0, R.id.s1, R.id.s2, R.id.s3, R.id.s4, R.id.s5)

        fun update(c: Context, m: AppWidgetManager, id: Int) {
            try {
                val inst = Store.inst(c, id)
                val st = Widgets.style(c, inst)
                val (w, h) = Widgets.sizePx(c, m, id, Widgets.NP)
                val np = NpState.current(c)
                val f = NpRenderer.render(c, st, inst.np, np, w, h)
                val rv = RemoteViews(c.packageName, R.layout.widget_np)
                rv.setImageViewBitmap(R.id.img, f.bmp)
                rv.setViewPadding(R.id.ctrl, f.padL, f.padT, f.padR, f.padB)
                for (k in slotIds.indices) {
                    if (k < f.slots.size) {
                        rv.setViewVisibility(slotIds[k], android.view.View.VISIBLE)
                        val op = f.slots[k]
                        val i = Intent(c, NpAction::class.java).setAction("app.widgets.NP")
                            .putExtra("op", op).putExtra("id", id)
                        rv.setOnClickPendingIntent(
                            slotIds[k],
                            PendingIntent.getBroadcast(c, id * 10 + k, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                        )
                        rv.setContentDescription(slotIds[k], op)
                    } else {
                        rv.setViewVisibility(slotIds[k], android.view.View.GONE)
                    }
                }
                val open: PendingIntent = np?.session
                    ?: np?.let { c.packageManager.getLaunchIntentForPackage(it.pkg) }?.let {
                        PendingIntent.getActivity(c, id, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                    }
                    ?: PendingIntent.getActivity(
                        c, id, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                rv.setOnClickPendingIntent(R.id.bg, open)
                m.updateAppWidget(id, rv)
            } catch (e: Exception) {
            }
        }

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            Widgets.ids(c, Widgets.NP).forEach { update(c, m, it) }
        }
    }
}

class NpAction : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val op = i.getStringExtra("op") ?: return
        val id = i.getIntExtra("id", -1)
        val ctl = NpState.controller(c) ?: return
        val st = ctl.playbackState
        val tc = ctl.transportControls
        val np = NpState.current(c)
        try {
            when (op) {
                "prev" -> tc.skipToPrevious()
                "next" -> tc.skipToNext()
                "toggle" -> if (st?.state == PlaybackState.STATE_PLAYING) tc.pause() else tc.play()
                "like" -> {
                    NpState.likeAction(st)?.let { tc.sendCustomAction(it, null) }
                    if (np != null) NpState.toggleLiked(c, np)
                }
                "shuffle" -> {
                    val on = !Store.getBool(c, "np_shuf_${ctl.packageName}", false)
                    val a = NpState.shuffleAction(st)
                    if (a != null) tc.sendCustomAction(a, null) else tc.setShuffleMode(if (on) 1 else 0)
                    Store.putBool(c, "np_shuf_${ctl.packageName}", on)
                }
                "repeat" -> {
                    val on = !Store.getBool(c, "np_rep_${ctl.packageName}", false)
                    val a = NpState.repeatAction(st)
                    if (a != null) tc.sendCustomAction(a, null) else tc.setRepeatMode(if (on) 2 else 0)
                    Store.putBool(c, "np_rep_${ctl.packageName}", on)
                }
            }
        } catch (e: Exception) {
        }
        if (id >= 0 && Store.inst(c, id).np.haptic) {
            try {
                c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            } catch (e: Exception) {
            }
        }
        NowPlayingWidget.updateAll(c)
    }
}
