package app.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.notification.NotificationListenerService
import android.text.TextPaint
import android.text.TextUtils
import android.widget.RemoteViews

/** A snapshot of whatever is playing. */
class Np(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean,
    val pos: Long,
    val dur: Long,
    val pkg: String,
    val canLike: Boolean,
    val liked: Boolean,
    val canShuffle: Boolean,
    val shuffleOn: Boolean,
    val canRepeat: Boolean,
    val repeatOn: Boolean,
    val session: PendingIntent?
)

object NpState {
    private val likeKeys = listOf("like", "heart", "favorite", "favourite", "love", "thumb", "save", "add to")
    private val unlikeKeys = listOf("unlike", "remove", "unfav", "unsave", "liked", "saved")

    private fun cn(c: Context) = ComponentName(c, MediaListener::class.java)

    fun granted(c: Context): Boolean =
        android.provider.Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners")
            ?.contains(c.packageName) == true

    fun controllers(c: Context): List<MediaController> = try {
        c.getSystemService(MediaSessionManager::class.java).getActiveSessions(cn(c))
    } catch (e: Exception) {
        emptyList()
    }

    fun controller(c: Context): MediaController? {
        val l = controllers(c)
        return l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING && it.metadata != null }
            ?: l.firstOrNull { it.metadata != null }
    }

    private fun action(st: PlaybackState?, keys: List<String>, not: List<String> = emptyList()): PlaybackState.CustomAction? =
        st?.customActions?.firstOrNull { a ->
            val n = ((a.name?.toString() ?: "") + " " + a.action).lowercase()
            keys.any { n.contains(it) } && not.none { n.contains(it) }
        }

    fun likeAction(st: PlaybackState?) = action(st, likeKeys, listOf("dislike", "thumbs_down", "thumbs down", "thumbsdown"))
    fun shuffleAction(st: PlaybackState?) = action(st, listOf("shuffle"))
    fun repeatAction(st: PlaybackState?) = action(st, listOf("repeat"))

    private fun trackKey(pkg: String, t: String, a: String) = "$pkg|$t|$a"

    fun current(c: Context): Np? {
        val ctl = controller(c) ?: return null
        val md = ctl.metadata ?: return null
        val st = ctl.playbackState
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: return null
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val playing = st?.state == PlaybackState.STATE_PLAYING
        var pos = st?.position ?: 0L
        if (playing && st != null) {
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        if (dur > 0) pos = pos.coerceIn(0L, dur)
        val pkg = ctl.packageName
        val la = likeAction(st)
        val likedLabel = la != null && unlikeKeys.any { ((la.name?.toString() ?: "") + " " + la.action).lowercase().contains(it) }
        val key = trackKey(pkg, title, artist)
        val liked = likedLabel || Store.getStr(c, "np_liked") == key
        val canShuffle = shuffleAction(st) != null
        val canRepeat = repeatAction(st) != null
        return Np(
            title, artist, art, playing, pos, dur, pkg,
            la != null, liked,
            canShuffle, Store.getBool(c, "np_shuf_$pkg", false),
            canRepeat, Store.getBool(c, "np_rep_$pkg", false),
            ctl.sessionActivity
        )
    }

    fun toggleLiked(c: Context, np: Np) {
        val key = trackKey(np.pkg, np.title, np.artist)
        Store.putStr(c, "np_liked", if (Store.getStr(c, "np_liked") == key) "" else key)
    }

    private var sampleArt: Bitmap? = null

    fun sample(): Np {
        if (sampleArt == null) {
            val b = Bitmap.createBitmap(240, 240, Bitmap.Config.ARGB_8888)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = LinearGradient(0f, 0f, 240f, 240f, 0xFF5B7CFF.toInt(), 0xFFE0689A.toInt(), Shader.TileMode.CLAMP)
            Canvas(b).drawRect(0f, 0f, 240f, 240f, p)
            sampleArt = b
        }
        return Np("Song title", "Artist name", sampleArt, true, 84000, 215000, "", true, false, true, false, true, false, null)
    }
}

/** Needs Notification access. Once granted, the system keeps it alive and tells us when the music changes. */
class MediaListener : NotificationListenerService() {
    private val h = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var attached: List<MediaController> = emptyList()
    private var connected = false

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = changed()
        override fun onPlaybackStateChanged(state: PlaybackState?) = changed()
    }

    private val sessions = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        attach(list ?: emptyList())
        changed()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (Widgets.ids(applicationContext, Widgets.NP).isEmpty()) return
            val playing = attached.any { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            if (playing) {
                NowPlayingWidget.updateAll(applicationContext)
                h.postDelayed(this, 1000)
            }
        }
    }

    private fun changed() {
        NowPlayingWidget.updateAll(applicationContext)
        h.removeCallbacks(tick)
        h.postDelayed(tick, 1000)
    }

    private fun attach(list: List<MediaController>) {
        attached.forEach { try { it.unregisterCallback(cb) } catch (e: Exception) { } }
        attached = list
        list.forEach { try { it.registerCallback(cb, h) } catch (e: Exception) { } }
    }

    override fun onListenerConnected() {
        connected = true
        try {
            val m = getSystemService(MediaSessionManager::class.java)
            msm = m
            val cn = ComponentName(this, MediaListener::class.java)
            m.addOnActiveSessionsChangedListener(sessions, cn, h)
            attach(m.getActiveSessions(cn))
            changed()
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        connected = false
        try { msm?.removeOnActiveSessionsChangedListener(sessions) } catch (e: Exception) { }
        attach(emptyList())
    }
}

class NpFrame(val bmp: Bitmap, val slots: List<String>, val padL: Int, val padT: Int, val padR: Int, val padB: Int, val ctlY: Int = 0, val ctlH: Int = 0)

object NpRenderer {
    fun slots(cfg: NpCfg, np: Np?): List<String> {
        val l = ArrayList<String>()
        if (np == null) return l
        if (cfg.shuffleRepeat && np.canShuffle) l.add("shuffle")
        l.add("prev"); l.add("toggle"); l.add("next")
        if (cfg.shuffleRepeat && np.canRepeat) l.add("repeat")
        if (cfg.like && np.canLike) l.add("like")
        return l
    }

    /** A pleasant accent pulled from the cover: the most colourful pixels, lifted so it reads on dark. */
    fun artColor(b: Bitmap, fallback: Int): Int {
        return try {
            val s = Bitmap.createScaledBitmap(b, 12, 12, true)
            var r = 0f; var g = 0f; var bl = 0f; var wsum = 0f
            val hsv = FloatArray(3)
            for (x in 0 until 12) for (y in 0 until 12) {
                val px = s.getPixel(x, y)
                Color.colorToHSV(px, hsv)
                val w = hsv[1] * hsv[2] + 0.01f
                r += Color.red(px) * w; g += Color.green(px) * w; bl += Color.blue(px) * w; wsum += w
            }
            val avg = Color.rgb((r / wsum).toInt(), (g / wsum).toInt(), (bl / wsum).toInt())
            Color.colorToHSV(avg, hsv)
            hsv[1] = hsv[1].coerceIn(0.35f, 0.85f)
            hsv[2] = hsv[2].coerceIn(0.75f, 1f)
            Color.HSVToColor(hsv)
        } catch (e: Exception) {
            fallback
        }
    }

    private fun lum(c: Int) = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    /** part: 0 everything, 1 everything except the control row, 2 only the control row (a short strip, so button animations stay light and crisp). */
    fun render(c: Context, st: Style, cfg: NpCfg, np: Np?, wPx: Int, hPx: Int, press: Pair<String, Float>? = null, scale: Float = 1f, part: Int = 0): NpFrame {
        val w = wPx * scale
        val h = hPx * scale
        val d = Widgets.density(c) * scale
        val ts = st.textScale / 100f
        val pal = Palette.of(c, st)
        val slots = slots(cfg, np)
        val pad = 14f * d
        // the controls get their own row along the bottom; art, title and timeline sit above it
        val ch = if (slots.isEmpty()) 0f else minOf(40f * d, h * 0.28f)
        val ctlTop = h - pad - ch
        val ex = ch * 0.45f
        val bmpH = if (part == 2) (ch + 2 * ex).toInt().coerceAtLeast(1) else h.toInt()
        val (bmp, cv) = Widgets.blank(w.toInt(), bmpH)
        if (part == 2) cv.translate(0f, -(ctlTop - ex))
        val accent = if (cfg.artAccent && np?.art != null) artColor(np.art, pal.accent) else pal.accent
        val p = Widgets.paint()

        if (st.bgOpacity > 0 && part != 2) {
            p.color = Widgets.alpha(pal.bg, st.bgOpacity * 255 / 100)
            val r = (st.corner * d).coerceAtMost(minOf(w, h) / 2f)
            cv.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        }

        val topH = if (slots.isEmpty()) h - 2 * pad else (ctlTop - pad - 4f * d).coerceAtLeast(20f * d)
        if (part != 2) {
        val artS = minOf(topH, w * 0.36f).coerceAtLeast(1f)
        val artL = pad
        val artT = pad + (topH - artS) / 2f
        val artR = (st.corner * d * 0.6f).coerceAtMost(artS / 2f)
        val artRect = RectF(artL, artT, artL + artS, artT + artS)
        if (np?.art != null) {
            val a = np.art
            val sh = BitmapShader(a, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val sc = Math.max(artS / a.width, artS / a.height)
            val m = Matrix()
            m.setScale(sc, sc)
            m.postTranslate(artL + (artS - a.width * sc) / 2f, artT + (artS - a.height * sc) / 2f)
            sh.setLocalMatrix(m)
            p.shader = sh
            cv.drawRoundRect(artRect, artR, artR, p)
            p.shader = null
        } else {
            p.color = Widgets.alpha(pal.text, 28)
            cv.drawRoundRect(artRect, artR, artR, p)
            val cx = artL + artS / 2f
            val cy = artT + artS / 2f
            val k = artS * 0.16f
            p.color = Widgets.alpha(pal.text, 120)
            cv.drawCircle(cx - k * 0.6f, cy + k * 0.9f, k * 0.62f, p)
            cv.drawRect(cx - k * 0.1f, cy - k * 1.3f, cx + k * 0.15f, cy + k * 0.9f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = k * 0.3f
            p.strokeCap = Paint.Cap.ROUND
            cv.drawLine(cx + k * 0.02f, cy - k * 1.2f, cx + k * 0.9f, cy - k * 0.5f, p)
            p.style = Paint.Style.FILL
        }

        val x0 = artL + artS + 14f * d
        val x1 = w - pad
        val avail = (x1 - x0).coerceAtLeast(10f)
        val base = FontStore.typeface(c, st.font)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)

        if (np == null) {
            tp.typeface = Typeface.create(base, Typeface.BOLD)
            tp.textSize = 17f * d * ts
            tp.color = pal.text
            cv.drawText(TextUtils.ellipsize("Nothing playing", tp, avail, TextUtils.TruncateAt.END).toString(), x0, h / 2f, tp)
            tp.typeface = base
            tp.textSize = 12.5f * d * ts
            tp.color = Widgets.alpha(pal.text, 150)
            val hint = if (NpState.granted(c)) "Start some music" else "Turn on Notification access in the app"
            cv.drawText(TextUtils.ellipsize(hint, tp, avail, TextUtils.TruncateAt.END).toString(), x0, h / 2f + 20f * d * ts, tp)
            return NpFrame(bmp, emptyList(), 0, 0, 0, 0)
        }

        val titleSize = 17f * d * ts
        val artistSize = 13f * d * ts
        val showBar = cfg.progress
        val artistGap = artistSize * 1.4f
        val barGap = 15f * d
        val thumbHalf = 8f * d
        // title, artist and bar sit together as one group, centered against the art
        val groupH = titleSize * 0.8f + artistGap + (if (showBar) barGap + thumbHalf else artistSize * 0.25f)
        val gTop = artT + (artS - groupH) / 2f
        val titleBase = gTop + titleSize * 0.8f
        tp.typeface = Typeface.create(base, Typeface.BOLD)
        tp.textSize = titleSize
        tp.color = pal.text
        cv.drawText(TextUtils.ellipsize(np.title, tp, avail, TextUtils.TruncateAt.END).toString(), x0, titleBase, tp)
        tp.typeface = base
        tp.textSize = artistSize
        tp.color = Widgets.alpha(pal.text, 170)
        val artistBase = titleBase + artistGap
        cv.drawText(TextUtils.ellipsize(np.artist, tp, avail, TextUtils.TruncateAt.END).toString(), x0, artistBase, tp)

        // progress bar: wavy while playing (or flat if wavy is off)
        val waveY = artistBase + barGap
        if (showBar) {
            val frac = if (np.dur > 0) (np.pos.toFloat() / np.dur).coerceIn(0f, 1f) else 0f
            val px = x0 + (x1 - x0) * frac
            val amp = if (np.playing && cfg.wavy) 3.2f * d else 0f
            val wl = 20f * d
            val path = Path()
            path.moveTo(x0, waveY)
            var x = x0
            while (x <= px) {
                path.lineTo(x, waveY + amp * Math.sin(((x - x0) / wl * 2 * Math.PI)).toFloat())
                x += 2f
            }
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.strokeWidth = 3.4f * d
            p.color = accent
            cv.drawPath(path, p)
            p.strokeWidth = 2.6f * d
            p.color = Widgets.alpha(pal.text, 55)
            cv.drawLine(px + 4f * d, waveY, x1, waveY, p)
            p.style = Paint.Style.FILL
            p.color = accent
            cv.drawRoundRect(RectF(px - 2f * d, waveY - 8f * d, px + 2f * d, waveY + 8f * d), 2f * d, 2f * d, p)
        }

        }

        if (slots.isNotEmpty() && part != 1) {
            val cw = w - 2 * pad
            val sw = cw / slots.size
            val cy = ctlTop + ch / 2f
            val s = ch * 0.44f
            p.style = Paint.Style.FILL
            for ((i, op) in slots.withIndex()) {
                val cx = pad + sw * (i + 0.5f)
                val pt = if (press != null && press.first == op) press.second.coerceIn(0f, 1f) else -1f
                cv.save()
                if (pt >= 0f) {
                    // a quick pop, plus a soft ring that spreads and fades
                    val pop = Math.sin(Math.PI * pt).toFloat()
                    cv.scale(1f + 0.14f * pop, 1f + 0.14f * pop, cx, cy)
                    p.style = Paint.Style.FILL
                    p.color = Widgets.alpha(accent, (80 * (1f - pt)).toInt())
                    cv.drawCircle(cx, cy, ch * (0.4f + 0.5f * pt), p)
                }
                when (op) {
                    "toggle" -> {
                        val bh = ch * 0.96f
                        val bw = minOf(sw * 0.98f, ch * 1.9f)
                        // playing shows a squircle, paused a circle, and the shape morphs when it flips
                        val now = if (np.playing) 0.30f else 0.5f
                        val prev = if (np.playing) 0.5f else 0.30f
                        val e = if (pt >= 0f) 1f - (1f - pt) * (1f - pt) else 1f
                        val rf = prev + (now - prev) * e
                        p.style = Paint.Style.FILL
                        p.color = accent
                        cv.drawRoundRect(RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2), bh * rf, bh * rf, p)
                        val ink = if (lum(accent) > 0.6f) 0xFF14161A.toInt() else Color.WHITE
                        val gs = if (pt >= 0f) 0.55f + 0.45f * e else 1f
                        glyph(cv, if (np.playing) "pause" else "play", cx, cy, s * 1.1f * gs, ink, false)
                    }
                    "prev", "next" -> {
                        val bh = ch * 0.8f
                        val bw = minOf(sw * 0.92f, ch * 1.4f)
                        p.style = Paint.Style.FILL
                        p.color = Widgets.alpha(pal.text, 26)
                        cv.drawRoundRect(RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2), bh * 0.38f, bh * 0.38f, p)
                        glyph(cv, op, cx, cy, s * 0.95f, pal.text, false)
                    }
                    else -> {
                        val on = (op == "like" && np.liked) || (op == "shuffle" && np.shuffleOn) || (op == "repeat" && np.repeatOn)
                        if (on) {
                            val bd = ch * 0.74f
                            p.style = Paint.Style.FILL
                            p.color = Widgets.alpha(accent, 48)
                            cv.drawRoundRect(RectF(cx - bd / 2, cy - bd / 2, cx + bd / 2, cy + bd / 2), bd * 0.38f, bd * 0.38f, p)
                        }
                        glyph(cv, op, cx, cy, s * 0.92f, if (on) accent else Widgets.alpha(pal.text, 190), on)
                    }
                }
                cv.restore()
            }
        }
        return NpFrame(bmp, slots, pad.toInt(), ctlTop.toInt(), pad.toInt(), pad.toInt(), (ctlTop - ex).toInt(), bmpH)
    }

    /** Clean, geometric glyphs: thin round-capped strokes, and soft-cornered solids for the transport keys. */
    private fun glyph(cv: Canvas, op: String, cx: Float, cy: Float, s: Float, color: Int, on: Boolean) {
        val k = s / 2f
        val p = Widgets.paint()
        p.color = color
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        fun solid(path: Path, soft: Float) {
            p.style = Paint.Style.FILL_AND_STROKE
            p.strokeWidth = soft
            cv.drawPath(path, p)
        }
        fun line(path: Path) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.11f
            cv.drawPath(path, p)
        }
        fun chev(x: Float, y: Float) {
            line(Path().apply {
                moveTo(x - k * 0.3f, y - k * 0.32f); lineTo(x + k * 0.05f, y); lineTo(x - k * 0.3f, y + k * 0.32f)
            })
        }
        when (op) {
            "play" -> solid(Path().apply {
                moveTo(cx - k * 0.5f, cy - k * 0.75f); lineTo(cx - k * 0.5f, cy + k * 0.75f); lineTo(cx + k * 0.8f, cy); close()
            }, k * 0.3f)
            "pause" -> {
                solid(Path().apply { addRoundRect(RectF(cx - k * 0.7f, cy - k * 0.75f, cx - k * 0.18f, cy + k * 0.75f), k * 0.2f, k * 0.2f, Path.Direction.CW) }, 1f)
                solid(Path().apply { addRoundRect(RectF(cx + k * 0.18f, cy - k * 0.75f, cx + k * 0.7f, cy + k * 0.75f), k * 0.2f, k * 0.2f, Path.Direction.CW) }, 1f)
            }
            "prev" -> {
                solid(Path().apply { moveTo(cx + k * 0.75f, cy - k * 0.65f); lineTo(cx + k * 0.75f, cy + k * 0.65f); lineTo(cx - k * 0.4f, cy); close() }, k * 0.26f)
                solid(Path().apply { addRoundRect(RectF(cx - k * 0.85f, cy - k * 0.65f, cx - k * 0.6f, cy + k * 0.65f), k * 0.12f, k * 0.12f, Path.Direction.CW) }, 1f)
            }
            "next" -> {
                solid(Path().apply { moveTo(cx - k * 0.75f, cy - k * 0.65f); lineTo(cx - k * 0.75f, cy + k * 0.65f); lineTo(cx + k * 0.4f, cy); close() }, k * 0.26f)
                solid(Path().apply { addRoundRect(RectF(cx + k * 0.6f, cy - k * 0.65f, cx + k * 0.85f, cy + k * 0.65f), k * 0.12f, k * 0.12f, Path.Direction.CW) }, 1f)
            }
            "shuffle" -> {
                line(Path().apply { moveTo(cx - k * 0.95f, cy + k * 0.5f); lineTo(cx - k * 0.3f, cy + k * 0.5f); lineTo(cx + k * 0.3f, cy - k * 0.5f); lineTo(cx + k * 0.8f, cy - k * 0.5f) })
                line(Path().apply { moveTo(cx - k * 0.95f, cy - k * 0.5f); lineTo(cx - k * 0.3f, cy - k * 0.5f); lineTo(cx + k * 0.3f, cy + k * 0.5f); lineTo(cx + k * 0.8f, cy + k * 0.5f) })
                chev(cx + k * 0.95f, cy - k * 0.5f)
                chev(cx + k * 0.95f, cy + k * 0.5f)
            }
            "repeat" -> {
                val l = cx - k * 0.95f
                val r = cx + k * 0.95f
                val t = cy - k * 0.55f
                val b = cy + k * 0.55f
                val rr = k * 0.4f
                line(Path().apply {
                    moveTo(cx + k * 0.25f, t)
                    lineTo(l + rr, t)
                    arcTo(RectF(l, t, l + 2 * rr, t + 2 * rr), 270f, -90f)
                    lineTo(l, b - rr)
                    arcTo(RectF(l, b - 2 * rr, l + 2 * rr, b), 180f, -90f)
                    lineTo(r - rr, b)
                    arcTo(RectF(r - 2 * rr, b - 2 * rr, r, b), 90f, -90f)
                    lineTo(r, t + k * 0.25f)
                })
                chev(cx + k * 0.45f, t)
            }
            "like" -> {
                val ink = if (lum(color) > 0.6f) 0xFF14161A.toInt() else Color.WHITE
                if (on) {
                    p.style = Paint.Style.FILL
                    cv.drawCircle(cx, cy, k * 0.95f, p)
                    p.color = ink
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = s * 0.11f
                    cv.drawPath(Path().apply { moveTo(cx - k * 0.42f, cy + k * 0.02f); lineTo(cx - k * 0.1f, cy + k * 0.34f); lineTo(cx + k * 0.46f, cy - k * 0.3f) }, p)
                } else {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = s * 0.11f
                    cv.drawCircle(cx, cy, k * 0.95f, p)
                    cv.drawLine(cx - k * 0.4f, cy, cx + k * 0.4f, cy, p)
                    cv.drawLine(cx, cy - k * 0.4f, cx, cy + k * 0.4f, p)
                }
            }
        }
    }
}

/** Remembers which button was just pressed, so every redraw of the widget shows the same animation. */
object NpPress {
    private const val DUR = 380L
    private val m = HashMap<Int, Pair<String, Long>>()

    fun start(id: Int, op: String) {
        synchronized(m) { m[id] = op to android.os.SystemClock.uptimeMillis() }
    }

    fun current(id: Int): Pair<String, Float>? {
        val e = synchronized(m) { m[id] } ?: return null
        val t = (android.os.SystemClock.uptimeMillis() - e.second) / DUR.toFloat()
        if (t >= 1f) {
            synchronized(m) { m.remove(id) }
            return null
        }
        return e.first to t
    }
}

class NowPlayingWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(c, m, it) }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, opts: android.os.Bundle?) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        ids.forEach { Store.deleteInst(c, it) }
    }

    override fun onEnabled(c: Context) {
        Live.ensure(c)
    }

    override fun onDisabled(c: Context) {
        if (!Widgets.any(c)) Live.stop(c)
    }

    companion object {
        private val slotIds = intArrayOf(R.id.s0, R.id.s1, R.id.s2, R.id.s3, R.id.s4, R.id.s5)

        fun update(c: Context, m: AppWidgetManager, id: Int, force: Boolean = false) {
            // other refreshes wait while a button animation is playing, so they can't cut in on it
            if (!force && NpPress.current(id) != null) return
            try {
                val inst = Store.inst(c, id)
                val st = Widgets.style(c, inst)
                val (bw, bh) = Widgets.sizePx(c, m, id, Widgets.NP)
                val fit = Widgets.fit(c, Widgets.NP, inst, bw, bh)
                val np = NpState.current(c)
                val f = Widgets.withDensity(fit.dens) { NpRenderer.render(c, st, inst.np, np, fit.w, fit.h, null, 1f, 1) }
                val rv = RemoteViews(c.packageName, R.layout.widget_np)
                rv.setImageViewBitmap(R.id.img, f.bmp)
                if (f.slots.isNotEmpty()) {
                    val cf = Widgets.withDensity(fit.dens) { NpRenderer.render(c, st, inst.np, np, fit.w, fit.h, null, 1f, 2) }
                    rv.setViewVisibility(R.id.ctlbox, android.view.View.VISIBLE)
                    rv.setImageViewBitmap(R.id.ctlimg, cf.bmp)
                    rv.setViewPadding(R.id.ctlbox, fit.offX, fit.offY + cf.ctlY, fit.offX, fit.offY + (fit.h - cf.ctlY - cf.ctlH).coerceAtLeast(0))
                } else {
                    rv.setViewVisibility(R.id.ctlbox, android.view.View.GONE)
                }
                rv.setViewPadding(R.id.ctrl, fit.offX + f.padL, fit.offY + f.padT, fit.offX + f.padR, fit.offY + f.padB)
                for (k in slotIds.indices) {
                    if (k < f.slots.size) {
                        rv.setViewVisibility(slotIds[k], android.view.View.VISIBLE)
                        val op = f.slots[k]
                        val i = Intent(c, NpAction::class.java).setAction("app.widgets.NP")
                            .putExtra("op", op).putExtra("id", id)
                        rv.setOnClickPendingIntent(
                            slotIds[k],
                            PendingIntent.getBroadcast(c, id * 10 + k, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                        )
                        rv.setContentDescription(slotIds[k], op)
                    } else {
                        rv.setViewVisibility(slotIds[k], android.view.View.GONE)
                    }
                }
                val open: PendingIntent = np?.session
                    ?: np?.let { c.packageManager.getLaunchIntentForPackage(it.pkg) }?.let {
                        PendingIntent.getActivity(c, id, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                    }
                    ?: PendingIntent.getActivity(
                        c, id, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                rv.setOnClickPendingIntent(R.id.bg, open)
                m.updateAppWidget(id, rv)
            } catch (e: Exception) {
            }
        }

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            Widgets.ids(c, Widgets.NP).forEach { update(c, m, it) }
        }

        /** Plays the press animation on one button, then settles on the full-quality picture. Everything slow is worked out once, up front. */
        fun pulse(c: Context, id: Int, op: String, playingAfter: Boolean? = null, done: (() -> Unit)? = null) {
            val ctx = c.applicationContext
            NpPress.start(id, op)
            Thread {
                val m = AppWidgetManager.getInstance(ctx)
                try {
                    val inst = Store.inst(ctx, id)
                    val st = Widgets.style(ctx, inst)
                    val (bw, bh) = Widgets.sizePx(ctx, m, id, Widgets.NP)
                    val fit = Widgets.fit(ctx, Widgets.NP, inst, bw, bh)
                    var np = NpState.current(ctx)
                    if (np != null && playingAfter != null) {
                        np = Np(np.title, np.artist, np.art, playingAfter, np.pos, np.dur, np.pkg, np.canLike, np.liked, np.canShuffle, np.shuffleOn, np.canRepeat, np.repeatOn, np.session)
                    }
                    var last = 0L
                    while (true) {
                        val pr = NpPress.current(id) ?: break
                        val t0 = android.os.SystemClock.uptimeMillis()
                        val f = Widgets.withDensity(fit.dens) { NpRenderer.render(ctx, st, inst.np, np, fit.w, fit.h, pr, 1f, 2) }
                        val rv = RemoteViews(ctx.packageName, R.layout.widget_np)
                        rv.setImageViewBitmap(R.id.ctlimg, f.bmp)
                        m.partiallyUpdateAppWidget(id, rv)
                        last = android.os.SystemClock.uptimeMillis() - t0
                        // the launcher only takes about 20 updates a second, so don't push faster than that
                        Thread.sleep(maxOf(8L, 50L - last))
                    }
                } catch (e: Exception) {
                }
                update(ctx, m, id, true)
                done?.invoke()
            }.start()
        }
    }
}

class NpAction : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val op = i.getStringExtra("op") ?: return
        val id = i.getIntExtra("id", -1)
        val ctl = NpState.controller(c) ?: return
        val st = ctl.playbackState
        val wasPlaying = st?.state == PlaybackState.STATE_PLAYING
        val tc = ctl.transportControls
        val np = NpState.current(c)
        try {
            when (op) {
                "prev" -> tc.skipToPrevious()
                "next" -> tc.skipToNext()
                "toggle" -> if (st?.state == PlaybackState.STATE_PLAYING) tc.pause() else tc.play()
                "like" -> {
                    NpState.likeAction(st)?.let { tc.sendCustomAction(it, null) }
                    if (np != null) NpState.toggleLiked(c, np)
                }
                "shuffle" -> {
                    val on = !Store.getBool(c, "np_shuf_${ctl.packageName}", false)
                    val a = NpState.shuffleAction(st)
                    if (a != null) tc.sendCustomAction(a, null)
                    Store.putBool(c, "np_shuf_${ctl.packageName}", on)
                }
                "repeat" -> {
                    val on = !Store.getBool(c, "np_rep_${ctl.packageName}", false)
                    val a = NpState.repeatAction(st)
                    if (a != null) tc.sendCustomAction(a, null)
                    Store.putBool(c, "np_rep_${ctl.packageName}", on)
                }
            }
        } catch (e: Exception) {
        }
        if (id >= 0 && Store.inst(c, id).np.haptic) {
            try {
                c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK))
            } catch (e: Exception) {
            }
        }
        if (id >= 0) {
            val pending = goAsync()
            NowPlayingWidget.pulse(c, id, op, if (op == "toggle") !wasPlaying else null) { pending.finish() }
        } else {
            NowPlayingWidget.updateAll(c)
        }
    }
}
