package app.widgets

import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.media.AudioManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.widget.RemoteViews

/** Draws the ringer widget as one bitmap, so any font, glow and colour works. */
object RingerRenderer {
    private val icons = intArrayOf(R.drawable.ic_mute, R.drawable.ic_vibrate, R.drawable.ic_ring)
    private val names = arrayOf("Silent", "Vibrate", "Ring")

    private fun alpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    /** mode: 0 = silent, 1 = vibrate, 2 = ring */
    fun render(c: Context, st: Style, cfg: RingerCfg, mode: Int, wPx: Int, hPx: Int): Bitmap {
        val w = wPx.coerceAtLeast(1)
        val h = hPx.coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val d = c.resources.displayMetrics.density
        val pal = Palette.of(c, st)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        if (st.bgOpacity > 0) {
            p.color = alpha(pal.bg, st.bgOpacity * 255 / 100)
            val r = (st.corner * d).coerceAtMost(minOf(w, h) / 2f)
            cv.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, p)
        }

        val spread = cfg.spacing.coerceIn(40, 100) / 100f
        val groupW = w * spread
        val left = (w - groupW) / 2f
        val cellW = groupW / 3f
        val labelSize = 11f * d * st.textScale / 100f
        val labelH = if (cfg.labels) labelSize * 1.7f else 0f
        val cy = (h - labelH) / 2f
        val iconPx = minOf(h * 0.46f * cfg.iconSize / 100f, cellW * 0.7f)
        val tf = FontStore.typeface(c, st.font)

        for (i in 0..2) {
            val cx = left + cellW * (i + 0.5f)
            val on = i == mode
            if (on && (cfg.hl == 0 || cfg.hl == 2)) {
                val rad = minOf(cy, h - cy, cellW * 0.65f) * 0.98f
                val a1 = (cfg.glow * 2.2f).toInt()
                val a2 = (cfg.glow * 1.0f).toInt()
                p.shader = RadialGradient(
                    cx, cy, rad.coerceAtLeast(1f),
                    intArrayOf(alpha(pal.accent, a1), alpha(pal.accent, a2), alpha(pal.accent, 0)),
                    floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
                )
                cv.drawCircle(cx, cy, rad, p)
                p.shader = null
            }
            if (on && (cfg.hl == 1 || cfg.hl == 2)) {
                val ph = minOf(iconPx * 1.55f, h * 0.92f)
                val pw = minOf(iconPx * 2.0f, cellW * 0.96f)
                p.color = alpha(pal.accent, 0x38)
                cv.drawRoundRect(RectF(cx - pw / 2, cy - ph / 2, cx + pw / 2, cy + ph / 2), ph / 2, ph / 2, p)
            }
            val col = if (on) pal.accent else alpha(pal.text, 190)
            val dr = c.getDrawable(icons[i])?.mutate()
            if (dr != null) {
                dr.setTint(col)
                val half = (iconPx / 2f).toInt()
                dr.setBounds((cx - half).toInt(), (cy - half).toInt(), (cx + half).toInt(), (cy + half).toInt())
                dr.draw(cv)
            }
            if (cfg.labels) {
                val tp = Paint(Paint.ANTI_ALIAS_FLAG)
                tp.typeface = tf
                tp.textSize = labelSize
                tp.color = col
                tp.textAlign = Paint.Align.CENTER
                cv.drawText(names[i], cx, cy + iconPx / 2f + labelSize * 1.2f, tp)
            }
        }
        return bmp
    }
}

class RingerWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(c, m, it) }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, opts: android.os.Bundle?) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        ids.forEach { Store.deleteInst(c, it) }
    }

    override fun onEnabled(c: Context) {
        Live.ensure(c)
    }

    override fun onDisabled(c: Context) {
        Live.stop(c)
    }

    companion object {
        fun mode(c: Context): Int {
            val am = c.getSystemService(AudioManager::class.java)
            return when (am.ringerMode) {
                AudioManager.RINGER_MODE_SILENT -> 0
                AudioManager.RINGER_MODE_VIBRATE -> 1
                else -> 2
            }
        }

        fun styleFor(c: Context, i: Inst): Style = if (i.useGlobal) Store.theme(c) else i.style

        /** The widget's real size in pixels, as the launcher reports it. */
        fun sizePx(c: Context, m: AppWidgetManager, id: Int): Pair<Int, Int> {
            val o = m.getAppWidgetOptions(id)
            val land = c.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            var wDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            var hDp = if (land) o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0) else o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
            if (wDp <= 0) wDp = 250
            if (hDp <= 0) hDp = 70
            val d = c.resources.displayMetrics.density
            return Pair((wDp * d).toInt().coerceAtMost(1400), (hDp * d).toInt().coerceAtMost(900))
        }

        private fun policyGranted(c: Context): Boolean =
            c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

        private fun tap(c: Context, id: Int, idx: Int): PendingIntent {
            if (idx == 0 && !policyGranted(c)) {
                val i = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return PendingIntent.getActivity(c, id * 10, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            }
            val i = Intent(c, RingerAction::class.java).setAction("app.widgets.RINGER")
                .putExtra("mode", idx).putExtra("id", id)
            return PendingIntent.getBroadcast(c, id * 10 + idx, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        fun update(c: Context, m: AppWidgetManager, id: Int) {
            try {
                val inst = Store.inst(c, id)
                val st = styleFor(c, inst)
                val (w, h) = sizePx(c, m, id)
                val bmp = RingerRenderer.render(c, st, inst.ringer, mode(c), w, h)
                val rv = RemoteViews(c.packageName, R.layout.widget_ringer)
                rv.setImageViewBitmap(R.id.img, bmp)
                val pad = ((w * (1f - inst.ringer.spacing.coerceIn(40, 100) / 100f)) / 2f).toInt()
                rv.setViewPadding(R.id.tap, pad, 0, pad, 0)
                val ids = intArrayOf(R.id.b0, R.id.b1, R.id.b2)
                val desc = arrayOf("Silent", "Vibrate", "Ring")
                for (k in 0..2) {
                    rv.setOnClickPendingIntent(ids[k], tap(c, id, k))
                    rv.setContentDescription(ids[k], desc[k])
                }
                m.updateAppWidget(id, rv)
            } catch (e: Exception) {
            }
        }

        fun ids(c: Context): IntArray =
            AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, RingerWidget::class.java))

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            ids(c).forEach { update(c, m, it) }
        }
    }
}

class RingerAction : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val idx = i.getIntExtra("mode", 2)
        val id = i.getIntExtra("id", -1)
        val am = c.getSystemService(AudioManager::class.java)
        try {
            am.ringerMode = when (idx) {
                0 -> AudioManager.RINGER_MODE_SILENT
                1 -> AudioManager.RINGER_MODE_VIBRATE
                else -> AudioManager.RINGER_MODE_NORMAL
            }
        } catch (e: SecurityException) {
        }
        if (id >= 0 && Store.inst(c, id).ringer.haptic) {
            try {
                c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } catch (e: Exception) {
            }
        }
        RingerWidget.updateAll(c)
    }
}
