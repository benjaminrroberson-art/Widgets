package app.widgets

import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.media.AudioManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.widget.RemoteViews

/** Draws the ringer widget as one bitmap. pos is a fractional index (0 silent, 1 vibrate, 2 ring) so it can be animated. */
object RingerRenderer {
    private val icons = intArrayOf(R.drawable.ic_mute, R.drawable.ic_vibrate, R.drawable.ic_ring)
    private val names = arrayOf("Silent", "Vibrate", "Ring")

    private fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    /** from == to draws a settled state. Otherwise t (0..1) fades the old highlight out and pops the new one in. */
    fun render(c: Context, st: Style, cfg: RingerCfg, from: Int, to: Int, t: Float, wPx: Int, hPx: Int, scale: Float = 1f): Bitmap {
        val (bmp, cv) = Widgets.blank((wPx * scale).toInt(), (hPx * scale).toInt())
        val w = bmp.width
        val h = bmp.height
        val d = Widgets.density(c) * scale
        val pal = Palette.of(c, st)
        val p = Widgets.paint()
        val al = { col: Int, a: Int -> Widgets.alpha(col, a) }

        if (st.bgOpacity > 0) {
            p.color = al(pal.bg, st.bgOpacity * 255 / 100)
            val r = (st.corner * d).coerceAtMost(minOf(w, h) / 2f)
            cv.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, p)
        }

        val spread = cfg.spacing.coerceIn(40, 100) / 100f
        val groupW = w * spread
        val left = (w - groupW) / 2f
        val cellW = groupW / 3f
        val labelSize = 11f * d * st.textScale / 100f
        val labelH = if (cfg.labels) labelSize * 1.7f else 0f
        val cy = (h - labelH) / 2f
        val iconPx = minOf(h * 0.46f * cfg.iconSize / 100f, cellW * 0.7f)
        val tf = FontStore.typeface(c, st.font)

        // how strongly each cell is highlighted, and how big its highlight is
        val inten = FloatArray(3)
        val grow = floatArrayOf(1f, 1f, 1f)
        if (from == to) {
            inten[to.coerceIn(0, 2)] = 1f
        } else {
            val e = t.coerceIn(0f, 1f)
            val k = e - 1f
            val back = 1f + 2.4f * k * k * k + 1.4f * k * k   // eases out with a small overshoot
            inten[from.coerceIn(0, 2)] = 1f - e
            inten[to.coerceIn(0, 2)] = minOf(1f, e * 1.5f)
            grow[from.coerceIn(0, 2)] = 1f - 0.15f * e
            grow[to.coerceIn(0, 2)] = 0.5f + 0.5f * back
        }

        for (i in 0..2) {
            val a = inten[i]
            if (a < 0.01f) continue
            val hx = left + cellW * (i + 0.5f)
            if (cfg.hl == 0 || cfg.hl == 2) {
                val rad = minOf(cy, h - cy, cellW * 0.65f) * 0.98f * grow[i]
                val a1 = (cfg.glow * 2.2f * a).toInt()
                val a2 = (cfg.glow * 1.0f * a).toInt()
                p.shader = RadialGradient(
                    hx, cy, rad.coerceAtLeast(1f),
                    intArrayOf(al(pal.accent, a1), al(pal.accent, a2), al(pal.accent, 0)),
                    floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
                )
                cv.drawCircle(hx, cy, rad, p)
                p.shader = null
            }
            if (cfg.hl == 1 || cfg.hl == 2) {
                val ph = minOf(iconPx * 1.55f, h * 0.92f) * grow[i]
                val pw = minOf(iconPx * 2.0f, cellW * 0.96f) * grow[i]
                p.color = al(pal.accent, (0x38 * a).toInt())
                cv.drawRoundRect(RectF(hx - pw / 2, cy - ph / 2, hx + pw / 2, cy + ph / 2), ph / 2, ph / 2, p)
            }
        }

        val idle = al(pal.text, 190)
        for (i in 0..2) {
            val cx = left + cellW * (i + 0.5f)
            val on = inten[i].coerceIn(0f, 1f)
            val col = mix(idle, pal.accent, on)
            val size = iconPx * (1f + 0.14f * on)
            val dr = c.getDrawable(icons[i])?.mutate()
            if (dr != null) {
                dr.setTint(col)
                val half = (size / 2f).toInt()
                dr.setBounds((cx - half).toInt(), (cy - half).toInt(), (cx + half).toInt(), (cy + half).toInt())
                dr.draw(cv)
            }
            if (cfg.labels) {
                val tp = Widgets.paint()
                tp.typeface = tf
                tp.textSize = labelSize
                tp.color = col
                tp.textAlign = Paint.Align.CENTER
                cv.drawText(names[i], cx, cy + iconPx / 2f + labelSize * 1.2f, tp)
            }
        }
        return bmp
    }
}

class RingerWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(c, m, it, mode(c)) }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, opts: android.os.Bundle?) {
        update(c, m, id, mode(c))
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        ids.forEach { Store.deleteInst(c, it) }
    }

    override fun onEnabled(c: Context) {
        Live.ensure(c)
    }

    override fun onDisabled(c: Context) {
        if (!Widgets.any(c)) Live.stop(c)
    }

    companion object {
        private val gens = HashMap<Int, Int>()

        fun mode(c: Context): Int {
            val am = c.getSystemService(AudioManager::class.java)
            return when (am.ringerMode) {
                AudioManager.RINGER_MODE_SILENT -> 0
                AudioManager.RINGER_MODE_VIBRATE -> 1
                else -> 2
            }
        }

        private fun policyGranted(c: Context): Boolean =
            c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

        private fun tap(c: Context, id: Int, idx: Int): PendingIntent {
            if (idx == 0 && !policyGranted(c)) {
                return PendingIntent.getActivity(
                    c, id * 10, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("dnd", true),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
            val i = Intent(c, RingerAction::class.java).setAction("app.widgets.RINGER")
                .putExtra("mode", idx).putExtra("id", id)
            return PendingIntent.getBroadcast(c, id * 10 + idx, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        /** Draws the widget with the highlight at pos and wires its taps. */
        fun update(c: Context, m: AppWidgetManager, id: Int, mode: Int) {
            try {
                val inst = Store.inst(c, id)
                val st = Widgets.style(c, inst)
                val (bw, bh) = Widgets.sizePx(c, m, id, Widgets.RINGER)
                val f = Widgets.fit(c, Widgets.RINGER, inst, bw, bh)
                val bmp = Widgets.withDensity(f.dens) { RingerRenderer.render(c, st, inst.ringer, mode, mode, 1f, f.w, f.h) }
                val rv = RemoteViews(c.packageName, R.layout.widget_ringer)
                rv.setImageViewBitmap(R.id.img, bmp)
                val pad = f.offX + ((f.w * (1f - inst.ringer.spacing.coerceIn(40, 100) / 100f)) / 2f).toInt()
                rv.setViewPadding(R.id.tap, pad, f.offY, pad, f.offY)
                val ids = intArrayOf(R.id.b0, R.id.b1, R.id.b2)
                val desc = arrayOf("Silent", "Vibrate", "Ring")
                for (k in 0..2) {
                    rv.setOnClickPendingIntent(ids[k], tap(c, id, k))
                    rv.setContentDescription(ids[k], desc[k])
                }
                m.updateAppWidget(id, rv)
                Store.putFloat(c, "shown_$id", mode.toFloat())
            } catch (e: Exception) {
            }
        }

        /** Lighter frame used mid-animation: smaller bitmap, so the launcher can keep up. */
        private fun frame(c: Context, m: AppWidgetManager, id: Int, st: Style, cfg: RingerCfg, f: Widgets.Fit, from: Int, to: Int, t: Float) {
            try {
                val bmp = Widgets.withDensity(f.dens) { RingerRenderer.render(c, st, cfg, from, to, t, f.w, f.h, 0.6f) }
                val rv = RemoteViews(c.packageName, R.layout.widget_ringer)
                rv.setImageViewBitmap(R.id.img, bmp)
                m.partiallyUpdateAppWidget(id, rv)
            } catch (e: Exception) {
            }
        }

        /** The old highlight fades out and the new one pops in, in place. Icons never travel. */
        private fun glide(c: Context, m: AppWidgetManager, id: Int, gen: Int) {
            val to = mode(c)
            val from = Math.round(Store.getFloat(c, "shown_$id", to.toFloat())).coerceIn(0, 2)
            if (from == to) {
                update(c, m, id, to)
                return
            }
            val inst = Store.inst(c, id)
            val st = Widgets.style(c, inst)
            val box = Widgets.sizePx(c, m, id, Widgets.RINGER)
            val fit = Widgets.fit(c, Widgets.RINGER, inst, box.first, box.second)
            val frames = 5
            val gap = 48L
            val t0 = android.os.SystemClock.uptimeMillis()
            for (f in 1..frames) {
                if (synchronized(gens) { gens[id] } != gen) return
                frame(c, m, id, st, inst.ringer, fit, from, to, f / frames.toFloat())
                val wait = t0 + gap * f - android.os.SystemClock.uptimeMillis()
                if (wait > 0) {
                    try {
                        Thread.sleep(wait)
                    } catch (ie: InterruptedException) {
                        return
                    }
                }
            }
            if (synchronized(gens) { gens[id] } == gen) update(c, m, id, to)
        }

        /** Brings every ringer widget in line with the real mode, with the slide animation. */
        fun refresh(c: Context, done: (() -> Unit)? = null) {
            val ctx = c.applicationContext
            val m = AppWidgetManager.getInstance(ctx)
            val ids = Widgets.ids(ctx, Widgets.RINGER)
            Thread {
                val gen = ids.map { id ->
                    synchronized(gens) {
                        val g = (gens[id] ?: 0) + 1
                        gens[id] = g
                        id to g
                    }
                }
                gen.forEach { (id, g) -> glide(ctx, m, id, g) }
                done?.invoke()
            }.start()
        }

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            Widgets.ids(c, Widgets.RINGER).forEach { update(c, m, it, mode(c)) }
        }
    }
}

class RingerAction : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val idx = i.getIntExtra("mode", 2)
        val id = i.getIntExtra("id", -1)
        val am = c.getSystemService(AudioManager::class.java)
        try {
            am.ringerMode = when (idx) {
                0 -> AudioManager.RINGER_MODE_SILENT
                1 -> AudioManager.RINGER_MODE_VIBRATE
                else -> AudioManager.RINGER_MODE_NORMAL
            }
        } catch (e: SecurityException) {
        }
        if (id >= 0 && Store.inst(c, id).ringer.haptic) {
            try {
                c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } catch (e: Exception) {
            }
        }
        val pending = goAsync()
        RingerWidget.refresh(c) { pending.finish() }
    }
}
