package app.widgets

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Live-preview editor. id = -1 edits the global theme; otherwise one placed widget. */
class EditorActivity : Activity() {

    private var id = -1
    private lateinit var inst: Inst
    private lateinit var theme: Style
    private val ringerDefault = RingerCfg()

    private lateinit var scroll: ScrollView
    private lateinit var page: LinearLayout
    private lateinit var col: LinearLayout
    private lateinit var preview: ImageView
    private var previewMode = 2
    private var density = 1f
    private val handler = Handler(Looper.getMainLooper())
    private val pushLive = Runnable { RingerWidget.updateAll(this) }

    private fun dp(i: Int) = (i * density).toInt()

    private fun editable() = id < 0 || !inst.useGlobal
    private fun style(): Style = if (id < 0) theme else if (inst.useGlobal) theme else inst.style
    private fun cfg(): RingerCfg = if (id < 0) ringerDefault else inst.ringer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        id = intent.getIntExtra("id", -1)
        theme = Store.theme(this)
        inst = if (id >= 0) Store.inst(this, id) else Inst(-1)
        Ui.init(this)
        scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(20), dp(12), dp(20), dp(32))
        scroll.addView(page, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
        Ui.window(this)
        build()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(pushLive)
        RingerWidget.updateAll(this)
    }

    // ---------- saving and preview ----------

    private fun save() {
        if (id < 0) Store.saveTheme(this, theme) else Store.saveInst(this, inst)
        refresh()
        handler.removeCallbacks(pushLive)
        handler.postDelayed(pushLive, 250)
    }

    private fun refresh() {
        val wDp = (resources.displayMetrics.widthPixels / density - 72).coerceIn(200f, 360f).toInt()
        val bmp = RingerRenderer.render(this, style(), cfg(), previewMode, dp(wDp), dp(72))
        preview.setImageBitmap(bmp)
    }

    // ---------- screen ----------

    private fun build() {
        val y = scroll.scrollY
        page.removeAllViews()
        col = page
        page.addView(TextView(this).apply {
            text = if (id < 0) "Global theme" else "Ringer mode"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(10), 0, dp(10))
        })

        // live preview on a stand-in wallpaper
        val back = FrameLayout(this).apply {
            val g = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF3B5BA9L.toInt(), 0xFF8E5BA8L.toInt(), 0xFFE0875AL.toInt())
            )
            g.cornerRadius = dp(24).toFloat()
            background = g
            setPadding(dp(18), dp(26), dp(18), dp(26))
        }
        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setOnTouchListener { v, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    previewMode = (e.x / v.width * 3).toInt().coerceIn(0, 2)
                    refresh()
                }
                true
            }
        }
        back.addView(preview, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(72), Gravity.CENTER))
        page.addView(back, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        page.addView(TextView(this).apply {
            text = "Tap the preview to try each mode. Colors follow your wallpaper unless you pick your own."
            textSize = 12.5f
            setTextColor(Ui.sub)
            setPadding(dp(4), dp(8), dp(4), 0)
        })

        if (id >= 0) {
            startCard("Look")
            col.addView(Switch(this).apply {
                text = "Use the global theme"
                isChecked = inst.useGlobal
                setPadding(0, dp(8), 0, dp(4))
                setOnCheckedChangeListener { _, on ->
                    if (!on && inst.useGlobal) inst.style = theme.copy()
                    inst.useGlobal = on
                    save()
                    build()
                }
            })
            if (inst.useGlobal) note("Turn this off to give this widget its own font, corners, opacity and colors.")
        }

        if (editable()) {
            startCard(if (id < 0) "Theme" else "This widget's look")
            fontRow()
            slider("Text size", 70, 160, style().textScale, "%") { style().textScale = it }
            slider("Corner radius", 0, 48, style().corner, "dp") { style().corner = it }
            slider("Background opacity", 0, 100, style().bgOpacity, "%") { style().bgOpacity = it }

            startCard("Colors")
            col.addView(Switch(this).apply {
                text = "Follow wallpaper (Material You)"
                isChecked = style().colorMode == 0
                setPadding(0, dp(8), 0, dp(4))
                setOnCheckedChangeListener { _, on ->
                    style().colorMode = if (on) 0 else 1
                    save()
                    build()
                }
            })
            if (style().colorMode == 1) {
                colorRow("Accent", style().accent) { style().accent = it }
                colorRow("Text and icons", style().text) { style().text = it }
                colorRow("Background", style().bg) { style().bg = it }
            }
        }

        if (id >= 0) {
            startCard("Ringer")
            col.addView(TextView(this).apply {
                text = "Highlight"
                textSize = 14f
                setPadding(0, dp(8), 0, dp(4))
            })
            val hl = Spinner(this)
            val opts = listOf("Glow", "Pill", "Glow and pill")
            hl.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)
            hl.setSelection(inst.ringer.hl.coerceIn(0, 2))
            hl.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, i: Long) {
                    if (pos != inst.ringer.hl) {
                        inst.ringer.hl = pos
                        save()
                    }
                }

                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            col.addView(hl)
            slider("Glow strength", 0, 100, inst.ringer.glow, "%") { inst.ringer.glow = it }
            slider("Icon size", 50, 140, inst.ringer.iconSize, "%") { inst.ringer.iconSize = it }
            slider("Icon spacing", 40, 100, inst.ringer.spacing, "%") { inst.ringer.spacing = it }
            col.addView(Switch(this).apply {
                text = "Show labels"
                isChecked = inst.ringer.labels
                setPadding(0, dp(12), 0, dp(4))
                setOnCheckedChangeListener { _, on ->
                    inst.ringer.labels = on
                    save()
                }
            })
            col.addView(Switch(this).apply {
                text = "Haptic tick on tap"
                isChecked = inst.ringer.haptic
                setPadding(0, dp(8), 0, dp(4))
                setOnCheckedChangeListener { _, on ->
                    inst.ringer.haptic = on
                    save()
                }
            })
        }

        Ui.polish(page) { dp(it) }
        refresh()
        scroll.post { scroll.scrollTo(0, y) }
    }

    // ---------- controls ----------

    private fun startCard(title: String) {
        page.addView(TextView(this).apply {
            text = title.uppercase()
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.1f
            setTextColor(Ui.accent)
            setPadding(dp(6), dp(22), 0, dp(8))
        })
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.card, dp(20).toFloat())
            setPadding(dp(16), dp(10), dp(16), dp(16))
        }
        page.addView(c, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        col = c
    }

    private fun note(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 13f
            setTextColor(Ui.sub)
            setPadding(0, dp(6), 0, dp(2))
        })
    }

    private fun slider(label: String, min: Int, max: Int, value: Int, unit: String, set: (Int) -> Unit) {
        val head = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(12), 0, 0)
        }
        fun txt(v: Int) {
            head.text = "$label: $v$unit"
        }
        txt(value)
        val bar = SeekBar(this).apply {
            this.max = max - min
            progress = (value - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    set(p + min)
                    txt(p + min)
                    save()
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(head)
        col.addView(bar)
    }

    private fun fontRow() {
        col.addView(TextView(this).apply {
            text = "Font"
            textSize = 14f
            setPadding(0, dp(8), 0, dp(4))
        })
        val keys = ArrayList<String>()
        val names = ArrayList<String>()
        for ((k, n) in FontStore.builtin) {
            keys.add(k)
            names.add(n)
        }
        for (f in FontStore.uploaded(this)) {
            keys.add("file:$f")
            names.add(f.substringBeforeLast('.'))
        }
        keys.add("__upload")
        names.add("Upload font…")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val cur = keys.indexOf(style().font).let { if (it < 0) 0 else it }
        sp.setSelection(cur)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, i: Long) {
                val k = keys[pos]
                if (k == "__upload") {
                    sp.setSelection(cur)
                    val it = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(it, 7)
                } else if (k != style().font) {
                    style().font = k
                    save()
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(sp)
        note("Upload a .ttf or .otf file and it becomes available to every widget.")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val key = FontStore.import(this, uri)
        if (key == null) {
            Toast.makeText(this, "That file isn't a usable font", Toast.LENGTH_LONG).show()
            return
        }
        if (editable()) {
            style().font = key
            save()
        }
        build()
    }

    private fun colorRow(label: String, color: Int, set: (Int) -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
        }
        r.addView(TextView(this).apply {
            text = label
            textSize = 15f
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = View(this)
        sw.background = Ui.round(color, dp(12).toFloat())
        r.addView(sw, LinearLayout.LayoutParams(dp(56), dp(32)))
        r.setOnClickListener {
            pickColor(label, color) { c ->
                set(c)
                save()
                build()
            }
        }
        col.addView(r)
    }

    private fun pickColor(title: String, start: Int, done: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(start, hsv)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }
        val sw = View(this)
        fun cur() = Color.HSVToColor(hsv)
        fun paint() {
            sw.background = Ui.round(cur(), dp(12).toFloat())
        }
        paint()
        box.addView(sw, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))
        fun bar(name: String, max: Int, init: Int, on: (Int) -> Unit) {
            box.addView(TextView(this).apply {
                text = name
                textSize = 13f
                setPadding(0, dp(12), 0, 0)
            })
            box.addView(SeekBar(this).apply {
                this.max = max
                progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                        on(p)
                        paint()
                    }

                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }
        Ui.polish(box) { dp(it) }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Done") { _, _ -> done(cur()) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
