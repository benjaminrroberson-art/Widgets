package app.widgets

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Live-preview editor. id = -1 edits the global theme; otherwise one placed widget. */
class EditorActivity : Activity() {

    private var id = -1
    private var type: String? = null
    private lateinit var inst: Inst
    private lateinit var theme: Style

    private lateinit var scroll: ScrollView
    private lateinit var page: LinearLayout
    private lateinit var col: LinearLayout
    private val imgs = LinkedHashMap<String, ImageView>()
    private var animFrom = 2f
    private var animTo = 2f
    private var animT = 1f
    private var density = 1f
    private val handler = Handler(Looper.getMainLooper())
    private val pushLive = Runnable { Widgets.updateAll(this) }

    private fun dp(i: Int) = (i * density).toInt()

    private fun editable() = id < 0 || !inst.useGlobal
    private fun style(): Style = if (id < 0) theme else if (inst.useGlobal) theme else inst.style

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        id = intent.getIntExtra("id", -1)
        theme = Store.theme(this)
        inst = if (id >= 0) Store.inst(this, id) else Inst(-1)
        type = if (id >= 0) Widgets.typeOf(this, id) else null
        animFrom = RingerWidget.mode(this).toFloat()
        animTo = animFrom
        Ui.init(this)
        scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(20), dp(12), dp(20), dp(32))
        scroll.addView(page, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
        Ui.window(this)
        build()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(pushLive)
        Widgets.updateAll(this)
    }

    // ---------- saving and preview ----------

    private fun save() {
        if (id < 0) Store.saveTheme(this, theme) else Store.saveInst(this, inst)
        refresh()
        handler.removeCallbacks(pushLive)
        handler.postDelayed(pushLive, 250)
    }

    private fun renderOne(t: String) {
        val iv = imgs[t] ?: return
        val (w, h) = if (id >= 0) {
            Widgets.sizePx(this, AppWidgetManager.getInstance(this), id, t)
        } else {
            val d = Widgets.defaultDp(t)
            Pair((d.first * density).toInt(), (d.second * density).toInt())
        }
        val i2 = if (id >= 0) inst else Inst(-1)
        try {
            iv.setImageBitmap(Widgets.render(this, t, id, i2, w, h, true, if (t == Widgets.RINGER) floatArrayOf(animFrom, animTo, animT) else null))
        } catch (e: Exception) {
        }
    }

    private fun refresh() {
        for (t in imgs.keys) renderOne(t)
    }

    private fun glideTo(target: Float) {
        if (target == animTo && animT >= 1f) return
        animFrom = animTo
        animTo = target
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 360
        a.addUpdateListener {
            animT = it.animatedFraction
            renderOne(Widgets.RINGER)
        }
        a.start()
    }

    // ---------- screen ----------

    private fun build() {
        val y = scroll.scrollY
        page.removeAllViews()
        imgs.clear()
        col = page
        val t = type
        page.addView(TextView(this).apply {
            text = if (id < 0) "Global theme" else Widgets.label(t ?: "")
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(10), 0, dp(10))
        })

        val shown = if (id < 0) Widgets.types else listOfNotNull(t)
        for (pt in shown) {
            val back = FrameLayout(this).apply {
                val g = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(0xFF3B5BA9.toInt(), 0xFF8E5BA8.toInt(), 0xFFE0875A.toInt())
                )
                g.cornerRadius = dp(24).toFloat()
                background = g
                setPadding(dp(16), dp(22), dp(16), dp(22))
            }
            val iv = ImageView(this).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            if (pt == Widgets.RINGER) {
                iv.setOnTouchListener { v, e ->
                    if (e.action == android.view.MotionEvent.ACTION_UP && v.width > 0) {
                        val target = (e.x / v.width * 3).toInt().coerceIn(0, 2).toFloat()
                        glideTo(target)
                    }
                    true
                }
            }
            back.addView(iv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(10)
            page.addView(back, lp)
            imgs[pt] = iv
        }
        page.addView(TextView(this).apply {
            text = "This is a live preview" + (if (shown.contains(Widgets.RINGER)) ". Tap the ringer to try each mode." else ".") +
                " Colors follow your wallpaper unless you pick your own."
            textSize = 12.5f
            setTextColor(Ui.sub)
            setPadding(dp(4), dp(2), dp(4), 0)
        })

        if (id >= 0) {
            startCard("Look")
            sw("Use the global theme", inst.useGlobal) { on ->
                if (!on && inst.useGlobal) inst.style = theme.copy()
                inst.useGlobal = on
                save()
                build()
            }
            if (inst.useGlobal) note("Turn this off to give this widget its own font, corners, opacity and colors.")
            sw("Lock aspect ratio", inst.lock) { on ->
                inst.lock = on
                save()
            }
            note("On: the widget keeps its proportions and scales to fill whatever size you resize it to. Off: it stretches to the box.")
        }

        if (editable()) {
            startCard(if (id < 0) "Theme" else "This widget's look")
            fontRow()
            slider("Text size", 70, 160, style().textScale, "%") { style().textScale = it }
            slider("Corner radius", 0, 48, style().corner, "dp") { style().corner = it }
            slider("Background opacity", 0, 100, style().bgOpacity, "%") { style().bgOpacity = it }

            startCard("Colors")
            sw("Follow wallpaper (Material You)", style().colorMode == 0) { on ->
                style().colorMode = if (on) 0 else 1
                save()
                build()
            }
            if (style().colorMode == 1) {
                colorRow("Accent", style().accent) { style().accent = it }
                colorRow("Text and icons", style().text) { style().text = it }
                colorRow("Background", style().bg) { style().bg = it }
            }
        }

        when (t) {
            Widgets.RINGER -> ringerControls()
            Widgets.NP -> npControls()
            Widgets.WX -> wxControls()
            Widgets.CAL -> calControls()
            Widgets.CLOCK -> clockControls()
        }

        Ui.polish(page) { dp(it) }
        refresh()
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun ringerControls() {
        val r = inst.ringer
        startCard("Ringer")
        spin("Highlight", listOf("Glow", "Pill", "Glow and pill"), r.hl) { r.hl = it; save() }
        slider("Glow strength", 0, 100, r.glow, "%") { r.glow = it }
        slider("Icon size", 50, 140, r.iconSize, "%") { r.iconSize = it }
        slider("Icon spacing", 40, 100, r.spacing, "%") { r.spacing = it }
        sw("Show labels", r.labels) { r.labels = it; save() }
        sw("Haptic tick on tap", r.haptic) { r.haptic = it; save() }
    }

    private fun npControls() {
        val n = inst.np
        startCard("Now playing")
        sw("Progress bar", n.progress) { n.progress = it; save(); build() }
        if (n.progress) sw("Wavy style", n.wavy) { n.wavy = it; save() }
        sw("Like button", n.like) { n.like = it; save() }
        sw("Shuffle and repeat", n.shuffleRepeat) { n.shuffleRepeat = it; save() }
        sw("Accent color from album art", n.artAccent) { n.artAccent = it; save() }
        sw("Haptic tick on tap", n.haptic) { n.haptic = it; save() }
        note("Like, shuffle and repeat only appear when your music app offers them. The widget needs Notification access, which you can turn on from the main screen.")
    }

    private fun clockControls() {
        val k = inst.clock
        startCard("Clock")
        note("Face: " + (k.style + 1) + " of " + ClockStyles.names.size + "  ·  " + ClockStyles.at(k.style).name)
        col.addView(Button2("Choose a face") { clockGallery() })
        sw("24-hour time", k.h24) { k.h24 = it; save() }
        sw("Show date", k.date) { k.date = it; save() }
        if (ClockStyles.at(k.style).name.let { it == "Dual" || it == "World" }) {
            val zones = listOf("Europe/London", "Europe/Paris", "Europe/Berlin", "Asia/Tokyo", "Asia/Kolkata", "Asia/Dubai", "Australia/Sydney", "America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles", "UTC")
            val idx = zones.indexOf(k.tz2).coerceAtLeast(0)
            spin("Second time zone", zones.map { it.substringAfterLast('/').replace('_', ' ') }, idx) { k.tz2 = zones[it]; save() }
        }
        startCard("Customize")
        slider("Hand thickness", 50, 200, k.handScale, "%") { k.handScale = it }
        val fkeys = ArrayList<String>().apply { add(""); addAll(FontStore.builtin.map { it.first }.filter { it.isNotEmpty() }); addAll(FontStore.uploaded(this@EditorActivity).map { "file:$it" }) }
        val fnames = ArrayList<String>().apply { add("Same as theme"); addAll(FontStore.builtin.filter { it.first.isNotEmpty() }.map { it.second }); addAll(FontStore.uploaded(this@EditorActivity).map { it.substringBeforeLast('.') }) }
        spin("Clock font", fnames, fkeys.indexOf(k.font).coerceAtLeast(0)) { k.font = fkeys[it]; save() }
        sw("Custom colors", k.custom) { on ->
            if (on && !k.custom) {
                val pal = Palette.of(this, Widgets.style(this, inst))
                k.cText = pal.text; k.cAccent = pal.accent; k.cBase = pal.bg
                k.cFace = blend(pal.bg, pal.text, 0.10f)
                k.cMuted = (pal.text and 0x00FFFFFF) or (150 shl 24)
                k.cHour = pal.text; k.cMin = pal.accent
            }
            k.custom = on
            save()
            build()
        }
        if (k.custom) {
            colorRow("Main ink (digits, ticks)", k.cText) { k.cText = it }
            colorRow("Accent", k.cAccent) { k.cAccent = it }
            colorRow("Face", k.cFace) { k.cFace = it }
            colorRow("Base / hub", k.cBase) { k.cBase = it }
            colorRow("Muted labels", k.cMuted) { k.cMuted = it }
            colorRow("Hour hand", k.cHour) { k.cHour = it }
            colorRow("Minute hand", k.cMin) { k.cMin = it }
        }
        note("Faces with weather, sun, moon, battery or next event use your Weather and Calendar widgets and phone data. Tapping the clock opens your alarm app.")
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch((a shr 16) and 255, (b shr 16) and 255) shl 16) or (ch((a shr 8) and 255, (b shr 8) and 255) shl 8) or ch(a and 255, b and 255)
    }

    private fun clockGallery() {
        val grid = android.widget.GridLayout(this)
        grid.columnCount = 3
        val sv = android.widget.ScrollView(this)
        sv.addView(grid)
        val dlg = AlertDialog.Builder(this).setTitle("Choose a face").setView(sv).setNegativeButton("Close", null).create()
        val cell = dp(104)
        val views = ArrayList<ImageView>()
        for (i in 0 until ClockStyles.names.size) {
            val box = android.widget.LinearLayout(this)
            box.orientation = android.widget.LinearLayout.VERTICAL
            box.gravity = android.view.Gravity.CENTER_HORIZONTAL
            box.setPadding(dp(4), dp(6), dp(4), dp(6))
            val iv = ImageView(this)
            iv.layoutParams = android.widget.LinearLayout.LayoutParams(cell, cell)
            iv.setBackgroundColor(Palette.of(this, Widgets.style(this, inst)).bg or (0xFF shl 24))
            views.add(iv)
            val tv = android.widget.TextView(this)
            tv.text = (if (i == inst.clock.style) "● " else "") + (i + 1).toString() + " " + ClockStyles.names[i]
            tv.textSize = 11f
            tv.gravity = android.view.Gravity.CENTER
            box.addView(iv)
            box.addView(tv)
            box.setOnClickListener {
                inst.clock.style = i
                save()
                dlg.dismiss()
                build()
            }
            grid.addView(box)
        }
        dlg.show()
        val st = Widgets.style(this, inst)
        val cfg = ClockCfg.fromJson(inst.clock.toJson())
        Thread {
            for (i in views.indices) {
                try {
                    cfg.style = i
                    val sdef = ClockStyles.at(i)
                    val sc = cell.toFloat() / maxOf(sdef.w, sdef.h)
                    val bmp = Widgets.withDensity(null) { ClockRenderer.render(this, st, cfg, (sdef.w * sc).toInt(), (sdef.h * sc).toInt(), true) }
                    runOnUiThread { views[i].setImageBitmap(bmp) }
                } catch (e: Exception) {
                }
            }
        }.start()
    }

    private fun calControls() {
        val cc = inst.cal
        startCard("Calendar")
        if (!Cal.granted(this)) {
            note("Allow Calendar access so the widget can read the calendars on this phone.")
            col.addView(Button2("Allow Calendar access") { requestPermissions(arrayOf(android.Manifest.permission.READ_CALENDAR), 6) })
        }
        spin("Style", listOf("Agenda", "Next up", "Month"), cc.style) { cc.style = it; save(); build() }
        if (cc.style != 2) slider("Days ahead", 1, 30, cc.days, " days") { cc.days = it }
        if (cc.style == 2) spin("Week starts on", listOf("Sunday", "Monday"), cc.weekStart) { cc.weekStart = it; save() }
        if (cc.style != 2) sw("Show location", cc.loc) { cc.loc = it; save() }
        val apps = CalWidget.candidates(this)
        spin("Corner icon opens", listOf("Ask / system default") + apps.map { it.second }, apps.indexOfFirst { it.first == cc.app } + 1) {
            cc.app = if (it == 0) "" else apps[it - 1].first
            save()
        }
        sw("Show all-day events", cc.allDay) { cc.allDay = it; save() }
        sw("Haptic tick on tap", cc.haptic) { cc.haptic = it; save() }
        val list = Cal.calendars(this)
        if (list.isNotEmpty()) {
            startCard("Calendars to show")
            val chosen = cc.cals.split(",").filter { it.isNotBlank() }.toMutableSet()
            for (ci in list) {
                sw(ci.name + (if (ci.account.isNotEmpty()) "  ·  " + ci.account else ""), chosen.isEmpty() || ci.id.toString() in chosen) { on ->
                    if (chosen.isEmpty()) list.forEach { chosen.add(it.id.toString()) }
                    if (on) chosen.add(ci.id.toString()) else chosen.remove(ci.id.toString())
                    cc.cals = if (chosen.size >= list.size) "" else chosen.joinToString(",")
                    save()
                }
            }
        }
        startCard("Proton Calendar setup")
        note("1. In Proton Calendar on the web: Settings, All settings, Calendars, Share with anyone, then Create link (full view). Use a link you can delete later.\n2. Install ICSx5 and add a subscription with that link.\n3. Allow Calendar access here. Proton can take up to a few hours to update the link.")
    }

    private fun wxControls() {
        val w = inst.wx
        startCard("Location")
        note(if (w.hasLoc) "Showing " + (if (w.place.isEmpty()) "your saved spot" else w.place) else "No location yet. Search for a city, or use where you are.")
        col.addView(Button2("Search by city or ZIP") { searchCity() })
        col.addView(Button2("Use my location") { useMyLocation() })

        startCard("Layout")
        note("Show, hide and reorder the parts.")
        val names = mapOf("current" to "Current conditions", "hourly" to "Hourly chips", "daily" to "Daily chips", "details" to "Details")
        for (p in w.parts()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(4))
            }
            val s = Switch(this).apply {
                text = names[p]
                isChecked = !w.isHidden(p)
                setOnCheckedChangeListener { _, on -> w.setHidden(p, !on); save() }
            }
            row.addView(s, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(arrow("▲") { w.move(p, -1); save(); build() })
            row.addView(arrow("▼") { w.move(p, 1); save(); build() })
            col.addView(row)
        }
        slider("Hourly cards shown at once", 0, 8, w.hourly, "") { w.hourly = it; if (w.hourTotal < it) w.hourTotal = it }
        slider("Daily cards shown at once", 0, 7, w.daily, "") { w.daily = it; if (w.dayTotal < it) w.dayTotal = it }
        slider("Hours you can scroll through", 6, 24, w.hourTotal, "") { w.hourTotal = it }
        slider("Days you can scroll through", 3, 8, w.dayTotal, "") { w.dayTotal = it }
        note("Cards shown at once is the visible width. Swipe a row sideways to reach the rest, up to the scroll limits above.")
        spin("Chip shape", listOf("Rounded", "Pill", "No background"), w.chip) { w.chip = it; save() }

        startCard("Look and units")
        spin("Units", listOf("Fahrenheit, mph", "Celsius, km/h"), if (w.metric) 1 else 0) { w.metric = it == 1; save() }
        spin("Icon style", listOf("Filled", "Outline"), w.iconStyle) { w.iconStyle = it; save() }
        spin("Weather source", listOf("Auto (Breezy if it has this place)", "Open-Meteo", "Breezy Weather"), w.source) { w.source = it; save(); fetchNow() }

        startCard("Details row")
        sw("UV index", w.uv) { w.uv = it; save() }
        sw("Humidity", w.humidity) { w.humidity = it; save() }
        sw("Wind", w.wind) { w.wind = it; save() }
        sw("Feels like", w.feels) { w.feels = it; save() }
        sw("Show updated time", w.updated) { w.updated = it; save() }
        col.addView(Button2("Refresh weather now") { fetchNow() })
        note("Open-Meteo needs no account or key. Breezy Weather is read straight from the Breezy app on your phone: allow it in the main page, under Breezy link, and add your place in Breezy.")
    }

    // ---------- weather location ----------

    private fun fetchNow() {
        if (id < 0) return
        val ctx = applicationContext
        val myId = id
        Thread {
            Wx.refresh(ctx, myId, true)
            WeatherWidget.updateAll(ctx)
            runOnUiThread { refresh() }
        }.start()
    }

    private fun setPlace(lat: Double, lon: Double, name: String) {
        val w = inst.wx
        w.hasLoc = true
        w.lat = lat
        w.lon = lon
        w.place = name
        save()
        fetchNow()
        build()
    }

    private fun searchCity() {
        val input = EditText(this)
        input.hint = "City or ZIP code"
        input.inputType = InputType.TYPE_CLASS_TEXT
        val box = FrameLayout(this)
        box.setPadding(dp(24), dp(12), dp(24), 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("Search by city or ZIP code")
            .setView(box)
            .setPositiveButton("Search") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) {
                    Thread {
                        val res = Wx.geocode(q)
                        runOnUiThread {
                            if (res.isEmpty()) {
                                Toast.makeText(this, "No match" + (Wx.lastError?.let { " ($it)" } ?: "") + ". Check your connection or try another spelling.", Toast.LENGTH_LONG).show()
                            } else {
                                val labels = res.map { if (it.detail.isEmpty()) it.name else it.name + ", " + it.detail }.toTypedArray()
                                AlertDialog.Builder(this)
                                    .setTitle("Pick one")
                                    .setItems(labels) { _, i -> setPlace(res[i].lat, res[i].lon, res[i].name) }
                                    .show()
                            }
                        }
                    }.start()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun useMyLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 9)
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        var best: Location? = null
        for (pv in lm.getProviders(true)) {
            val l = try { lm.getLastKnownLocation(pv) } catch (e: SecurityException) { null }
            if (l != null && (best == null || l.time > best.time)) best = l
        }
        val b = best
        if (b == null) {
            Toast.makeText(this, "Couldn't get a location fix. Search for your city instead.", Toast.LENGTH_LONG).show()
        } else {
            setPlace(Math.round(b.latitude * 100) / 100.0, Math.round(b.longitude * 100) / 100.0, "My location")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 6) {
            CalWidget.updateAll(this)
            build()
        }
        if (requestCode == 9 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) useMyLocation()
    }

    // ---------- controls ----------

    private fun startCard(title: String) {
        page.addView(TextView(this).apply {
            text = title.uppercase()
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.1f
            setTextColor(Ui.accent)
            setPadding(dp(6), dp(22), 0, dp(8))
        })
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.card, dp(20).toFloat())
            setPadding(dp(16), dp(10), dp(16), dp(16))
        }
        page.addView(c, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        col = c
    }

    private fun note(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 13f
            setTextColor(Ui.sub)
            setPadding(0, dp(6), 0, dp(2))
        })
    }

    private fun Button2(label: String, onTap: () -> Unit): android.widget.Button =
        android.widget.Button(this).apply {
            text = label
            setOnClickListener { onTap() }
        }

    private fun arrow(glyph: String, onTap: () -> Unit): TextView = TextView(this).apply {
        text = glyph
        textSize = 16f
        setTextColor(Ui.sub)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onTap() }
    }

    private fun sw(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        col.addView(Switch(this).apply {
            text = label
            isChecked = checked
            setPadding(0, dp(10), 0, dp(4))
            setOnCheckedChangeListener { _, on -> onChange(on) }
        })
    }

    private fun spin(label: String, opts: List<String>, sel: Int, onSel: (Int) -> Unit) {
        col.addView(TextView(this).apply {
            text = label
            textSize = 14f
            setPadding(0, dp(12), 0, dp(4))
        })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)
        var cur = sel.coerceIn(0, opts.size - 1)
        sp.setSelection(cur)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, i: Long) {
                if (pos != cur) {
                    cur = pos
                    onSel(pos)
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(sp)
    }

    private fun slider(label: String, min: Int, max: Int, value: Int, unit: String, set: (Int) -> Unit) {
        val head = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(12), 0, 0)
        }
        fun txt(v: Int) {
            head.text = "$label: $v$unit"
        }
        txt(value)
        val bar = SeekBar(this).apply {
            this.max = max - min
            progress = (value - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    set(p + min)
                    txt(p + min)
                    save()
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(head)
        col.addView(bar)
    }

    private fun fontRow() {
        col.addView(TextView(this).apply {
            text = "Font"
            textSize = 14f
            setPadding(0, dp(8), 0, dp(4))
        })
        val keys = ArrayList<String>()
        val names = ArrayList<String>()
        for ((k, n) in FontStore.builtin) {
            keys.add(k)
            names.add(n)
        }
        for (f in FontStore.uploaded(this)) {
            keys.add("file:$f")
            names.add(f.substringBeforeLast('.'))
        }
        keys.add("__upload")
        names.add("Upload font…")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val cur = keys.indexOf(style().font).let { if (it < 0) 0 else it }
        sp.setSelection(cur)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, i: Long) {
                val k = keys[pos]
                if (k == "__upload") {
                    sp.setSelection(cur)
                    val it = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(it, 7)
                } else if (k != style().font) {
                    style().font = k
                    save()
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(sp)
        note("Upload a .ttf or .otf file and it becomes available to every widget.")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val key = FontStore.import(this, uri)
        if (key == null) {
            Toast.makeText(this, "That file isn't a usable font", Toast.LENGTH_LONG).show()
            return
        }
        if (editable()) {
            style().font = key
            save()
        }
        build()
    }

    private fun colorRow(label: String, color: Int, set: (Int) -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(4))
        }
        r.addView(TextView(this).apply {
            text = label
            textSize = 15f
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = View(this)
        sw.background = Ui.round(color, dp(12).toFloat())
        r.addView(sw, LinearLayout.LayoutParams(dp(56), dp(32)))
        r.setOnClickListener {
            pickColor(label, color) { c ->
                set(c)
                save()
                build()
            }
        }
        col.addView(r)
    }

    private fun pickColor(title: String, start: Int, done: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(start, hsv)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
        }
        val sw = View(this)
        fun cur() = Color.HSVToColor(hsv)
        fun paint() {
            sw.background = Ui.round(cur(), dp(12).toFloat())
        }
        paint()
        box.addView(sw, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))
        fun bar(name: String, max: Int, init: Int, on: (Int) -> Unit) {
            box.addView(TextView(this).apply {
                text = name
                textSize = 13f
                setPadding(0, dp(12), 0, 0)
            })
            box.addView(SeekBar(this).apply {
                this.max = max
                progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                        on(p)
                        paint()
                    }

                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }
        Ui.polish(box) { dp(it) }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Done") { _, _ -> done(cur()) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
