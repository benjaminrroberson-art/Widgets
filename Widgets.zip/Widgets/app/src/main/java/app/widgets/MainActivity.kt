package app.widgets

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var scroll: ScrollView
    private lateinit var page: LinearLayout
    private lateinit var col: LinearLayout
    private var density = 1f

    private fun dp(i: Int) = (i * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        Ui.init(this)
        scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(20), dp(12), dp(20), dp(32))
        scroll.addView(page, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
        Ui.window(this)
        Live.ensure(this)
    }

    override fun onResume() {
        super.onResume()
        density = resources.displayMetrics.density
        val y = scroll.scrollY
        build()
        scroll.post { scroll.scrollTo(0, y) }
        RingerWidget.updateAll(this)
    }

    private fun build() {
        page.removeAllViews()
        col = page
        page.addView(TextView(this).apply {
            text = "Widgets"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(10), 0, dp(6))
        })
        page.addView(TextView(this).apply {
            text = "Design every widget here. Changes show live in the preview and on your home screen."
            textSize = 13.5f
            setTextColor(Ui.sub)
            setPadding(dp(2), 0, dp(2), dp(4))
        })

        startCard("Widgets")
        val ids = RingerWidget.ids(this)
        if (ids.isEmpty()) {
            note("No widgets on your home screen yet. Add one below, then tap it here to design it.")
        }
        for (id in ids) {
            val inst = Store.inst(this, id)
            navRow("Ringer mode", if (inst.useGlobal) "Uses the global theme" else "Has its own look") {
                startActivity(Intent(this, EditorActivity::class.java).putExtra("id", id))
            }
        }
        col.addView(Button(this).apply {
            text = "Add a ringer widget"
            setOnClickListener {
                val m = AppWidgetManager.getInstance(this@MainActivity)
                if (m.isRequestPinAppWidgetSupported) {
                    m.requestPinAppWidget(ComponentName(this@MainActivity, RingerWidget::class.java), null, null)
                } else {
                    Toast.makeText(this@MainActivity, "Long-press your home screen, then Widgets, then Widgets", Toast.LENGTH_LONG).show()
                }
            }
        })

        startCard("Theme")
        note("The font, corners, opacity and colors every widget uses, unless a widget has its own look.")
        navRow("Global theme", "Font, corners, opacity, colors") {
            startActivity(Intent(this, EditorActivity::class.java).putExtra("id", -1))
        }

        startCard("Setup")
        val dnd = getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        note((if (dnd) "✅ " else "❌ ") + "Do Not Disturb access (needed for the Silent button)")
        if (!dnd) {
            col.addView(Button(this).apply {
                text = "Open settings"
                setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            })
        }
        if (Build.VERSION.SDK_INT >= 33) {
            val ok = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            note((if (ok) "✅ " else "❌ ") + "Notifications (lets the small “widgets are live” notice show)")
            if (!ok) {
                col.addView(Button(this).apply {
                    text = "Allow"
                    setOnClickListener { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
                })
            }
        }
        col.addView(Switch(this).apply {
            text = "Keep widgets live"
            isChecked = Store.live(this@MainActivity)
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                Store.setLive(this@MainActivity, on)
                if (on) Live.ensure(this@MainActivity) else Live.stop(this@MainActivity)
            }
        })
        note("A tiny background service so the ringer widget updates when you change the mode with the volume keys or quick settings. Turn it off if you only use the widget to switch modes.")

        Ui.polish(page) { dp(it) }
    }

    private fun startCard(title: String) {
        page.addView(TextView(this).apply {
            text = title.uppercase()
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.1f
            setTextColor(Ui.accent)
            setPadding(dp(6), dp(22), 0, dp(8))
        })
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.card, dp(20).toFloat())
            setPadding(dp(16), dp(10), dp(16), dp(16))
        }
        page.addView(c, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        col = c
    }

    private fun note(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 13f
            setTextColor(Ui.sub)
            setPadding(0, dp(8), 0, dp(2))
        })
    }

    private fun navRow(title: String, sub: String, onTap: () -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(12), dp(2), dp(12))
            setOnClickListener { onTap() }
        }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        })
        mid.addView(TextView(this).apply {
            text = sub
            textSize = 12.5f
            setTextColor(Ui.sub)
        })
        r.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(TextView(this).apply {
            text = "›"
            textSize = 24f
            setTextColor(Ui.sub)
        })
        col.addView(r)
    }
}
