package app.widgets

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var scroll: ScrollView
    private lateinit var page: LinearLayout
    private lateinit var col: LinearLayout
    private var density = 1f

    private fun dp(i: Int) = (i * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        Ui.init(this)
        scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(20), dp(12), dp(20), dp(32))
        scroll.addView(page, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
        Ui.window(this)
        Live.ensure(this)
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i?.getBooleanExtra("dnd", false) == true) {
            i.removeExtra("dnd")
            openDnd()
        }
    }

    override fun onResume() {
        super.onResume()
        density = resources.displayMetrics.density
        val y = scroll.scrollY
        build()
        scroll.post { scroll.scrollTo(0, y) }
        Widgets.updateAll(this)
        Wx.refreshAll(this, false)
    }

    private fun openAppSettings() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            Toast.makeText(this, "Open Settings, Apps, Widgets, Permissions", Toast.LENGTH_LONG).show()
        }
    }

    private fun openDnd() {
        try {
            val i = Intent("android.settings.NOTIFICATION_POLICY_ACCESS_DETAIL_SETTINGS")
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, "Open Settings, then Notifications, then Do Not Disturb access", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openListener() {
        try {
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                    .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, ComponentName(this, MediaListener::class.java).flattenToString())
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, "Open Settings, then Notifications, then Notification access", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun build() {
        page.removeAllViews()
        col = page
        page.addView(TextView(this).apply {
            text = "Widgets"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(10), 0, dp(6))
        })
        val net = checkSelfPermission(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
        if (!net) {
            if (!Store.getBool(this, "asked_net", false)) {
                Store.putBool(this, "asked_net", true)
                requestPermissions(arrayOf(Manifest.permission.INTERNET), 3)
            }
            page.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply {
                    setColor(0x33FF5252)
                    cornerRadius = dp(16).toFloat()
                }
                addView(TextView(this@MainActivity).apply {
                    text = "Network is off for Widgets"
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                })
                addView(TextView(this@MainActivity).apply {
                    text = "Weather and city search need internet. Turn on Network in this app's permissions."
                    textSize = 13f
                    setTextColor(Ui.sub)
                })
                addView(Button(this@MainActivity).apply {
                    text = "Open permission settings"
                    setOnClickListener { openAppSettings() }
                })
            })
        }
        page.addView(TextView(this).apply {
            text = "Tap a widget to design it. Changes show live here and on your home screen."
            textSize = 13.5f
            setTextColor(Ui.sub)
            setPadding(dp(2), 0, dp(2), dp(4))
        })

        val placed = Widgets.all(this)
        if (placed.isEmpty()) {
            startCard("Your widgets")
            note("None on your home screen yet. Add one below.")
        } else {
            page.addView(sectionLabel("Your widgets"))
            val m = AppWidgetManager.getInstance(this)
            for ((id, type) in placed) previewCard(m, id, type)
        }

        startCard("Add a widget")
        for (t in Widgets.types) {
            navRow(Widgets.label(t), Widgets.blurb(t)) { pin(t) }
        }

        startCard("Theme")
        note("The font, corners, opacity and colors every widget uses, unless a widget has its own look.")
        navRow("Global theme", "Font, text size, corners, opacity, colors") {
            startActivity(Intent(this, EditorActivity::class.java).putExtra("id", -1))
        }

        startCard("Setup")
        note((if (net) "✅ " else "❌ ") + "Network (needed for weather and city search)")
        if (!net) {
            col.addView(Button(this).apply {
                text = "Open permission settings"
                setOnClickListener { openAppSettings() }
            })
            note("On GrapheneOS: Permissions, then turn Network on.")
        }
        val dnd = getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        note((if (dnd) "✅ " else "❌ ") + "Do Not Disturb access (needed for the Silent button)")
        if (!dnd) {
            col.addView(Button(this).apply {
                text = "Open Do Not Disturb access"
                setOnClickListener { openDnd() }
            })
            note("If Widgets isn't listed: App info for Widgets, tap the ⋮ menu, choose Allow restricted settings, then try again.")
        }
        val np = NpState.granted(this)
        note((if (np) "✅ " else "❌ ") + "Notification access (lets Now playing see your music)")
        if (!np) {
            col.addView(Button(this).apply {
                text = "Open Notification access"
                setOnClickListener { openListener() }
            })
        }
        if (Build.VERSION.SDK_INT >= 33) {
            val ok = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            note((if (ok) "✅ " else "❌ ") + "Notifications (for the small “widgets are live” notice)")
            if (!ok) {
                col.addView(Button(this).apply {
                    text = "Allow"
                    setOnClickListener { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
                })
            }
        }
        col.addView(Switch(this).apply {
            text = "Keep widgets live"
            isChecked = Store.live(this@MainActivity)
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                Store.setLive(this@MainActivity, on)
                if (on) Live.ensure(this@MainActivity) else Live.stop(this@MainActivity)
            }
        })
        note("A tiny background service so widgets update when the ringer, theme or wallpaper changes.")

        startCard("Connection test")
        note("Checks whether Widgets can reach the weather and search services.")
        col.addView(Button(this).apply {
            text = "Test internet access"
            setOnClickListener {
                text = "Testing\u2026"
                Thread {
                    val out = try { Wx.netTest() } catch (e: Exception) { "Failed: " + e.message }
                    runOnUiThread {
                        text = "Test internet access"
                        AlertDialog.Builder(this@MainActivity).setTitle("Connection test").setMessage(out).setPositiveButton("Close", null).show()
                    }
                }.start()
            }
        })

        startCard("Breezy Weather link (experimental)")
        note("Weather uses Open-Meteo for now. This test asks Breezy Weather what its data-sharing provider returns, so I can wire it up properly.")
        val bz = checkSelfPermission("org.breezyweather.READ_PROVIDER") == PackageManager.PERMISSION_GRANTED
        note((if (bz) "\u2705 " else "\u274C ") + "Permission to read Breezy Weather data")
        if (!bz) {
            col.addView(Button(this).apply {
                text = "Allow Breezy data access"
                setOnClickListener {
                    requestPermissions(arrayOf("org.breezyweather.READ_PROVIDER"), 5)
                    Toast.makeText(this@MainActivity, "If no prompt appears: Settings, Apps, Widgets, Permissions", Toast.LENGTH_LONG).show()
                }
            })
        }
        col.addView(Button(this).apply {
            text = "Test Breezy link"
            setOnClickListener {
                val out = try { Wx.breezyProbe(this@MainActivity) } catch (e: Exception) { "Failed: " + e.message }
                val tv = TextView(this@MainActivity).apply {
                    text = out
                    textSize = 11f
                    typeface = Typeface.MONOSPACE
                    setTextIsSelectable(true)
                    setPadding(dp(20), dp(12), dp(20), dp(12))
                }
                val sv = ScrollView(this@MainActivity)
                sv.addView(tv)
                AlertDialog.Builder(this@MainActivity).setTitle("Breezy probe").setView(sv).setPositiveButton("Close", null).show()
            }
        })

        Ui.polish(page) { dp(it) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        build()
    }

    private fun pin(t: String) {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) {
            m.requestPinAppWidget(ComponentName(this, Widgets.cls(t)), null, null)
        } else {
            Toast.makeText(this, "Long-press your home screen, then Widgets, then Widgets", Toast.LENGTH_LONG).show()
        }
    }

    private fun sectionLabel(t: String) = TextView(this).apply {
        text = t.uppercase()
        textSize = 12.5f
        setTypeface(typeface, Typeface.BOLD)
        letterSpacing = 0.1f
        setTextColor(Ui.accent)
        setPadding(dp(6), dp(22), 0, dp(8))
    }

    /** A card that shows the widget as it really looks, and opens its editor when tapped. */
    private fun previewCard(m: AppWidgetManager, id: Int, type: String) {
        val inst = Store.inst(this, id)
        val (w, h) = Widgets.sizePx(this, m, id, type)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.card, dp(20).toFloat())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { startActivity(Intent(this@MainActivity, EditorActivity::class.java).putExtra("id", id)) }
        }
        val back = FrameLayout(this).apply {
            val g = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF3B5BA9.toInt(), 0xFF8E5BA8.toInt(), 0xFFE0875A.toInt())
            )
            g.cornerRadius = dp(14).toFloat()
            background = g
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }
        val img = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            try {
                setImageBitmap(Widgets.render(this@MainActivity, type, id, inst, w, h, true))
            } catch (e: Exception) {
            }
        }
        back.addView(img, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        card.addView(back, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(10), dp(4), dp(0))
        }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(TextView(this).apply {
            text = Widgets.label(type)
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        })
        mid.addView(TextView(this).apply {
            text = if (inst.useGlobal) "Uses the global theme" else "Has its own look"
            textSize = 12.5f
            setTextColor(Ui.sub)
        })
        row.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "Customize ›"
            textSize = 14f
            setTextColor(Ui.accent)
        })
        card.addView(row)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        page.addView(card, lp)
    }

    private fun startCard(title: String) {
        page.addView(sectionLabel(title))
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(Ui.card, dp(20).toFloat())
            setPadding(dp(16), dp(10), dp(16), dp(16))
        }
        page.addView(c, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        col = c
    }

    private fun note(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 13f
            setTextColor(Ui.sub)
            setPadding(0, dp(8), 0, dp(2))
        })
    }

    private fun navRow(title: String, sub: String, onTap: () -> Unit) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(12), dp(2), dp(12))
            setOnClickListener { onTap() }
        }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        })
        mid.addView(TextView(this).apply {
            text = sub
            textSize = 12.5f
            setTextColor(Ui.sub)
        })
        r.addView(mid, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(TextView(this).apply {
            text = "›"
            textSize = 24f
            setTextColor(Ui.sub)
        })
        col.addView(r)
    }
}
