package app.widgets

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File

/** The look shared by every widget (global theme), or one widget's own override of it. */
class Style {
    var font = ""            // "" = system, "sans-serif-light" etc, or "file:<name>" for an uploaded font
    var textScale = 100      // percent
    var corner = 28          // dp
    var bgOpacity = 0        // percent, 0 = fully transparent
    var colorMode = 0        // 0 = wallpaper colors, 1 = custom
    var accent = 0xFF7C9CFFL.toInt()
    var text = 0xFFFFFFFFL.toInt()
    var bg = 0xFF181B21L.toInt()

    fun toJson(): JSONObject = JSONObject()
        .put("font", font).put("textScale", textScale).put("corner", corner)
        .put("bgOpacity", bgOpacity).put("colorMode", colorMode)
        .put("accent", accent).put("text", text).put("bg", bg)

    fun copy(): Style = fromJson(toJson())

    companion object {
        fun fromJson(j: JSONObject?): Style {
            val s = Style()
            if (j == null) return s
            s.font = j.optString("font", s.font)
            s.textScale = j.optInt("textScale", s.textScale)
            s.corner = j.optInt("corner", s.corner)
            s.bgOpacity = j.optInt("bgOpacity", s.bgOpacity)
            s.colorMode = j.optInt("colorMode", s.colorMode)
            s.accent = j.optInt("accent", s.accent)
            s.text = j.optInt("text", s.text)
            s.bg = j.optInt("bg", s.bg)
            return s
        }
    }
}

/** Settings that only the ringer widget has. */
class RingerCfg {
    var hl = 0          // 0 = glow, 1 = pill, 2 = both
    var glow = 70       // percent
    var iconSize = 100  // percent
    var spacing = 100   // percent of the widget width the three icons spread across
    var labels = false
    var haptic = true

    fun toJson(): JSONObject = JSONObject()
        .put("hl", hl).put("glow", glow).put("iconSize", iconSize)
        .put("spacing", spacing).put("labels", labels).put("haptic", haptic)

    companion object {
        fun fromJson(j: JSONObject?): RingerCfg {
            val c = RingerCfg()
            if (j == null) return c
            c.hl = j.optInt("hl", c.hl)
            c.glow = j.optInt("glow", c.glow)
            c.iconSize = j.optInt("iconSize", c.iconSize)
            c.spacing = j.optInt("spacing", c.spacing)
            c.labels = j.optBoolean("labels", c.labels)
            c.haptic = j.optBoolean("haptic", c.haptic)
            return c
        }
    }
}

/** One placed widget: whether it follows the global theme, plus its own settings. */
class Inst(val id: Int) {
    var useGlobal = true
    var style = Style()
    var ringer = RingerCfg()
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("widgets", Context.MODE_PRIVATE)

    private fun parse(s: String?): JSONObject? = try {
        if (s == null) null else JSONObject(s)
    } catch (e: Exception) {
        null
    }

    fun theme(c: Context): Style = Style.fromJson(parse(sp(c).getString("theme", null)))

    fun saveTheme(c: Context, s: Style) {
        sp(c).edit().putString("theme", s.toJson().toString()).apply()
    }

    fun inst(c: Context, id: Int): Inst {
        val i = Inst(id)
        val j = parse(sp(c).getString("inst_$id", null)) ?: return i
        i.useGlobal = j.optBoolean("g", true)
        i.style = Style.fromJson(j.optJSONObject("style"))
        i.ringer = RingerCfg.fromJson(j.optJSONObject("ringer"))
        return i
    }

    fun saveInst(c: Context, i: Inst) {
        val j = JSONObject().put("g", i.useGlobal).put("style", i.style.toJson()).put("ringer", i.ringer.toJson())
        sp(c).edit().putString("inst_${i.id}", j.toString()).apply()
    }

    fun deleteInst(c: Context, id: Int) {
        sp(c).edit().remove("inst_$id").apply()
    }

    fun live(c: Context): Boolean = sp(c).getBoolean("live", true)

    fun setLive(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("live", on).apply()
    }
}

class Pal(val accent: Int, val text: Int, val bg: Int)

object Palette {
    fun dark(c: Context): Boolean =
        (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    fun of(c: Context, s: Style): Pal {
        val dark = dark(c)
        if (s.colorMode == 1) return Pal(s.accent, s.text, s.bg)
        return if (Build.VERSION.SDK_INT >= 31) {
            Pal(
                c.getColor(if (dark) android.R.color.system_accent1_200 else android.R.color.system_accent1_600),
                c.getColor(if (dark) android.R.color.system_neutral1_50 else android.R.color.system_neutral1_900),
                c.getColor(if (dark) android.R.color.system_neutral1_900 else android.R.color.system_neutral1_10)
            )
        } else {
            Pal(
                if (dark) 0xFF7C9CFFL.toInt() else 0xFF3F63E0L.toInt(),
                if (dark) Color.WHITE else 0xFF14161AL.toInt(),
                if (dark) 0xFF181B21L.toInt() else Color.WHITE
            )
        }
    }
}

object FontStore {
    val builtin = listOf(
        "" to "System default",
        "sans-serif-light" to "Light",
        "sans-serif-medium" to "Medium",
        "sans-serif-condensed" to "Condensed",
        "serif" to "Serif",
        "monospace" to "Monospace",
        "casual" to "Casual",
        "cursive" to "Cursive"
    )

    private val cache = HashMap<String, Typeface>()

    fun dir(c: Context): File {
        val d = File(c.filesDir, "fonts")
        d.mkdirs()
        return d
    }

    fun uploaded(c: Context): List<String> = dir(c).list()?.sorted() ?: emptyList()

    fun typeface(c: Context, key: String): Typeface {
        cache[key]?.let { return it }
        var t: Typeface = Typeface.DEFAULT
        try {
            if (key.startsWith("file:")) {
                val f = File(dir(c), key.removePrefix("file:"))
                if (f.exists()) t = Typeface.createFromFile(f)
            } else if (key.isNotEmpty()) {
                t = Typeface.create(key, Typeface.NORMAL)
            }
        } catch (e: Exception) {
        }
        cache[key] = t
        return t
    }

    /** Copies a picked font file into the app. Returns its key ("file:name") or null if unusable. */
    fun import(c: Context, uri: Uri): String? {
        return try {
            var name = "font"
            c.contentResolver.query(uri, null, null, null, null)?.use {
                if (it.moveToFirst()) {
                    val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = it.getString(i) ?: name
                }
            }
            name = name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            if (!name.lowercase().endsWith(".ttf") && !name.lowercase().endsWith(".otf")) name += ".ttf"
            val out = File(dir(c), name)
            c.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
            try {
                Typeface.createFromFile(out)
            } catch (e: Exception) {
                out.delete()
                return null
            }
            cache.remove("file:$name")
            "file:$name"
        } catch (e: Exception) {
            null
        }
    }
}
