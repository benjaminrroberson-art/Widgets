package app.widgets

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File

/** The look shared by every widget (global theme), or one widget's own override of it. */
class Style {
    var font = ""            // "" = system, "sans-serif-light" etc, or "file:<name>" for an uploaded font
    var textScale = 100      // percent
    var corner = 28          // dp
    var bgOpacity = 0        // percent, 0 = fully transparent
    var colorMode = 0        // 0 = wallpaper colors, 1 = custom
    var accent = 0xFF7C9CFFL.toInt()
    var text = 0xFFFFFFFFL.toInt()
    var bg = 0xFF181B21L.toInt()

    fun toJson(): JSONObject = JSONObject()
        .put("font", font).put("textScale", textScale).put("corner", corner)
        .put("bgOpacity", bgOpacity).put("colorMode", colorMode)
        .put("accent", accent).put("text", text).put("bg", bg)

    fun copy(): Style = fromJson(toJson())

    companion object {
        fun fromJson(j: JSONObject?): Style {
            val s = Style()
            if (j == null) return s
            s.font = j.optString("font", s.font)
            s.textScale = j.optInt("textScale", s.textScale)
            s.corner = j.optInt("corner", s.corner)
            s.bgOpacity = j.optInt("bgOpacity", s.bgOpacity)
            s.colorMode = j.optInt("colorMode", s.colorMode)
            s.accent = j.optInt("accent", s.accent)
            s.text = j.optInt("text", s.text)
            s.bg = j.optInt("bg", s.bg)
            return s
        }
    }
}

/** Settings that only the ringer widget has. */
class RingerCfg {
    var hl = 0          // 0 = glow, 1 = pill, 2 = both
    var glow = 70       // percent
    var iconSize = 100  // percent
    var spacing = 100   // percent of the widget width the three icons spread across
    var labels = false
    var haptic = true

    fun toJson(): JSONObject = JSONObject()
        .put("hl", hl).put("glow", glow).put("iconSize", iconSize)
        .put("spacing", spacing).put("labels", labels).put("haptic", haptic)

    companion object {
        fun fromJson(j: JSONObject?): RingerCfg {
            val c = RingerCfg()
            if (j == null) return c
            c.hl = j.optInt("hl", c.hl)
            c.glow = j.optInt("glow", c.glow)
            c.iconSize = j.optInt("iconSize", c.iconSize)
            c.spacing = j.optInt("spacing", c.spacing)
            c.labels = j.optBoolean("labels", c.labels)
            c.haptic = j.optBoolean("haptic", c.haptic)
            return c
        }
    }
}


/** Settings that only the Now Playing widget has. */
class NpCfg {
    var progress = true
    var wavy = true
    var like = true
    var shuffleRepeat = true
    var artAccent = false
    var haptic = true

    fun toJson(): JSONObject = JSONObject()
        .put("progress", progress).put("wavy", wavy).put("like", like).put("sr", shuffleRepeat)
        .put("artAccent", artAccent).put("haptic", haptic)

    companion object {
        fun fromJson(j: JSONObject?): NpCfg {
            val c = NpCfg()
            if (j == null) return c
            c.progress = j.optBoolean("progress", c.progress)
            c.wavy = j.optBoolean("wavy", c.wavy)
            c.like = j.optBoolean("like", c.like)
            c.shuffleRepeat = j.optBoolean("sr", c.shuffleRepeat)
            c.artAccent = j.optBoolean("artAccent", c.artAccent)
            c.haptic = j.optBoolean("haptic", c.haptic)
            return c
        }
    }
}

/** Settings that only the Weather widget has. */
class WxCfg {
    var metric = false
    var iconStyle = 0        // 0 = filled, 1 = outline
    var hourly = 5
    var daily = 4
    var source = 0 // 0 auto (Breezy when it has this place), 1 Open-Meteo, 2 Breezy Weather
    var hourTotal = 24
    var dayTotal = 8
    var chip = 0             // 0 = rounded, 1 = pill, 2 = no background
    var order = "current,hourly,daily,details"
    var hidden = ""
    var uv = true
    var humidity = true
    var wind = true
    var feels = false
    var updated = true
    var hasLoc = false
    var lat = 0.0
    var lon = 0.0
    var place = ""

    fun parts(): List<String> {
        val all = listOf("current", "hourly", "daily", "details")
        val got = order.split(",").filter { it in all }.toMutableList()
        for (a in all) if (a !in got) got.add(a)
        return got
    }

    fun isHidden(p: String) = hidden.split(",").contains(p)

    fun visible(): List<String> = parts().filter { !isHidden(it) }

    fun setHidden(p: String, hide: Boolean) {
        val set = hidden.split(",").filter { it.isNotEmpty() }.toMutableSet()
        if (hide) set.add(p) else set.remove(p)
        hidden = set.joinToString(",")
    }

    fun move(p: String, dir: Int) {
        val l = parts().toMutableList()
        val i = l.indexOf(p)
        val j = i + dir
        if (i < 0 || j < 0 || j >= l.size) return
        l.removeAt(i)
        l.add(j, p)
        order = l.joinToString(",")
    }

    fun toJson(): JSONObject = JSONObject()
        .put("metric", metric).put("iconStyle", iconStyle).put("hourly", hourly).put("daily", daily).put("src", source).put("ht", hourTotal).put("dt", dayTotal)
        .put("chip", chip).put("order", order).put("hidden", hidden)
        .put("uv", uv).put("humidity", humidity).put("wind", wind).put("feels", feels).put("updated", updated)
        .put("hasLoc", hasLoc).put("lat", lat).put("lon", lon).put("place", place)

    companion object {
        fun fromJson(j: JSONObject?): WxCfg {
            val c = WxCfg()
            if (j == null) return c
            c.metric = j.optBoolean("metric", c.metric)
            c.iconStyle = j.optInt("iconStyle", c.iconStyle)
            c.hourly = j.optInt("hourly", c.hourly)
            c.daily = j.optInt("daily", c.daily)
            c.source = j.optInt("src", c.source)
            c.hourTotal = j.optInt("ht", c.hourTotal)
            c.dayTotal = j.optInt("dt", c.dayTotal)
            c.chip = j.optInt("chip", c.chip)
            c.order = j.optString("order", c.order)
            c.hidden = j.optString("hidden", c.hidden)
            c.uv = j.optBoolean("uv", c.uv)
            c.humidity = j.optBoolean("humidity", c.humidity)
            c.wind = j.optBoolean("wind", c.wind)
            c.feels = j.optBoolean("feels", c.feels)
            c.updated = j.optBoolean("updated", c.updated)
            c.hasLoc = j.optBoolean("hasLoc", c.hasLoc)
            c.lat = j.optDouble("lat", c.lat)
            c.lon = j.optDouble("lon", c.lon)
            c.place = j.optString("place", c.place)
            return c
        }
    }
}

/** Settings that only the calendar widget has. */
class CalCfg {
    var style = 0        // 0 agenda, 1 next up, 2 month
    var cals = ""        // comma-separated calendar ids, "" = all
    var days = 14
    var weekStart = 0    // 0 Sunday, 1 Monday
    var loc = true
    var allDay = true
    var haptic = true
    var app = ""         // package opened by the corner icon, "" = Android decides

    fun toJson(): JSONObject = JSONObject()
        .put("app", app).put("style", style).put("cals", cals).put("days", days).put("ws", weekStart)
        .put("loc", loc).put("allDay", allDay).put("haptic", haptic)

    companion object {
        fun fromJson(j: JSONObject?): CalCfg {
            val c = CalCfg()
            if (j == null) return c
            c.style = j.optInt("style", c.style)
            c.cals = j.optString("cals", c.cals)
            c.days = j.optInt("days", c.days)
            c.weekStart = j.optInt("ws", c.weekStart)
            c.loc = j.optBoolean("loc", c.loc)
            c.allDay = j.optBoolean("allDay", c.allDay)
            c.haptic = j.optBoolean("haptic", c.haptic)
            c.app = j.optString("app", c.app)
            return c
        }
    }
}

/** Settings that only the clock widget has. */
class ClockCfg {
    var style = 0
    var h24 = false
    var date = true
    var tz2 = "Europe/London"
    var font = ""                 // "" = same as theme
    var handScale = 100           // percent
    var custom = false            // use the colors below instead of the theme's
    var cText = 0xFFFFFFFFL.toInt()
    var cAccent = 0xFF7C9CFFL.toInt()
    var cBase = 0xFF181B21L.toInt()
    var cFace = 0xFF2A2D34L.toInt()
    var cMuted = 0x99FFFFFFL.toInt()
    var cHour = 0xFFFFFFFFL.toInt()
    var cMin = 0xFF7C9CFFL.toInt()
    var ampm = true
    var zero = false
    var dateFmt = 0               // 0 "Saturday, Nov 14", 1 "Saturday, 14 Nov", 2 "Saturday 11/14"
    var scale = 100               // percent, size of the whole face
    var depth = 100               // percent, strength of soft shadows
    val opts = HashMap<String, Int>()   // per-face options, keyed "Face.option"

    fun toJson(): JSONObject = JSONObject().put("style", style).put("h24", h24).put("date", date).put("tz2", tz2)
        .put("font", font).put("hs", handScale).put("custom", custom).put("cText", cText).put("cAccent", cAccent)
        .put("cBase", cBase).put("cFace", cFace).put("cMuted", cMuted).put("cHour", cHour).put("cMin", cMin)
        .put("ampm", ampm).put("zero", zero).put("dateFmt", dateFmt).put("scale", scale).put("depth", depth)
        .put("opts", JSONObject().also { o -> opts.forEach { (k, v) -> o.put(k, v) } })

    companion object {
        fun fromJson(j: JSONObject?): ClockCfg {
            val c = ClockCfg()
            if (j == null) return c
            c.style = j.optInt("style", c.style)
            c.h24 = j.optBoolean("h24", c.h24)
            c.date = j.optBoolean("date", c.date)
            c.tz2 = j.optString("tz2", c.tz2)
            c.font = j.optString("font", c.font)
            c.handScale = j.optInt("hs", c.handScale)
            c.custom = j.optBoolean("custom", c.custom)
            c.cText = j.optInt("cText", c.cText)
            c.cAccent = j.optInt("cAccent", c.cAccent)
            c.cBase = j.optInt("cBase", c.cBase)
            c.cFace = j.optInt("cFace", c.cFace)
            c.cMuted = j.optInt("cMuted", c.cMuted)
            c.cHour = j.optInt("cHour", c.cHour)
            c.cMin = j.optInt("cMin", c.cMin)
            c.ampm = j.optBoolean("ampm", c.ampm)
            c.zero = j.optBoolean("zero", c.zero)
            c.dateFmt = j.optInt("dateFmt", c.dateFmt)
            c.scale = j.optInt("scale", c.scale)
            c.depth = j.optInt("depth", c.depth)
            j.optJSONObject("opts")?.let { o -> o.keys().forEach { k -> c.opts[k] = o.optInt(k) } }
            return c
        }
    }
}

/** One placed widget: whether it follows the global theme, plus its own settings. */
class Inst(val id: Int) {
    var useGlobal = true
    var lock = true
    var style = Style()
    var ringer = RingerCfg()
    var np = NpCfg()
    var wx = WxCfg()
    var cal = CalCfg()
    var clock = ClockCfg()
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("widgets", Context.MODE_PRIVATE)

    private fun parse(s: String?): JSONObject? = try {
        if (s == null) null else JSONObject(s)
    } catch (e: Exception) {
        null
    }

    fun theme(c: Context): Style = Style.fromJson(parse(sp(c).getString("theme", null)))

    fun saveTheme(c: Context, s: Style) {
        sp(c).edit().putString("theme", s.toJson().toString()).apply()
    }

    fun inst(c: Context, id: Int): Inst {
        val i = Inst(id)
        val j = parse(sp(c).getString("inst_$id", null)) ?: return i
        i.useGlobal = j.optBoolean("g", true)
        i.lock = j.optBoolean("lock", true)
        i.style = Style.fromJson(j.optJSONObject("style"))
        i.ringer = RingerCfg.fromJson(j.optJSONObject("ringer"))
        i.np = NpCfg.fromJson(j.optJSONObject("np"))
        i.wx = WxCfg.fromJson(j.optJSONObject("wx"))
        i.cal = CalCfg.fromJson(j.optJSONObject("cal"))
        i.clock = ClockCfg.fromJson(j.optJSONObject("clock"))
        return i
    }

    fun saveInst(c: Context, i: Inst) {
        val j = JSONObject().put("g", i.useGlobal).put("lock", i.lock).put("style", i.style.toJson()).put("ringer", i.ringer.toJson()).put("np", i.np.toJson()).put("wx", i.wx.toJson()).put("cal", i.cal.toJson()).put("clock", i.clock.toJson())
        sp(c).edit().putString("inst_${i.id}", j.toString()).apply()
    }

    fun deleteInst(c: Context, id: Int) {
        sp(c).edit().remove("inst_$id").remove("wxj_$id").remove("wxt_$id").remove("shown_$id").remove("wxg_$id").remove("wxsig_$id").remove("calg_$id").remove("calsel_$id").remove("calmon_$id").remove("calsig_$id").apply()
    }

    fun getStr(c: Context, k: String): String? = sp(c).getString(k, null)
    fun putStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun getLong(c: Context, k: String, d: Long): Long = sp(c).getLong(k, d)
    fun putLong(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
    fun getFloat(c: Context, k: String, d: Float): Float = sp(c).getFloat(k, d)
    fun putFloat(c: Context, k: String, v: Float) { sp(c).edit().putFloat(k, v).apply() }
    fun getBool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }

    fun live(c: Context): Boolean = sp(c).getBoolean("live", true)

    fun setLive(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("live", on).apply()
    }
}

class Pal(val accent: Int, val text: Int, val bg: Int)

object Palette {
    fun dark(c: Context): Boolean =
        (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    fun of(c: Context, s: Style): Pal {
        val dark = dark(c)
        if (s.colorMode == 1) return Pal(s.accent, s.text, s.bg)
        return if (Build.VERSION.SDK_INT >= 31) {
            Pal(
                c.getColor(if (dark) android.R.color.system_accent1_200 else android.R.color.system_accent1_600),
                c.getColor(if (dark) android.R.color.system_neutral1_50 else android.R.color.system_neutral1_900),
                c.getColor(if (dark) android.R.color.system_neutral1_900 else android.R.color.system_neutral1_10)
            )
        } else {
            Pal(
                if (dark) 0xFF7C9CFFL.toInt() else 0xFF3F63E0L.toInt(),
                if (dark) Color.WHITE else 0xFF14161AL.toInt(),
                if (dark) 0xFF181B21L.toInt() else Color.WHITE
            )
        }
    }
}

object FontStore {
    val builtin = listOf(
        "" to "System default",
        "sans-serif-light" to "Light",
        "sans-serif-medium" to "Medium",
        "sans-serif-condensed" to "Condensed",
        "serif" to "Serif",
        "monospace" to "Monospace",
        "casual" to "Casual",
        "cursive" to "Cursive"
    )

    private val cache = HashMap<String, Typeface>()

    fun dir(c: Context): File {
        val d = File(c.filesDir, "fonts")
        d.mkdirs()
        return d
    }

    fun uploaded(c: Context): List<String> = dir(c).list()?.sorted() ?: emptyList()

    fun typeface(c: Context, key: String): Typeface {
        cache[key]?.let { return it }
        var t: Typeface = Typeface.DEFAULT
        try {
            if (key.startsWith("file:")) {
                val f = File(dir(c), key.removePrefix("file:"))
                if (f.exists()) t = Typeface.createFromFile(f)
            } else if (key.isNotEmpty()) {
                t = Typeface.create(key, Typeface.NORMAL)
            }
        } catch (e: Exception) {
        }
        cache[key] = t
        return t
    }

    /** Copies a picked font file into the app. Returns its key ("file:name") or null if unusable. */
    fun import(c: Context, uri: Uri): String? {
        return try {
            var name = "font"
            c.contentResolver.query(uri, null, null, null, null)?.use {
                if (it.moveToFirst()) {
                    val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = it.getString(i) ?: name
                }
            }
            name = name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            if (!name.lowercase().endsWith(".ttf") && !name.lowercase().endsWith(".otf")) name += ".ttf"
            val out = File(dir(c), name)
            c.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
            try {
                Typeface.createFromFile(out)
            } catch (e: Exception) {
                out.delete()
                return null
            }
            cache.remove("file:$name")
            "file:$name"
        } catch (e: Exception) {
            null
        }
    }
}
