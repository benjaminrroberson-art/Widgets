package app.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.provider.AlarmClock
import android.text.TextPaint
import android.widget.RemoteViews
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

private val Number.f: Float get() = this.toFloat()

/** Everything a clock face might want to show besides the time. Each piece is looked up only when a style asks for it. */
internal class ClockData(val c: Context, val now: ZonedDateTime, val preview: Boolean) {
    val weather: WxData? by lazy {
        var out: WxData? = null
        try {
            for (id in Widgets.ids(c, Widgets.WX)) {
                val j = Wx.cached(c, id) ?: continue
                out = parseWx(j)
                if (out != null) break
            }
            if (out == null && preview) out = parseWx(Wx.sample())
        } catch (e: Exception) {
        }
        out
    }

    val metric: Boolean by lazy {
        var m = false
        try {
            for (id in Widgets.ids(c, Widgets.WX)) {
                m = Store.inst(c, id).wx.metric
                break
            }
        } catch (e: Exception) {
        }
        m
    }

    fun temp(cc: Double): String = ((if (metric) cc else cc * 9 / 5 + 32).roundToInt()).toString() + "°"

    val battery: Int by lazy {
        try {
            c.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
        } catch (e: Exception) {
            78
        }
    }

    val event: Ev? by lazy {
        try {
            if (Cal.granted(c)) {
                val t = now.toInstant().toEpochMilli()
                Cal.events(c, t, t + 86_400_000L, CalCfg()).firstOrNull { it.end > t && !it.allDay }
            } else if (preview) Cal.sample().firstOrNull { !it.allDay }
            else null
        } catch (e: Exception) {
            null
        }
    }

    /** Sunrise and sunset in minutes after local midnight. Falls back to 6:30 and 17:30 when there is no weather location. */
    val sun: Pair<Int, Int> by lazy {
        var lat = Double.NaN
        var lon = Double.NaN
        try {
            for (id in Widgets.ids(c, Widgets.WX)) {
                val w = Store.inst(c, id).wx
                if (w.hasLoc) {
                    lat = w.lat
                    lon = w.lon
                    break
                }
            }
        } catch (e: Exception) {
        }
        val r = if (lat.isNaN()) null else sunMinutes(lat, lon, true)
        val s = if (lat.isNaN()) null else sunMinutes(lat, lon, false)
        Pair(r ?: 390, s ?: 1050)
    }

    private fun sunMinutes(lat: Double, lon: Double, rising: Boolean): Int? {
        try {
            val rad = Math.PI / 180.0
            val n = now.dayOfYear
            val lngHour = lon / 15.0
            val t = n + ((if (rising) 6 else 18) - lngHour) / 24.0
            val m = 0.9856 * t - 3.289
            var l = m + 1.916 * sin(m * rad) + 0.020 * sin(2 * m * rad) + 282.634
            l = ((l % 360) + 360) % 360
            var ra = atan(0.91764 * tan(l * rad)) / rad
            ra = ((ra % 360) + 360) % 360
            ra += (floor(l / 90) * 90) - (floor(ra / 90) * 90)
            ra /= 15.0
            val sinDec = 0.39782 * sin(l * rad)
            val cosDec = cos(asin(sinDec))
            val cosH = (cos(90.833 * rad) - sinDec * sin(lat * rad)) / (cosDec * cos(lat * rad))
            if (cosH > 1 || cosH < -1) return null
            val h = (if (rising) 360 - acos(cosH) / rad else acos(cosH) / rad) / 15.0
            val tt = h + ra - 0.06571 * t - 6.622
            var ut = (tt - lngHour) % 24
            if (ut < 0) ut += 24
            val local = (ut + now.offset.totalSeconds / 3600.0 + 24) % 24
            return (local * 60).roundToInt()
        } catch (e: Exception) {
            return null
        }
    }

    /** 0 = new moon, 0.5 = full. */
    val moon: Double by lazy {
        val jd = now.toInstant().toEpochMilli() / 86_400_000.0 + 2440587.5
        val p = ((jd - 2451550.1) / 29.530588853) % 1.0
        if (p < 0) p + 1 else p
    }
}

/** A drawing surface in design units, with shapes that read like the SVG sketches the faces came from. */
internal class K(val cv: Canvas, val c: Context, val st: Style, val cfg: ClockCfg, val now: ZonedDateTime, val preview: Boolean) {
    val data = ClockData(c, now, preview)
    val pal = Palette.of(c, st)
    val tx = pal.text
    val ac = pal.accent
    val s1 = pal.bg or (0xFF shl 24)
    val s2 = mix(s1, tx, 0.10f)
    val trk = Widgets.alpha(tx, 46)
    val trk2 = Widgets.alpha(tx, 105)
    val sec = Widgets.alpha(tx, 150)
    val base: Typeface = FontStore.typeface(c, st.font)
    val bold: Typeface = Typeface.create(base, Typeface.BOLD)
    val serif: Typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
    val ts = st.textScale / 100f
    val hr = now.hour
    val mi = now.minute
    val h12 = hr % 12
    val hAng = (h12 + mi / 60f) * 30f
    val mAng = mi * 6f
    val h24 = cfg.h24
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    val hourStr: String get() = if (h24) "%02d".format(hr) else (if (h12 == 0) 12 else h12).toString()
    val minStr: String get() = "%02d".format(mi)
    val timeStr: String get() = "$hourStr:$minStr"
    val ampm: String get() = if (hr < 12) "AM" else "PM"
    val dowShort: String get() = now.format(DateTimeFormatter.ofPattern("EEE", Locale.getDefault()))
    val dowFull: String get() = now.format(DateTimeFormatter.ofPattern("EEEE", Locale.getDefault()))
    val monShort: String get() = now.format(DateTimeFormatter.ofPattern("MMM", Locale.getDefault()))
    val dateLong: String get() = now.format(DateTimeFormatter.ofPattern("EEEE, MMM d", Locale.getDefault()))
    val dateShort: String get() = now.format(DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault()))
    val day: Int get() = now.dayOfMonth

    fun fmtMin(minutes: Int): String {
        val t = LocalTime.of((minutes / 60) % 24, minutes % 60)
        return t.format(DateTimeFormatter.ofPattern(if (h24) "HH:mm" else "h:mm a", Locale.getDefault()))
    }

    fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).roundToInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch((a shr 16) and 255, (b shr 16) and 255) shl 16) or (ch((a shr 8) and 255, (b shr 8) and 255) shl 8) or ch(a and 255, b and 255)
    }

    fun alpha(color: Int, a: Int) = Widgets.alpha(color, a)

    /** Draw in a 120-unit sketch space (the first faces were drawn that way). */
    fun u120(block: () -> Unit) {
        cv.save()
        cv.scale(200f / 120f, 200f / 120f)
        block()
        cv.restore()
    }

    fun fillCircle(cx: Number, cy: Number, r: Number, color: Int) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = color
        cv.drawCircle(cx.f, cy.f, r.f, p)
    }

    fun ring(cx: Number, cy: Number, r: Number, color: Int, w: Number) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w.f
        cv.drawCircle(cx.f, cy.f, r.f, p)
    }

    /** A dashed circle drawn like an SVG stroke-dasharray, starting at 12 o'clock when top is true. */
    fun dashRing(cx: Number, cy: Number, r: Number, color: Int, w: Number, on: Number, off: Number, phase: Number = 0, cap: Paint.Cap = Paint.Cap.BUTT, top: Boolean = true) {
        cv.save()
        if (top) cv.rotate(-90f, cx.f, cy.f)
        path.reset()
        path.addCircle(cx.f, cy.f, r.f, Path.Direction.CW)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w.f; p.strokeCap = cap
        p.pathEffect = DashPathEffect(floatArrayOf(max(on.f, 0.01f), off.f), phase.f)
        cv.drawPath(path, p)
        cv.restore()
    }

    /** Arc measured clockwise from 12 o'clock. */
    fun arc(cx: Number, cy: Number, r: Number, from: Number, sweep: Number, color: Int, w: Number, cap: Paint.Cap = Paint.Cap.ROUND) {
        if (sweep.f <= 0.01f) return
        path.reset()
        path.arcTo(RectF(cx.f - r.f, cy.f - r.f, cx.f + r.f, cy.f + r.f), from.f - 90f, sweep.f, true)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w.f; p.strokeCap = cap
        cv.drawPath(path, p)
    }

    fun arcDash(cx: Number, cy: Number, r: Number, from: Number, sweep: Number, color: Int, w: Number, on: Number, off: Number) {
        if (sweep.f <= 0.01f) return
        path.reset()
        path.arcTo(RectF(cx.f - r.f, cy.f - r.f, cx.f + r.f, cy.f + r.f), from.f - 90f, sweep.f, true)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w.f
        p.pathEffect = DashPathEffect(floatArrayOf(on.f, off.f), 0f)
        cv.drawPath(path, p)
    }

    fun pie(cx: Number, cy: Number, r: Number, sweep: Number, color: Int) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = color
        cv.drawArc(RectF(cx.f - r.f, cy.f - r.f, cx.f + r.f, cy.f + r.f), -90f, sweep.f, true, p)
    }

    fun wedge(cx: Number, cy: Number, r: Number, startCanvasDeg: Number, sweep: Number, color: Int) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = color
        cv.drawArc(RectF(cx.f - r.f, cy.f - r.f, cx.f + r.f, cy.f + r.f), startCanvasDeg.f, sweep.f, true, p)
    }

    fun line(x1: Number, y1: Number, x2: Number, y2: Number, color: Int, w: Number, cap: Paint.Cap = Paint.Cap.ROUND, rot: Number = 0, px: Number = 100, py: Number = 100) {
        cv.save()
        if (rot.f != 0f) cv.rotate(rot.f, px.f, py.f)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w.f; p.strokeCap = cap
        cv.drawLine(x1.f, y1.f, x2.f, y2.f, p)
        cv.restore()
    }

    fun poly(pts: FloatArray, fill: Int?, stroke: Int? = null, sw: Number = 1, rot: Number = 0, px: Number = 100, py: Number = 100) {
        cv.save()
        if (rot.f != 0f) cv.rotate(rot.f, px.f, py.f)
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) {
            path.lineTo(pts[i], pts[i + 1])
            i += 2
        }
        path.close()
        if (fill != null) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = fill
            cv.drawPath(path, p)
        }
        if (stroke != null) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = stroke; p.strokeWidth = sw.f; p.strokeJoin = Paint.Join.ROUND
            cv.drawPath(path, p)
        }
        cv.restore()
    }

    fun rrect(l: Number, t: Number, r: Number, b: Number, rad: Number, fill: Int?, stroke: Int? = null, sw: Number = 1, rot: Number = 0, px: Number = 100, py: Number = 100) {
        cv.save()
        if (rot.f != 0f) cv.rotate(rot.f, px.f, py.f)
        val rc = RectF(l.f, t.f, r.f, b.f)
        if (fill != null) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = fill
            cv.drawRoundRect(rc, rad.f, rad.f, p)
        }
        if (stroke != null) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = stroke; p.strokeWidth = sw.f
            cv.drawRoundRect(rc, rad.f, rad.f, p)
        }
        cv.restore()
    }

    fun bez(pts: List<FloatArray>, fill: Int) {
        path.reset()
        path.moveTo(pts[0][0], pts[0][1])
        for (i in 1 until pts.size) {
            val q = pts[i]
            if (q.size == 6) path.cubicTo(q[0], q[1], q[2], q[3], q[4], q[5]) else path.lineTo(q[0], q[1])
        }
        path.close()
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = fill
        cv.drawPath(path, p)
    }

    fun polyline(xs: FloatArray, ys: FloatArray, color: Int, w: Number) {
        path.reset()
        path.moveTo(xs[0], ys[0])
        for (i in 1 until xs.size) path.lineTo(xs[i], ys[i])
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w.f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        cv.drawPath(path, p)
    }

    /** Returns the drawn width. y is the baseline unless central is true. */
    fun text(s: String, x: Number, y: Number, size: Number, color: Int, boldF: Boolean = false, align: Paint.Align = Paint.Align.CENTER, face: Typeface? = null, central: Boolean = false, spacing: Number = 0, outline: Number = 0): Float {
        tp.reset()
        tp.isAntiAlias = true
        tp.typeface = face ?: (if (boldF) bold else base)
        tp.textSize = size.f
        tp.textAlign = align
        tp.letterSpacing = spacing.f
        tp.color = color
        if (outline.f > 0f) {
            tp.style = Paint.Style.STROKE
            tp.strokeWidth = outline.f
        }
        val yy = if (central) y.f - (tp.descent() + tp.ascent()) / 2f else y.f
        cv.drawText(s, x.f, yy, tp)
        return tp.measureText(s)
    }

    fun measure(s: String, size: Number, boldF: Boolean = false, spacing: Number = 0, face: Typeface? = null): Float {
        tp.reset()
        tp.typeface = face ?: (if (boldF) bold else base)
        tp.textSize = size.f
        tp.letterSpacing = spacing.f
        return tp.measureText(s)
    }

    fun fit(s: String, size: Number, maxW: Number, boldF: Boolean = false): Float {
        val w = measure(s, size, boldF)
        return if (w <= maxW.f) size.f else size.f * maxW.f / w
    }

    fun ell(s: String, size: Number, maxW: Number, boldF: Boolean = false): String {
        tp.reset()
        tp.typeface = if (boldF) bold else base
        tp.textSize = size.f
        return android.text.TextUtils.ellipsize(s, tp, maxW.f, android.text.TextUtils.TruncateAt.END).toString()
    }

    /** Lit part of the moon. phase 0 = new, 0.5 = full. */
    fun moonDisc(cx: Number, cy: Number, r: Number, phase: Double, lit: Int, dark: Int) {
        fillCircle(cx, cy, r, dark)
        val fp = if (phase < 0.5) phase else 1 - phase
        val waning = phase >= 0.5
        val cc = cos(2 * Math.PI * fp).toFloat()
        cv.save()
        if (waning) cv.scale(-1f, 1f, cx.f, cy.f)
        path.reset()
        val rr = r.f
        path.moveTo(cx.f, cy.f - rr)
        path.arcTo(RectF(cx.f - rr, cy.f - rr, cx.f + rr, cy.f + rr), -90f, 180f, false)
        val w = abs(cc) * rr
        path.arcTo(RectF(cx.f - w, cy.f - rr, cx.f + w, cy.f + rr), 90f, if (cc >= 0) -180f else 180f, false)
        path.close()
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = lit
        cv.drawPath(path, p)
        cv.restore()
    }

    /** Hour and minute hands for a 200-unit round dial, with an optional outline halo in the face color. */
    fun hands(hourTail: Number, hourTip: Number, hourW: Number, hourColor: Int, minTail: Number, minTip: Number, minW: Number, minColor: Int, halo: Int? = null, cap: Paint.Cap = Paint.Cap.ROUND, cx: Number = 100, cy: Number = 100) {
        if (halo != null) {
            line(cx, cy.f + (hourTail.f - 100f), cx, hourTip, halo, hourW.f + 3f, cap, hAng, cx, cy)
        }
        line(cx, cy.f + (hourTail.f - 100f), cx, hourTip, hourColor, hourW, cap, hAng, cx, cy)
        if (halo != null) line(cx, cy.f + (minTail.f - 100f), cx, minTip, halo, minW.f + 3f, cap, mAng, cx, cy)
        line(cx, cy.f + (minTail.f - 100f), cx, minTip, minColor, minW, cap, mAng, cx, cy)
    }
}

internal class CStyle(val name: String, val w: Int, val h: Int, val draw: (K) -> Unit)

private val STAR12 = floatArrayOf(100f, 20f, 140f, 169.3f, 30.7f, 60f, 180f, 100f, 30.7f, 140f, 140f, 30.7f, 100f, 180f, 60f, 30.7f, 169.3f, 140f, 20f, 100f, 169.3f, 60f, 60f, 169.3f)
private val COMPASS8 = floatArrayOf(100f, 30f, 105.4f, 87.1f, 128.3f, 71.7f, 112.9f, 94.6f, 170f, 100f, 112.9f, 105.4f, 128.3f, 128.3f, 105.4f, 112.9f, 100f, 170f, 94.6f, 112.9f, 71.7f, 128.3f, 87.1f, 105.4f, 30f, 100f, 87.1f, 94.6f, 71.7f, 71.7f, 94.6f, 87.1f)
private val ROMAN = listOf("I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII")
private val STARS = arrayOf(
    floatArrayOf(24f, 150f), floatArrayOf(48f, 112f), floatArrayOf(40f, 70f), floatArrayOf(78f, 52f), floatArrayOf(100f, 92f), floatArrayOf(122f, 60f),
    floatArrayOf(150f, 38f), floatArrayOf(168f, 76f), floatArrayOf(150f, 118f), floatArrayOf(176f, 150f), floatArrayOf(128f, 160f), floatArrayOf(90f, 170f)
)

private fun sinD(deg: Float) = sin(Math.toRadians(deg.toDouble())).toFloat()
private fun cosD(deg: Float) = cos(Math.toRadians(deg.toDouble())).toFloat()

private val ONES = listOf("", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen")
private val TENS = listOf("", "", "twenty", "thirty", "forty", "fifty")

private fun hourWord(h12: Int): String = ONES[if (h12 == 0) 12 else h12]
private fun minuteWords(m: Int): String = when {
    m == 0 -> "o'clock"
    m < 10 -> "oh-" + ONES[m]
    m < 20 -> ONES[m]
    m % 10 == 0 -> TENS[m / 10]
    else -> TENS[m / 10] + "-" + ONES[m % 10]
}

object ClockStyles {
    private val SQ = 200
    internal val ALL: List<CStyle> = listOf(
        CStyle("Stack", SQ, SQ) { stack(it) },
        CStyle("Words", SQ, SQ) { words(it) },
        CStyle("Analog", SQ, SQ) { analog(it) },
        CStyle("Ring", SQ, SQ) { ringClock(it) },
        CStyle("Strip", 400, 118) { strip(it) },
        CStyle("Dual", 400, 118) { dual(it) },
        CStyle("Flip", SQ, SQ) { flip(it) },
        CStyle("Day arc", SQ, SQ) { dayArc(it) },
        CStyle("Rings", SQ, SQ) { rings(it) },
        CStyle("Numerals", SQ, SQ) { numerals(it) },
        CStyle("Outline", SQ, SQ) { outline(it) },
        CStyle("Poster", SQ, SQ) { poster(it) },
        CStyle("Day dots", 400, 130) { dayDots(it) },
        CStyle("Pills", 400, 100) { pills(it) },
        CStyle("Dots", SQ, SQ) { dots(it) },
        CStyle("Capsules", SQ, SQ) { capsules(it) },
        CStyle("Pie", SQ, SQ) { pie(it) },
        CStyle("Orbit", SQ, SQ) { orbit(it) },
        CStyle("Squircle", SQ, SQ) { squircle(it) },
        CStyle("Quadrants", SQ, SQ) { quadrants(it) },
        CStyle("One hand", SQ, SQ) { oneHand(it) },
        CStyle("Tape", 340, 84) { tape(it) },
        CStyle("Chronograph", SQ, SQ) { chrono(it) },
        CStyle("Day ring", SQ, SQ) { dayRing(it) },
        CStyle("Gears", SQ, SQ) { gears(it) },
        CStyle("Moonphase", SQ, SQ) { moonphase(it) },
        CStyle("Pilot", SQ, SQ) { pilot(it) },
        CStyle("Data rim", SQ, SQ) { dataRim(it) },
        CStyle("Sun and moon", SQ, SQ) { sunMoon(it) },
        CStyle("Dashboard", 340, 112) { dashboard(it) },
        CStyle("Eclipse", SQ, SQ) { eclipse(it) },
        CStyle("Bands", SQ, SQ) { bands(it) },
        CStyle("Sunburst", SQ, SQ) { sunburst(it) },
        CStyle("Waves", SQ, SQ) { waves(it) },
        CStyle("Dunes", SQ, SQ) { dunes(it) },
        CStyle("Cropped", SQ, SQ) { cropped(it) },
        CStyle("Moire", SQ, SQ) { moire(it) },
        CStyle("Contours", SQ, SQ) { contours(it) },
        CStyle("String art", SQ, SQ) { stringArt(it) },
        CStyle("Halftone", SQ, SQ) { halftone(it) },
        CStyle("Constellation", SQ, SQ) { constellation(it) },
        CStyle("Tree rings", SQ, SQ) { treeRings(it) },
        CStyle("Barcode", SQ, SQ) { barcode(it) },
        CStyle("Vertical", SQ, SQ) { vertical(it) },
        CStyle("Diver", SQ, SQ) { diver(it) },
        CStyle("Railroad", SQ, SQ) { railroad(it) },
        CStyle("Tourbillon", SQ, SQ) { tourbillon(it) },
        CStyle("Guilloche", SQ, SQ) { guilloche(it) },
        CStyle("Deco", SQ, SQ) { deco(it) },
        CStyle("Compass", SQ, SQ) { compass(it) },
        CStyle("Station", SQ, SQ) { station(it) },
        CStyle("Regulator", SQ, SQ) { regulator(it) }
    )

    val names: List<String> get() = ALL.map { it.name }

    fun at(i: Int): CStyle = ALL[i.coerceIn(0, ALL.size - 1)]

    /** Default size in dp, used for the aspect ratio and before the launcher reports a size. */
    fun dp(i: Int): Pair<Int, Int> {
        val s = at(i)
        return if (s.w == s.h) 180 to 180 else 320 to (320f * s.h / s.w).roundToInt()
    }

    // ---------- digital ----------

    private fun stack(k: K) {
        k.text(k.hourStr, 24, 90, 88, k.tx, align = Paint.Align.LEFT, spacing = -0.04f)
        k.text(k.minStr, 24, 166, 88, k.ac, align = Paint.Align.LEFT, spacing = -0.04f)
        if (k.cfg.date) k.text(k.dateLong, 26, 188, 13 * k.ts, k.sec, align = Paint.Align.LEFT)
    }

    private fun words(k: K) {
        k.text("It's", 22, 50, 14 * k.ts, k.sec, align = Paint.Align.LEFT)
        val a = hourWord(k.h12)
        val b = minuteWords(k.mi)
        val size = min(44f, min(k.fit(a, 44, 170, true), k.fit(b, 44, 170, true)))
        k.text(a, 22, 100, size, k.tx, true, Paint.Align.LEFT, spacing = -0.02f)
        k.text(b, 22, 100 + size * 1.05f, size, k.ac, true, Paint.Align.LEFT, spacing = -0.02f)
        if (k.cfg.date) k.text(k.dateShort, 22, 186, 13 * k.ts, k.sec, align = Paint.Align.LEFT)
    }

    private fun analog(k: K) = k.u120 {
        k.ring(60, 60, 54, k.trk, 0.5f)
        k.line(60, 10, 60, 18, k.ac, 2)
        k.line(110, 60, 102, 60, k.sec, 2)
        k.line(60, 110, 60, 102, k.sec, 2)
        k.line(10, 60, 18, 60, k.sec, 2)
        k.line(60, 60, 60, 32, k.tx, 4.5f, rot = k.hAng, px = 60, py = 60)
        k.line(60, 60, 60, 18, k.tx, 3, rot = k.mAng, px = 60, py = 60)
        k.fillCircle(60, 60, 3.5f, k.ac)
    }

    private fun ringClock(k: K) = k.u120 {
        k.ring(60, 60, 50, k.trk, 6)
        k.arc(60, 60, 50, 0, k.mAng, k.ac, 6)
        k.text(k.timeStr, 60, 64, 30, k.tx)
        if (k.cfg.date) k.text(k.dowShort + " " + k.day, 60, 82, 12, k.sec)
    }

    private fun strip(k: K) {
        val w = k.text(k.timeStr, 24, 80, 68, k.tx, spacing = -0.03f, align = Paint.Align.LEFT)
        if (!k.h24) k.text(k.ampm, 24 + w + 8, 80, 17, k.ac, true, Paint.Align.LEFT)
        if (k.cfg.date) {
            k.text(k.dowShort.uppercase(), 376, 36, 13 * k.ts, k.sec, align = Paint.Align.RIGHT)
            k.text(k.day.toString(), 376, 72, 37, k.tx, align = Paint.Align.RIGHT)
            k.text(k.monShort.uppercase(), 376, 94, 13 * k.ts, k.sec, align = Paint.Align.RIGHT)
        }
    }

    private fun zoneCity(id: String): String = id.substringAfterLast('/').replace('_', ' ')

    private fun dual(k: K) {
        val z2 = try { ZoneId.of(k.cfg.tz2) } catch (e: Exception) { ZoneId.of("UTC") }
        val t2 = k.now.withZoneSameInstant(z2)
        val pat = DateTimeFormatter.ofPattern(if (k.h24) "HH:mm" else "h:mm", Locale.getDefault())
        k.text(zoneCity(k.now.zone.id), 30, 40, 13 * k.ts, k.sec, align = Paint.Align.LEFT)
        k.text(k.timeStr, 30, 88, 48, k.tx, align = Paint.Align.LEFT, spacing = -0.03f)
        k.line(200, 26, 200, 94, k.trk2, 1, Paint.Cap.BUTT)
        k.text(zoneCity(z2.id), 226, 40, 13 * k.ts, k.sec, align = Paint.Align.LEFT)
        k.text(t2.format(pat), 226, 88, 48, k.ac, align = Paint.Align.LEFT, spacing = -0.03f)
    }

    private fun flip(k: K) {
        val x0 = 18f
        for (i in 0..1) {
            val l = x0 + i * 84f
            k.rrect(l, 32, l + 76, 136, 13, k.s2)
            k.text(if (i == 0) k.hourStr else k.minStr, l + 38, 84, 62, if (i == 0) k.tx else k.ac, true, central = true)
            k.line(l, 84, l + 76, 84, k.s1, 2.5f, Paint.Cap.BUTT)
        }
        val lab = (if (k.h24) "" else k.ampm + " · ") + (if (k.cfg.date) k.dateShort else "")
        if (lab.isNotEmpty()) k.text(lab, 100, 168, 13 * k.ts, k.sec)
    }

    private fun dayArc(k: K) {
        k.cv.save()
        k.cv.translate(10f, 45f)
        val (rise, set) = k.data.sun
        val nowMin = k.hr * 60 + k.mi
        val f = ((nowMin - rise).toFloat() / (set - rise).toFloat()).coerceIn(0f, 1f)
        k.arc(90, 90, 70, 270, 180, k.trk, 3)
        k.arc(90, 90, 70, 270, 180 * f, k.ac, 3)
        val ang = Math.PI * f
        val sx = 90f - 70f * cos(ang).toFloat()
        val sy = 90f - 70f * sin(ang).toFloat()
        k.fillCircle(sx, sy, 7, k.ac)
        k.line(10, 90, 170, 90, k.trk, 0.8f, Paint.Cap.BUTT)
        k.text(k.timeStr, 90, 82, 30, k.tx)
        val after = nowMin >= set || nowMin < rise
        k.text((if (after) "Sunrise " + k.fmtMin(rise) else "Sunset " + k.fmtMin(set)), 90, 106, 12 * k.ts, k.sec)
        k.cv.restore()
    }

    private fun rings(k: K) = k.u120 {
        val dim = k.now.toLocalDate().lengthOfMonth()
        k.ring(60, 60, 52, k.trk, 7); k.arc(60, 60, 52, 0, (k.h12 + k.mi / 60f) / 12f * 360f, k.ac, 7)
        k.ring(60, 60, 40, k.trk, 7); k.arc(60, 60, 40, 0, k.mi / 60f * 360f, k.tx, 7)
        k.ring(60, 60, 28, k.trk, 7); k.arc(60, 60, 28, 0, k.day.toFloat() / dim * 360f, k.sec, 7)
        k.text(k.timeStr, 60, 65, 15, k.tx, true)
    }

    private fun numerals(k: K) = k.u120 {
        k.fillCircle(60, 60, 56, k.s2)
        k.text("12", 60, 28, 17, k.tx, true)
        k.text("3", 96, 66, 17, k.sec, true)
        k.text("6", 60, 108, 17, k.sec, true)
        k.text("9", 24, 66, 17, k.sec, true)
        k.line(60, 60, 60, 38, k.tx, 6, rot = k.hAng, px = 60, py = 60)
        k.line(60, 60, 60, 30, k.tx, 4, rot = k.mAng, px = 60, py = 60)
        k.fillCircle(60, 60, 5, k.ac)
    }

    private fun outline(k: K) {
        k.text(k.hourStr, 100, 94, 86, k.s1, true, spacing = -0.03f)
        k.text(k.hourStr, 100, 94, 86, k.tx, true, spacing = -0.03f, outline = 1.8f)
        k.text(k.minStr, 100, 170, 86, k.ac, true, spacing = -0.03f)
        if (k.cfg.date) k.text(k.dowFull, 100, 192, 13 * k.ts, k.sec)
    }

    private fun poster(k: K) {
        k.text(k.day.toString(), 214, 150, 190, k.trk, true, Paint.Align.RIGHT, spacing = -0.05f)
        if (k.cfg.date) k.text(k.dowFull + " · " + k.monShort, 22, 138, 13 * k.ts, k.sec, align = Paint.Align.LEFT)
        k.text(k.timeStr, 22, 182, 50, k.tx, align = Paint.Align.LEFT, spacing = -0.02f)
    }

    private fun dayDots(k: K) {
        k.text(k.timeStr, 24, 62, 50, k.tx, align = Paint.Align.LEFT, spacing = -0.02f)
        if (k.cfg.date) k.text(k.dateShort, 376, 58, 14 * k.ts, k.sec, align = Paint.Align.RIGHT)
        val step = (376f - 24f) / 24f
        for (i in 0 until 24) {
            val col = if (i < k.hr) k.tx else if (i == k.hr) k.ac else k.trk
            k.fillCircle(24 + i * step + step / 2f, 100, 6.4f, col)
        }
    }

    private fun pills(k: K) {
        val tw = k.measure(k.timeStr, 38, true, -0.02f)
        val w1 = tw + 46f
        k.rrect(18, 19, 18 + w1, 81, 31, k.ac)
        k.text(k.timeStr, 18 + w1 / 2f, 50, 38, k.s1, true, central = true, spacing = -0.02f)
        val x2 = 18f + w1 + 8f
        k.rrect(x2, 19, x2 + 66, 81, 31, k.s2)
        k.text(k.dowShort.uppercase(), x2 + 33, 38, 11 * k.ts, k.sec)
        k.text(k.day.toString(), x2 + 33, 66, 22, k.tx, true)
        val x3 = x2 + 74f
        k.rrect(x3, 19, x3 + 62, 81, 31, k.s2)
        k.text(if (k.h24) k.monShort.uppercase() else k.ampm, x3 + 31, 50, 16, k.tx, true, central = true)
    }

    // ---------- simple analog ----------

    private fun dots(k: K) = k.u120 {
        k.dashRing(60, 60, 54, k.trk, 2.2f, 0.01f, 5.655f, 0, Paint.Cap.ROUND)
        k.dashRing(60, 60, 54, k.tx, 5, 0.01f, 28.274f, 0, Paint.Cap.ROUND)
        k.line(60, 64, 60, 34, k.tx, 2.5f, rot = k.hAng, px = 60, py = 60)
        k.line(60, 66, 60, 16, k.ac, 2, rot = k.mAng, px = 60, py = 60)
        k.fillCircle(60, 60, 3, k.ac)
    }

    private fun capsules(k: K) = k.u120 {
        k.ring(60, 60, 55, k.trk, 0.5f)
        k.rrect(53, 26, 67, 72, 7, k.tx, rot = k.hAng, px = 60, py = 60)
        k.rrect(55.5f, 6, 64.5f, 72, 4.5f, k.ac, rot = k.mAng, px = 60, py = 60)
        k.fillCircle(60, 60, 3.5f, k.s1)
    }

    private fun pie(k: K) = k.u120 {
        k.ring(60, 60, 52, k.trk, 0.5f)
        k.pie(60, 60, 52, k.mAng, k.alpha(k.ac, 70))
        k.line(60, 60, 60, 8, k.ac, 2.5f, rot = k.mAng, px = 60, py = 60)
        k.line(60, 60, 60, 30, k.tx, 6, rot = k.hAng, px = 60, py = 60)
        k.fillCircle(60, 60, 4, k.tx)
    }

    private fun orbit(k: K) = k.u120 {
        k.ring(60, 60, 22, k.trk, 0.6f)
        k.ring(60, 60, 44, k.trk, 0.6f)
        k.fillCircle(60, 60, 5, k.sec)
        k.cv.save(); k.cv.rotate(k.hAng, 60f, 60f); k.fillCircle(60, 38, 8, k.tx); k.cv.restore()
        k.cv.save(); k.cv.rotate(k.mAng, 60f, 60f); k.fillCircle(60, 16, 6, k.ac); k.cv.restore()
    }

    private fun squircle(k: K) = k.u120 {
        k.rrect(6, 6, 114, 114, 32, k.s2)
        for (i in 0 until 12) {
            val q = i % 3 == 0
            k.line(60, 14, 60, if (q) 20 else 19, if (q) k.tx else k.sec, if (q) 3 else 2, rot = i * 30f, px = 60, py = 60)
        }
        k.line(60, 60, 60, 34, k.tx, 5, rot = k.hAng, px = 60, py = 60)
        k.line(60, 60, 60, 22, k.ac, 3, rot = k.mAng, px = 60, py = 60)
        k.fillCircle(60, 60, 3.5f, k.ac)
    }

    private fun quadrants(k: K) = k.u120 {
        k.fillCircle(60, 60, 54, k.s2)
        k.wedge(60, 60, 54, -90, 90, k.ac)
        k.wedge(60, 60, 54, 90, 90, k.tx)
        k.line(60, 60, 60, 32, k.s1, 9, rot = k.hAng, px = 60, py = 60)
        k.line(60, 60, 60, 14, k.s1, 6, rot = k.mAng, px = 60, py = 60)
        k.line(60, 60, 60, 32, k.sec, 5, rot = k.hAng, px = 60, py = 60)
        k.line(60, 60, 60, 14, k.sec, 2.5f, rot = k.mAng, px = 60, py = 60)
        k.fillCircle(60, 60, 4, k.s1)
    }

    private fun oneHand(k: K) = k.u120 {
        k.dashRing(60, 60, 54, k.trk, 2.2f, 0.01f, 5.655f, 0, Paint.Cap.ROUND)
        k.line(60, 30, 60, 6, k.ac, 3, rot = k.mAng, px = 60, py = 60)
        k.cv.save(); k.cv.rotate(k.mAng, 60f, 60f); k.fillCircle(60, 6, 4, k.ac); k.cv.restore()
        k.text(if (k.h24) k.hr.toString() else (if (k.h12 == 0) 12 else k.h12).toString(), 60, 76, 52, k.tx)
    }

    private fun tape(k: K) {
        val tH = k.hr + k.mi / 60f
        val base = floor(tH).toInt()
        for (h in base - 3..base + 3) {
            for (q in 0..3) {
                val x = 170f + (h - tH) * 80f + q * 20f
                if (x < 4f || x > 336f) continue
                if (q == 0) k.line(x, 34, x, 58, k.tx, 2.5f) else k.line(x, 40, x, 52, k.sec, 1.5f)
            }
            val x = 170f + (h - tH) * 80f
            if (x in 12f..328f) {
                val hh = ((h % 24) + 24) % 24
                val lab = if (k.h24) hh.toString() else (if (hh % 12 == 0) 12 else hh % 12).toString()
                k.text(lab, x, 76, 12 * k.ts, k.sec)
            }
        }
        k.line(170, 22, 170, 62, k.ac, 2.5f)
        k.poly(floatArrayOf(163f, 6f, 177f, 6f, 170f, 18f), k.ac)
    }

    // ---------- detailed analog ----------

    private fun chrono(k: K) {
        k.fillCircle(100, 100, 94, k.s2)
        k.dashRing(100, 100, 86, k.sec, 6, 1.2f, 7.807f, 0.6f)
        k.dashRing(100, 100, 86, k.tx, 10, 3, 42.03f, 1.5f)
        for ((x, y) in listOf(60 to 100, 140 to 100, 100 to 140)) k.ring(x, y, 21, k.trk2, 1)
        k.text(k.dowShort.uppercase(), 60, 104, 11 * k.ts, k.sec, true)
        k.text(k.day.toString(), 140, 106, 16, k.tx, true)
        k.line(100, 140, 100, 124, k.ac, 2, rot = (k.hr + k.mi / 60f) / 24f * 360f, px = 100, py = 140)
        k.text("24H", 100, 160, 8, k.sec)
        k.hands(106, 54, 6, k.tx, 112, 22, 3, k.ac)
        k.fillCircle(100, 100, 5, k.ac)
    }

    private fun dayRing(k: K) {
        k.arc(100, 100, 88, 270, 180, k.ac, 10, Paint.Cap.BUTT)
        k.arc(100, 100, 88, 90, 180, k.trk, 10, Paint.Cap.BUTT)
        k.cv.save(); k.cv.rotate(((k.hr + k.mi / 60f) - 12f) / 24f * 360f, 100f, 100f); k.fillCircle(100, 12, 9, k.tx); k.cv.restore()
        k.text("NOON", 100, 40, 10, k.sec)
        k.text("MIDNIGHT", 100, 168, 10, k.sec)
        k.fillCircle(100, 100, 72, k.s2)
        k.dashRing(100, 100, 62, k.sec, 8, 2, 30.47f, 1)
        k.hands(104, 68, 6, k.tx, 108, 48, 3, k.ac)
        k.fillCircle(100, 100, 4.5f, k.ac)
    }

    private fun gears(k: K) {
        k.ring(100, 100, 94, k.trk, 0.8f)
        k.dashRing(100, 100, 88, k.sec, 6, 1.2f, 7.807f, 0.6f)
        fun gear(cx: Float, cy: Float, r: Float, w: Float, on: Float, off: Float, innerR: Float, rot: Float) {
            k.cv.save(); k.cv.rotate(rot, cx, cy)
            k.dashRing(cx, cy, r, k.trk2, w, on, off, 0, top = false)
            k.cv.restore()
            k.ring(cx, cy, innerR, k.trk2, 1)
        }
        gear(72f, 112f, 38f, 9f, 7.5f, 7.8f, 32f, k.mi * 6f)
        k.fillCircle(72, 112, 6, k.s1); k.ring(72, 112, 6, k.trk2, 1)
        gear(138f, 66f, 22f, 8f, 6.5f, 7f, 17f, -k.mi * 6f * 38f / 22f)
        gear(140f, 140f, 19f, 8f, 7f, 6.9f, 14f, k.mi * 6f * 38f / 19f)
        k.fillCircle(138, 66, 5, k.ac)
        k.hands(106, 56, 10, k.s1, 110, 24, 6, k.s1, null)
        k.hands(106, 56, 5.5f, k.tx, 110, 24, 2.5f, k.ac)
        k.fillCircle(100, 100, 5, k.tx)
    }

    private fun moonphase(k: K) {
        k.fillCircle(100, 100, 94, k.s2)
        k.dashRing(100, 100, 86, k.sec, 8, 2, 43.03f, 1)
        k.rrect(136, 88, 174, 112, 5, k.s1, k.trk, 1)
        k.text(k.day.toString(), 155, 105, 15, k.tx, true)
        k.text(k.dowShort.uppercase(), 52, 104, 11 * k.ts, k.sec, true)
        k.fillCircle(100, 146, 26, k.s1); k.ring(100, 146, 26, k.trk, 1)
        k.moonDisc(100, 146, 17, k.data.moon, k.tx, k.alpha(k.tx, 38))
        for ((x, y) in listOf(84 to 130, 118 to 128, 116 to 162)) k.fillCircle(x, y, 1.5f, k.sec)
        k.hands(104, 54, 6, k.tx, 108, 24, 3, k.ac)
        k.fillCircle(100, 100, 5, k.ac)
    }

    private fun pilot(k: K) {
        k.fillCircle(100, 100, 94, k.s2)
        k.dashRing(100, 100, 90, k.sec, 4, 1, 8.425f, 0.5f)
        k.poly(floatArrayOf(100f, 3f, 93f, 15f, 107f, 15f), k.ac)
        val pos = arrayOf(floatArrayOf(137f, 36f), floatArrayOf(164f, 63f), floatArrayOf(174f, 100f), floatArrayOf(164f, 137f), floatArrayOf(137f, 164f), floatArrayOf(100f, 174f), floatArrayOf(63f, 164f), floatArrayOf(36f, 137f), floatArrayOf(26f, 100f), floatArrayOf(36f, 63f), floatArrayOf(63f, 36f), floatArrayOf(100f, 28f))
        for (i in 0 until 12) k.text((i + 1).toString(), pos[i][0], pos[i][1], 20, k.tx, true, central = true)
        k.hands(110, 62, 8, k.tx, 116, 34, 4, k.tx, null, Paint.Cap.BUTT)
        k.fillCircle(100, 100, 6, k.ac)
    }

    private fun dataRim(k: K) {
        k.fillCircle(100, 100, 96, k.s2)
        k.arc(100, 100, 84, 220, 100, k.trk, 8)
        k.arc(100, 100, 84, 40, 100, k.trk, 8)
        val w = k.data.weather
        val tf = if (w == null) 0.5f else ((w.now.temp + 10.0) / 50.0).toFloat().coerceIn(0.04f, 1f)
        k.arc(100, 100, 84, 220, 100 * tf, k.ac, 8)
        val bf = (k.data.battery / 100f).coerceIn(0.04f, 1f)
        k.arc(100, 100, 84, 40, 100 * bf, k.tx, 8)
        k.text(if (w == null) "--°" else k.data.temp(w.now.temp), 42, 104, 12, k.tx, true)
        k.text(k.data.battery.toString() + "%", 158, 104, 12, k.tx, true)
        k.dashRing(100, 100, 62, k.sec, 7, 1.5f, 30.97f, 0.75f)
        k.text(k.dowShort.uppercase() + " " + k.day, 100, 146, 12 * k.ts, k.sec, true)
        k.hands(104, 62, 6, k.tx, 108, 46, 3, k.ac)
        k.fillCircle(100, 100, 4.5f, k.ac)
    }

    private fun sunMoon(k: K) {
        k.fillCircle(100, 100, 94, k.s2)
        k.wedge(100, 100, 94, 0, 180, k.s1)
        k.dashRing(100, 100, 86, k.sec, 8, 2, 19.99f, 1)
        k.fillCircle(100, 60, 9, k.ac)
        k.fillCircle(100, 142, 9, k.tx); k.fillCircle(106, 140, 8, k.s1)
        k.text("12", 100, 40, 10, k.sec, true)
        k.text("18", 160, 104, 10, k.sec, true)
        k.text("6", 40, 104, 10, k.sec, true)
        val a = ((k.hr + k.mi / 60f) - 12f) / 24f * 360f
        k.line(100, 100, 100, 26, k.ac, 3, rot = a)
        k.cv.save(); k.cv.rotate(a, 100f, 100f); k.fillCircle(100, 24, 5, k.ac); k.cv.restore()
        k.line(100, 100, 100, 48, k.tx, 3, rot = k.mAng)
        k.fillCircle(100, 100, 5, k.tx)
    }

    private fun dashboard(k: K) {
        k.fillCircle(56, 56, 50, k.s2)
        k.dashRing(56, 56, 42, k.sec, 6, 2, 19.99f, 1)
        k.line(56, 59, 56, 38, k.tx, 4, rot = k.hAng, px = 56, py = 56)
        k.line(56, 62, 56, 22, k.ac, 2.5f, rot = k.mAng, px = 56, py = 56)
        k.fillCircle(56, 56, 3, k.ac)
        if (k.cfg.date) k.text(k.dateLong, 124, 30, 18 * k.ts, k.tx, true, Paint.Align.LEFT)
        val w = k.data.weather
        val line = if (w == null) "Weather not set up" else k.data.temp(w.now.temp) + " · " + WxText.desc(w.now.code) + (w.days.firstOrNull()?.let { " · High " + k.data.temp(it.hi) } ?: "")
        k.text(k.ell(line, 12 * k.ts, 210), 124, 54, 12 * k.ts, k.sec, align = Paint.Align.LEFT)
        k.line(124, 66, 324, 66, k.trk, 0.8f, Paint.Cap.BUTT)
        val e = k.data.event
        if (e == null) {
            k.text("No upcoming events", 124, 90, 12 * k.ts, k.sec, align = Paint.Align.LEFT)
        } else {
            k.fillCircle(130, 83, 4, k.ac)
            k.text(k.ell(e.title, 12 * k.ts, 180), 142, 88, 12 * k.ts, k.tx, align = Paint.Align.LEFT)
            val mins = ((e.begin - k.now.toInstant().toEpochMilli()) / 60000L).toInt()
            val inTxt = when {
                mins <= 0 -> "now"
                mins < 60 -> "in $mins m"
                else -> "in " + (mins / 60) + " h " + (mins % 60) + " m"
            }
            k.text(k.fmtMin(java.time.Instant.ofEpochMilli(e.begin).atZone(k.now.zone).let { it.hour * 60 + it.minute }) + " · " + inTxt, 142, 104, 12 * k.ts, k.sec, align = Paint.Align.LEFT)
        }
    }

    // ---------- artful ----------

    private fun eclipse(k: K) {
        k.dashRing(100, 100, 92, k.trk, 5, 0.01f, 48.17f, 0, Paint.Cap.ROUND)
        k.cv.save(); k.cv.rotate(k.hAng, 100f, 100f); k.fillCircle(100, 8, 7, k.tx); k.cv.restore()
        k.fillCircle(100, 100, 58, k.ac)
        val mx = 100f + (k.mi - 30f) / 30f * 90f
        k.fillCircle(mx, 100, 58, k.s1)
        k.ring(mx, 100, 58, k.alpha(k.ac, 160), 0.8f)
    }

    private fun bands(k: K) {
        val third = if (k.h24) k.day.toString() else k.ampm
        val rows = listOf(
            Triple(40f, (k.h12 + k.mi / 60f) / 12f, k.hourStr),
            Triple(84f, k.mi / 60f, k.minStr),
            Triple(128f, (k.hr + k.mi / 60f) / 24f, third)
        )
        val cols = listOf(k.tx, k.ac, k.sec)
        for ((i, r) in rows.withIndex()) {
            k.rrect(20, r.first, 180, r.first + 32, 16, k.trk)
            val w = max(40f, 160f * r.second)
            k.rrect(20, r.first, 20 + w, r.first + 32, 16, cols[i])
            k.text(r.third, 20 + w - 14, r.first + 16, 16, k.s1, true, Paint.Align.RIGHT, central = true)
        }
    }

    private fun sunburst(k: K) {
        k.dashRing(100, 100, 70, k.trk, 40, 2, 5.33f)
        k.arcDash(100, 100, 70, 0, k.mAng, k.ac, 40, 2, 5.33f)
        k.fillCircle(100, 100, 46, k.s1)
        k.text(k.hourStr, 100, 118, 52, k.tx)
    }

    private fun waves(k: K) {
        val phase = k.mi / 60f * 2f * Math.PI.toFloat()
        val ys = floatArrayOf(40f, 58f, 76f, 94f, 112f)
        val cols = intArrayOf(k.tx, k.ac, k.alpha(k.ac, 180), k.alpha(k.ac, 115), k.alpha(k.ac, 64))
        for (i in 0 until 5) {
            val n = 61
            val xs = FloatArray(n)
            val yy = FloatArray(n)
            for (j in 0 until n) {
                val x = 10f + j * 3f
                xs[j] = x
                yy[j] = ys[i] + 22f * sin(((x - 10f) / 180f * 2f * Math.PI + phase + i * 0.35).toFloat())
            }
            k.polyline(xs, yy, cols[i], 3)
        }
        k.text(k.timeStr, 20, 178, 40, k.tx, align = Paint.Align.LEFT, spacing = -0.02f)
    }

    private fun dunes(k: K) {
        val (rise, set) = k.data.sun
        val nowMin = k.hr * 60 + k.mi
        val f = ((nowMin - rise).toFloat() / (set - rise).toFloat()).coerceIn(0f, 1f)
        val sx = 20f + 160f * f
        val sy = 100f - 70f * sin(Math.PI * f).toFloat()
        k.fillCircle(sx, sy, 14, k.tx)
        k.bez(listOf(floatArrayOf(0f, 130f), floatArrayOf(40f, 100f, 90f, 110f, 130f, 125f), floatArrayOf(170f, 140f, 190f, 120f, 200f, 115f), floatArrayOf(200f, 200f), floatArrayOf(0f, 200f)), k.alpha(k.ac, 80))
        k.bez(listOf(floatArrayOf(0f, 150f), floatArrayOf(50f, 125f, 100f, 150f, 150f, 138f), floatArrayOf(200f, 126f, 190f, 140f, 200f, 135f), floatArrayOf(200f, 200f), floatArrayOf(0f, 200f)), k.alpha(k.ac, 155))
        k.bez(listOf(floatArrayOf(0f, 172f), floatArrayOf(60f, 156f, 120f, 184f, 200f, 162f), floatArrayOf(200f, 200f), floatArrayOf(0f, 200f)), k.ac)
        k.text(k.timeStr, 16, 192, 20, k.s1, true, Paint.Align.LEFT)
    }

    private fun cropped(k: K) {
        k.text(k.hourStr, -14, 128, 224, k.tx, true, Paint.Align.LEFT, spacing = -0.06f)
        k.text(k.minStr, 226, 222, 224, k.ac, true, Paint.Align.RIGHT, spacing = -0.06f)
        if (k.cfg.date) k.text(k.dowShort + " " + k.day + " " + k.monShort, 20, 186, 12 * k.ts, k.sec, align = Paint.Align.LEFT)
    }

    private fun moire(k: K) {
        k.cv.save()
        val clip = Path()
        clip.addCircle(100f, 100f, 90f, Path.Direction.CW)
        k.cv.clipPath(clip)
        var x = 0f
        while (x <= 198f) {
            k.line(x, -40, x, 240, k.tx, 1.2f, Paint.Cap.BUTT)
            x += 6f
        }
        k.cv.rotate(k.mi * 0.5f + k.h12 * 3f, 100f, 100f)
        x = -40f
        while (x <= 240f) {
            k.line(x, -40, x, 240, k.ac, 1.2f, Paint.Cap.BUTT)
            x += 6f
        }
        k.cv.restore()
    }

    private fun contours(k: K) {
        val dx = 4f * sinD(k.hAng)
        val dy = -4f * cosD(k.hAng)
        val hi = (k.mi / 60f * 7f).toInt().coerceIn(0, 7)
        var cx = 100f
        var cy = 100f
        val rx = floatArrayOf(84f, 74f, 64f, 54f, 44f, 34f, 24f, 14f)
        val ry = floatArrayOf(70f, 61.5f, 53f, 44.5f, 36f, 27.5f, 19f, 10.5f)
        val pnt = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 8) {
            pnt.style = Paint.Style.STROKE
            pnt.strokeWidth = if (i == hi) 3f else 1.5f
            pnt.color = if (i == hi) k.ac else k.trk2
            k.cv.drawOval(RectF(cx - rx[i], cy - ry[i], cx + rx[i], cy + ry[i]), pnt)
            if (i < 7) {
                cx += dx
                cy += dy
            }
        }
        k.fillCircle(cx, cy, 4, k.tx)
    }

    private fun stringArt(k: K) {
        k.ring(100, 100, 80, k.trk, 0.8f)
        k.poly(STAR12, null, k.tx, 1.3f, k.mAng)
        k.cv.save(); k.cv.rotate(k.hAng, 100f, 100f); k.fillCircle(100, 20, 6, k.ac); k.cv.restore()
    }

    private fun halftone(k: K) {
        val hx = 100f + 54f * sinD(k.hAng)
        val hy = 100f - 54f * cosD(k.hAng)
        val mx = 100f + 54f * sinD(k.mAng)
        val my = 100f - 54f * cosD(k.mAng)
        for (i in 0 until 13) for (j in 0 until 13) {
            val x = 16f + i * 14.5f
            val y = 16f + j * 14.5f
            val dh = Math.hypot((x - hx).toDouble(), (y - hy).toDouble()).toFloat()
            val dm = Math.hypot((x - mx).toDouble(), (y - my).toDouble()).toFloat()
            val r = max(1.2f, 7f - min(dh, dm) / 11f)
            k.fillCircle(x, y, r, if (dm < dh) k.ac else k.tx)
        }
    }

    private fun constellation(k: K) {
        val n = k.h12
        val xs = FloatArray(n + 1) { STARS[it][0] }
        val ys = FloatArray(n + 1) { STARS[it][1] }
        if (n >= 1) k.polyline(xs, ys, k.ac, 1.6f)
        val nxt = STARS[(n + 1) % 12]
        val f = k.mi / 60f
        val cur = STARS[n]
        k.line(cur[0], cur[1], cur[0] + (nxt[0] - cur[0]) * f, cur[1] + (nxt[1] - cur[1]) * f, k.ac, 1.6f, Paint.Cap.ROUND)
        for (i in 0 until 12) {
            when {
                i < n -> k.fillCircle(STARS[i][0], STARS[i][1], 3.5f, k.tx)
                i == n -> k.fillCircle(STARS[i][0], STARS[i][1], 6, k.ac)
                else -> k.fillCircle(STARS[i][0], STARS[i][1], 3.5f, k.trk2)
            }
        }
    }

    private fun treeRings(k: K) {
        for (i in 0 until k.h12) k.ring(100, 100, 12f + i * 6.2f, k.tx, 2)
        val r = 12f + k.h12 * 6.2f
        k.ring(100, 100, r, k.trk, 2)
        k.arc(100, 100, r, 0, k.mAng, k.ac, 5)
        k.ring(100, 100, 89, k.trk, 1)
    }

    private fun barcode(k: K) {
        for (i in 0 until 24) {
            val h = 36f + (abs(sin(i * 0.55)) * 84).roundToInt()
            val col = if (i < k.hr) k.tx else if (i == k.hr) k.ac else k.trk
            k.rrect(10f + i * 7.5f, 96f - h / 2f, 15f + i * 7.5f, 96f + h / 2f, 2, col)
        }
        k.text(k.timeStr, 100, 186, 14 * k.ts, k.sec)
    }

    private fun vertical(k: K) {
        val a = hourWord(k.h12)
        val b = minuteWords(k.mi)
        val size = min(64f, min(k.fit(a, 64, 176, true), k.fit(b, 64, 176, true)))
        k.cv.save(); k.cv.translate(104f, 100f); k.cv.rotate(-90f)
        k.text(a, 0, 0, size, k.tx, true, spacing = -0.02f)
        k.cv.restore()
        k.cv.save(); k.cv.translate(176f, 100f); k.cv.rotate(-90f)
        k.text(b, 0, 0, size, k.ac, true, spacing = -0.02f)
        k.cv.restore()
    }

    // ---------- watch dials ----------

    private fun diver(k: K) {
        k.fillCircle(100, 100, 98, k.s1); k.ring(100, 100, 98, k.trk, 1)
        k.ring(100, 100, 92, k.trk2, 16)
        k.dashRing(100, 100, 92, k.tx, 6, 1.4f, 8.025f, 0.7f)
        k.dashRing(100, 100, 92, k.tx, 10, 3, 44.12f, 1.5f)
        k.poly(floatArrayOf(100f, 10f, 93f, 22f, 107f, 22f), k.ac)
        k.fillCircle(100, 100, 82, k.s2)
        k.dashRing(100, 100, 62, k.tx, 14, 6, 24.37f, 3)
        k.rrect(126, 93, 152, 107, 2, k.s1, k.trk, 1)
        k.text(k.day.toString(), 139, 104, 11, k.tx, true)
        k.hands(108, 58, 10, k.tx, 112, 26, 7, k.tx)
        k.hands(96, 62, 4, k.s2, 96, 32, 3, k.s2)
        k.fillCircle(100, 100, 6, k.ac)
    }

    private fun railroad(k: K) {
        k.fillCircle(100, 100, 96, k.s2)
        k.ring(100, 100, 92, k.tx, 1.2f)
        k.ring(100, 100, 76, k.tx, 1.2f)
        k.dashRing(100, 100, 84, k.tx, 12, 0.9f, 7.79f, 0.45f)
        val pos = arrayOf(floatArrayOf(132f, 44.6f), floatArrayOf(155.4f, 68f), floatArrayOf(164f, 100f), floatArrayOf(155.4f, 132f), floatArrayOf(132f, 155.4f), floatArrayOf(100f, 164f), floatArrayOf(68f, 155.4f), floatArrayOf(44.6f, 132f), floatArrayOf(36f, 100f), floatArrayOf(44.6f, 68f), floatArrayOf(68f, 44.6f), floatArrayOf(100f, 36f))
        for (i in 0 until 12) k.text(ROMAN[i], pos[i][0], pos[i][1], 17, k.tx, face = k.serif, central = true)
        k.ring(100, 134, 14, k.trk2, 1)
        k.text(k.day.toString(), 100, 134, 11, k.sec, true, central = true)
        k.line(100, 100, 100, 54, k.tx, 3, rot = k.hAng)
        k.cv.save(); k.cv.rotate(k.hAng, 100f, 100f); k.fillCircle(100, 66, 6, k.s2); k.ring(100, 66, 6, k.tx, 2); k.cv.restore()
        k.line(100, 100, 100, 22, k.tx, 2.5f, rot = k.mAng)
        k.cv.save(); k.cv.rotate(k.mAng, 100f, 100f); k.fillCircle(100, 40, 5, k.s2); k.ring(100, 40, 5, k.tx, 2); k.cv.restore()
        k.fillCircle(100, 100, 4, k.tx)
    }

    private fun tourbillon(k: K) {
        k.fillCircle(100, 100, 96, k.s2)
        k.dashRing(100, 100, 86, k.tx, 6, 0.01f, 43.98f, 0, Paint.Cap.ROUND)
        k.ring(100, 100, 74, k.trk, 0.6f)
        val pf = (k.data.battery / 100f).coerceIn(0.03f, 1f)
        k.arc(100, 58, 22, 300, 120, k.trk, 3)
        k.arc(100, 58, 22, 300, 120 * pf, k.ac, 3)
        k.text("PWR", 100, 76, 8, k.sec, true)
        k.fillCircle(100, 146, 26, k.s1); k.ring(100, 146, 26, k.tx, 1.5f)
        for (i in 0 until 3) k.line(100, 122, 100, 170, k.tx, 1.5f, rot = i * 60f + k.mi * 6f, px = 100, py = 146)
        k.ring(100, 146, 13, k.ac, 2)
        k.fillCircle(100, 146, 3.5f, k.ac)
        k.hands(100, 54, 9, k.s2, 100, 22, 6, k.s2)
        k.hands(100, 54, 5, k.tx, 100, 22, 2.5f, k.ac)
        k.fillCircle(100, 100, 5, k.tx)
    }

    private fun guilloche(k: K) {
        k.fillCircle(100, 100, 96, k.s2)
        k.cv.save()
        val clip = Path()
        clip.addCircle(100f, 100f, 78f, Path.Direction.CW)
        k.cv.clipPath(clip)
        for (i in 0 until 12) {
            k.cv.save(); k.cv.rotate(i * 30f, 100f, 100f)
            k.ring(100, 68, 46, k.trk2, 0.7f)
            k.cv.restore()
        }
        k.cv.restore()
        k.ring(100, 100, 78, k.tx, 1)
        k.dashRing(100, 100, 88, k.sec, 6, 1, 8.215f, 0.5f)
        k.dashRing(100, 100, 68, k.tx, 10, 4, 31.6f, 2)
        k.hands(104, 54, 7, k.s2, 108, 26, 5, k.s2)
        k.hands(104, 54, 4, k.tx, 108, 26, 2, k.ac)
        k.fillCircle(100, 100, 5, k.ac)
    }

    private fun deco(k: K) {
        k.fillCircle(100, 100, 96, k.s2)
        k.dashRing(100, 100, 47, k.alpha(k.ac, 90), 94, 6.2f, 6.1f, 0, top = false)
        k.dashRing(100, 100, 82, k.tx, 12, 5, 38.9f, 2.5f)
        k.fillCircle(100, 100, 68, k.s2); k.ring(100, 100, 68, k.tx, 1.5f)
        k.ring(100, 100, 63, k.tx, 0.6f)
        k.text("12", 100, 42, 19, k.tx, face = k.serif, central = true)
        k.text("3", 156, 100, 19, k.tx, face = k.serif, central = true)
        k.text("6", 100, 158, 19, k.tx, face = k.serif, central = true)
        k.text("9", 44, 100, 19, k.tx, face = k.serif, central = true)
        k.poly(floatArrayOf(95f, 102f, 100f, 48f, 105f, 102f), k.tx, null, 1, k.hAng)
        k.poly(floatArrayOf(97.5f, 102f, 100f, 24f, 102.5f, 102f), k.ac, null, 1, k.mAng)
        k.fillCircle(100, 100, 6, k.tx); k.fillCircle(100, 100, 2.5f, k.s2)
    }

    private fun compass(k: K) {
        k.fillCircle(100, 100, 96, k.s2)
        k.dashRing(100, 100, 90, k.sec, 6, 1, 8.215f, 0.5f)
        k.dashRing(100, 100, 78, k.tx, 6, 0.01f, 40.84f, 0, Paint.Cap.ROUND)
        k.poly(COMPASS8, k.trk, k.trk2, 0.8f)
        k.poly(floatArrayOf(100f, 6f, 94f, 18f, 106f, 18f), k.ac)
        k.poly(floatArrayOf(96f, 102f, 100f, 48f, 104f, 102f), k.tx, k.s2, 1.5f, k.hAng)
        k.poly(floatArrayOf(97.5f, 102f, 100f, 22f, 102.5f, 102f), k.ac, k.s2, 1.5f, k.mAng)
        k.fillCircle(100, 100, 6, k.tx); k.ring(100, 100, 6, k.s2, 2)
    }

    private fun station(k: K) {
        k.fillCircle(100, 100, 96, k.s2)
        k.dashRing(100, 100, 88, k.tx, 6, 2, 7.215f, 1)
        k.dashRing(100, 100, 76, k.tx, 14, 7, 34.89f, 3.5f)
        k.hands(100, 50, 10, k.tx, 100, 24, 7, k.tx, null, Paint.Cap.BUTT)
        k.fillCircle(100, 100, 6, k.ac)
    }

    private fun regulator(k: K) {
        k.fillCircle(100, 100, 96, k.s2)
        k.dashRing(100, 100, 88, k.sec, 6, 1, 8.215f, 0.5f)
        k.dashRing(100, 100, 88, k.tx, 10, 3, 44.12f, 1.5f)
        k.fillCircle(100, 62, 26, k.s1); k.ring(100, 62, 26, k.trk, 1)
        k.dashRing(100, 62, 21, k.tx, 4, 1.2f, 9.27f)
        k.line(100, 62, 100, 46, k.tx, 3.5f, rot = k.hAng, px = 100, py = 62)
        k.text("HOURS", 100, 87, 7, k.sec, true)
        k.fillCircle(100, 142, 26, k.s1); k.ring(100, 142, 26, k.trk, 1)
        k.dashRing(100, 142, 21, k.sec, 4, 1, 4.255f)
        val dim = k.now.toLocalDate().lengthOfMonth()
        k.arcDash(100, 142, 21, 0, k.day.toFloat() / dim * 360f, k.ac, 4, 1, 4.255f)
        k.text(k.dowShort.uppercase(), 100, 136, 8, k.sec, true)
        k.text(k.day.toString(), 100, 156, 20, k.tx, true)
        k.hands(104, 54, 0.1f, k.s2, 108, 22, 7, k.s2)
        k.line(100, 108, 100, 22, k.tx, 3.5f, rot = k.mAng)
        k.fillCircle(100, 100, 5, k.tx)
    }
}

object ClockRenderer {
    /** Draws the chosen face centered in the bitmap at the face's own proportions. */
    fun render(c: Context, st: Style, cfg: ClockCfg, wPx: Int, hPx: Int, preview: Boolean, zoned: ZonedDateTime = ZonedDateTime.now()): Bitmap {
        val (bmp, cv) = Widgets.blank(wPx, hPx)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val d = Widgets.density(c)
        if (st.bgOpacity > 0) {
            val pal = Palette.of(c, st)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Widgets.alpha(pal.bg, st.bgOpacity * 255 / 100)
            val r = (st.corner * d).coerceAtMost(min(w, h) / 2f)
            cv.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        }
        val s = ClockStyles.at(cfg.style)
        val sc = min(w / s.w, h / s.h)
        cv.translate((w - s.w * sc) / 2f, (h - s.h * sc) / 2f)
        cv.scale(sc, sc)
        val k = K(cv, c, st, cfg, zoned, preview)
        try {
            s.draw(k)
        } catch (e: Exception) {
            android.util.Log.e("ClockRenderer", "draw failed", e)
        }
        return bmp
    }
}

class ClockWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(c, m, it) }
    }

    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, opts: android.os.Bundle?) {
        update(c, m, id)
    }

    override fun onDeleted(c: Context, ids: IntArray) {
        ids.forEach { Store.deleteInst(c, it) }
    }

    override fun onEnabled(c: Context) {
        Live.ensure(c)
    }

    override fun onDisabled(c: Context) {
        if (!Widgets.any(c)) Live.stop(c)
    }

    companion object {
        fun update(c: Context, m: AppWidgetManager, id: Int) {
            try {
                val inst = Store.inst(c, id)
                val st = Widgets.style(c, inst)
                val (bw, bh) = Widgets.sizePx(c, m, id, Widgets.CLOCK)
                val fit = Widgets.fit(c, Widgets.CLOCK, inst, bw, bh)
                val bmp = Widgets.withDensity(fit.dens) { ClockRenderer.render(c, st, inst.clock, fit.w, fit.h, false) }
                val rv = RemoteViews(c.packageName, R.layout.widget_clock)
                rv.setImageViewBitmap(R.id.img, bmp)
                val open = Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val intent = if (open.resolveActivity(c.packageManager) != null) open else Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                rv.setOnClickPendingIntent(R.id.bg, PendingIntent.getActivity(c, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                m.updateAppWidget(id, rv)
            } catch (e: Exception) {
                android.util.Log.e("ClockWidget", "update failed", e)
            }
        }

        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            Widgets.ids(c, Widgets.CLOCK).forEach { update(c, m, it) }
        }
    }
}
